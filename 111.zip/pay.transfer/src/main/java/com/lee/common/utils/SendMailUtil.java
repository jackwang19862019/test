package com.lee.common.utils;

import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;
import java.util.Date;
import java.util.Properties;

public class SendMailUtil {

    public static R sendEmail(String receiveMailAccount, String msg) {

        String myEmailAccount = "Jack19862019@gmail.com";//RedisUtil.getEmailConfigValue(CfgKeyConst.email_account);
        String myEmailPassword = "Asdf@2019";//RedisUtil.getEmailConfigValue(CfgKeyConst.email_password);
        String myEmailSMTPHost = "smtp.gmail.com";//RedisUtil.getEmailConfigValue(CfgKeyConst.email_smtp_host);

        // 1. 创建参数配置, 用于连接邮件服务器的参数配置
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", myEmailSMTPHost);
        props.put("mail.smtp.port", "587");
        props.put("mail.debug", "false");

        // 2. 根据配置创建会话对象, 用于和邮件服务器交互
        Session session = Session.getInstance(props);
        session.setDebug(false);                                 // 设置为debug模式, 可以查看详细的发送 log

        // 3. 创建一封邮件
        MimeMessage message = null;
        Transport transport = null;
        try {
            message = createMimeMessage(session, myEmailAccount, receiveMailAccount, msg);
            transport = session.getTransport();
            transport.connect(myEmailAccount, myEmailPassword);

            transport.sendMessage(message, message.getAllRecipients());

            transport.close();
        } catch (Exception e) {
            e.printStackTrace();
            return R.error(e.getMessage());
        }
        return R.ok();

    }

    public static String getHtml(String leve, String channel, String className, String methodName, String lineNum, String error) {
        String html = "<!DOCTYPE html>";
        html += "<html>\n" +
                "<head>\n" +
                "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n" +
                "<table align=\"center\" style=\" color: rgb(0, 0, 0); font-family: 'lucida Grande', Verdana, 'Microsoft YaHei'; font-size: 14px; line-height: 23.8px; width: 1200px; margin: 0px; border: none; padding: 0px; background-image: url(); background-color: rgb(241, 245, 240); background-position: 490px 10px; background-repeat: no-repeat; \">\n" +
                "\t<tbody style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td colspan=\"2\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; padding: 0px; margin: 0px;\">\n" +
                "\t\t\t\t<p style=\"text-align:center;line-height: 20.4px; color: rgb(62, 207, 88); padding: 0px; margin: 0px;\">异常信息</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased;\"><br></td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">报错级别</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\"><span t=\"7\" style=\"border-bottom-width: 1px; border-bottom-style: dashed; border-bottom-color: rgb(204, 204, 204); z-index: 1; position: static;\">" + leve + "</span></td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">通道标识</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\"><span t=\"7\" style=\"border-bottom-width: 1px; border-bottom-style: dashed; border-bottom-color: rgb(204, 204, 204); z-index: 1; position: static;\">" + channel + "</span></td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误类名</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">" + className + "</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误方法(行)</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">" + methodName + "(" + lineNum + ")" + "</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误信息</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">\n" +
                "\t\t\t\t<a href=\"http://a.izing.info/\" target=\"_blank\" style=\"outline: none; cursor: pointer; color: rgb(153, 51, 0);\">" + error + "</a>\n" +
                "\t\t\t</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\"></tr>\n" +
                "\t</tbody>\n" +
                "</table>\n" +
                "</body>\n" +

                "</html>";
        return html;
    }


    public static String getHtmlApi(String leve, String msg, String className, String methodName, String lineNum, String error) {
        String html = "<!DOCTYPE html>";
        html += "<html>\n" +
                "<head>\n" +
                "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n" +
                "<table align=\"center\" style=\" color: rgb(0, 0, 0); font-family: 'lucida Grande', Verdana, 'Microsoft YaHei'; font-size: 14px; line-height: 23.8px; width: 880px; margin: 0px; border: none; padding: 0px; background-image: url(); background-color: rgb(241, 245, 240); background-position: 490px 10px; background-repeat: no-repeat; \">\n" +
                "\t<tbody style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td colspan=\"2\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; padding: 0px; margin: 0px;\">\n" +
                "\t\t\t\t<p style=\"text-align:center;line-height: 20.4px; color: rgb(62, 207, 88); padding: 0px; margin: 0px;\">异常信息</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased;\"><br></td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">报错级别</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\"><span t=\"7\" style=\"border-bottom-width: 1px; border-bottom-style: dashed; border-bottom-color: rgb(204, 204, 204); z-index: 1; position: static;\">" + leve + "</span></td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">异常msg</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\"><span t=\"7\" style=\"border-bottom-width: 1px; border-bottom-style: dashed; border-bottom-color: rgb(204, 204, 204); z-index: 1; position: static;\">" + msg + "</span></td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误类名</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">" + className + "</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误方法(行)</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">" + methodName + "(" + lineNum + ")" + "</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误信息</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">\n" +
                "\t\t\t\t<a href=\"http://a.izing.info/\" target=\"_blank\" style=\"outline: none; cursor: pointer; color: rgb(153, 51, 0);\">" + error + "</a>\n" +
                "\t\t\t</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\"></tr>\n" +
                "\t</tbody>\n" +
                "</table>\n" +
                "</body>\n" +

                "</html>";
        return html;
    }



    public static String getHtml(String leve,String className, String methodName, String lineNum, String error) {
        String html = "<!DOCTYPE html>";
        html += "<html>\n" +
                "<head>\n" +
                "  <meta http-equiv=\"Content-Type\" content=\"text/html; charset=utf-8\">\n" +
                "<table align=\"center\" style=\" color: rgb(0, 0, 0); font-family: 'lucida Grande', Verdana, 'Microsoft YaHei'; font-size: 14px; line-height: 23.8px; width: 880px; margin: 0px; border: none; padding: 0px; background-image: url(); background-color: rgb(241, 245, 240); background-position: 490px 10px; background-repeat: no-repeat; \">\n" +
                "\t<tbody style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td colspan=\"2\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; padding: 0px; margin: 0px;\">\n" +
                "\t\t\t\t<p style=\"text-align:center;line-height: 20.4px; color: rgb(62, 207, 88); padding: 0px; margin: 0px;\">商户信息</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased;\"><br></td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">报错级别</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\"><span t=\"7\" style=\"border-bottom-width: 1px; border-bottom-style: dashed; border-bottom-color: rgb(204, 204, 204); z-index: 1; position: static;\">" + leve + "</span></td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误类名</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">" + className + "</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: right; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误方法(行)</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">" + methodName + "(" + lineNum + ")" + "</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\">\n" +
                "\t\t\t<td width=\"300\" style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; text-align: top; padding-right: 20px;\">\n" +
                "\t\t\t\t<p style=\"line-height: 20.4px; color: rgb(125, 125, 125); padding: 0px; margin: 0px;\">错误信息</p>\n" +
                "\t\t\t</td>\n" +
                "\t\t\t<td style=\"font-size: 12px; -webkit-font-smoothing: subpixel-antialiased; word-break: break-all; padding: 0px; margin: 0px;\">\n" +
                "\t\t\t\t<a href=\"http://a.izing.info/\" target=\"_blank\" style=\"outline: none; cursor: pointer; color: rgb(153, 51, 0);\">" + error + "</a>\n" +
                "\t\t\t</td>\n" +
                "\t\t</tr>\n" +
                "\t\t<tr style=\"padding: 0px; margin: 0px;\"></tr>\n" +
                "\t</tbody>\n" +
                "</table>\n" +
                "</body>\n" +

                "</html>";
        return html;
    }




    /**
     * 创建一封只包含文本的简单邮件
     *
     * @param session     和服务器交互的会话
     * @param sendMail    发件人邮箱
     * @param receiveMail 收件人邮箱
     * @return
     * @throws Exception
     */
    public static MimeMessage createMimeMessage(Session session, String sendMail, String receiveMail, String msg) throws Exception {
        // 1. 创建一封邮件
        MimeMessage message = new MimeMessage(session);

        // 2. From: 发件人（昵称有广告嫌疑，避免被邮件服务器误认为是滥发广告以至返回失败，请修改昵称）聚富支付
        message.setFrom(new InternetAddress(sendMail, "admin", "UTF-8"));

        // 3. To: 收件人（可以增加多个收件人、抄送、密送）
        message.setRecipient(MimeMessage.RecipientType.TO, new InternetAddress(receiveMail, "尊敬的用户", "UTF-8"));

        // 4. Subject: 邮件主题（标题有广告嫌疑，避免被邮件服务器误认为是滥发广告以至返回失败，请修改标题）
        message.setSubject("商户信息", "UTF-8");

        // 5. Content: 邮件正文（可以使用html标签）（内容有广告嫌疑，避免被邮件服务器误认为是滥发广告以至返回失败，请修改发送内容）
        message.setContent(msg, "text/html;charset=UTF-8");

        // 6. 设置发件时间
        message.setSentDate(new Date());

        // 7. 保存设置
        message.saveChanges();

        return message;
    }

}
