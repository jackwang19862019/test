package com.lee.common.utils;

import com.lee.common.exception.RException;

public class SignUtils {

    public static final String MD5 = "MD5";

    public static final String RSA = "RSA";

    public static String validate(String signType, String sign, String context, String privateKey) {
        String content = null;
        switch (signType) {
            case MD5:

                break;
            case RSA:
                content = validateRSA(sign, content);
                break;
            default:
                throw new RException("不支持的加密方式");
        }
        return null;
    }

    public static String validateRSA(String sign, String content) {

        return null;
    }

    public static boolean validateMD5(String sign) {
        return false;
    }

}
