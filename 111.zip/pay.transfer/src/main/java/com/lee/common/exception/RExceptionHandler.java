package com.lee.common.exception;

import com.lee.common.utils.R;
import com.lee.common.utils.SendMailUtil;
import com.lee.mail.EmailService;
import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.net.SocketTimeoutException;

@RestControllerAdvice
public class RExceptionHandler {

    @Autowired
    EmailService emailService;

    private Logger logger = Logger.getLogger(RExceptionHandler.class);

    @ExceptionHandler(Exception.class)
    public R handleException(Exception e) {
        this.logger.error(e.getMessage(), e);
        String stackTrace = getStackTrace(e);
        if (stackTrace.contains("Read timed out")|| stackTrace.contains("connect timed out")){
            String s = ((RException) e).getchannelNo();
            return R.error(s+":支付请求超时，请重试。如多次请求失败，请联系第三方解决");
        }
        if (stackTrace.contains("HttpServerErrorException") || stackTrace.contains("500 Internal Server Error")){
            String s = ((RException) e).getchannelNo();
            return R.error(s+"代码报错，请联系第三方解决");
        }
        emailService.sendEmail(e);
        return R.error(e.getMessage());
    }

    private static String getStackTrace(Throwable throwable) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        try {
            throwable.printStackTrace(pw);
            return sw.toString();
        } finally {
            pw.close();
        }
    }

}
