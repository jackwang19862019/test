package com.lee.common.utils;

/**
 * @ClassName QhPayUtil
 * @Description 支付工具类
 * @Date 2017年10月31日 上午11:44:01
 * @version 1.0.0
 */
public class QhPayUtil {
	/**
	 * 密钥
	 */
	private static final String qhpayKey = "NsXpt407QKN2zq/5x4gK/Q==";

	/**
	 * 商户号前缀
	 */
	private static String merchNoPrefix = ""; 
	/**
	 * 代理商户号前缀
	 */
	private static String agentNoPrefix = ""; 
	
	/***
	 *  公钥
	 */
	private static String qhPublicKey = "";
	
	/**
	 *  私钥
	 */
	private static String qhPrivateKey = "";


	public static void setMerchNoPrefix(String merchNoPrefix){
		QhPayUtil.merchNoPrefix = merchNoPrefix;
	}
	


	public static void setAgentNoPrefix(String agentNoPrefix){
		QhPayUtil.agentNoPrefix = agentNoPrefix;
	}
	
	/**
	 * 
	 * @Description 加密
	 * @param content
	 * @return
	 */
	public static String encrypt(String content){
		return AesUtil.encrypt(content, qhpayKey);
	}
	
	/**
	 * 
	 * @Description 解密
	 * @param result
	 * @return
	 */
	public static String decrypt(String result){
		return AesUtil.decrypt(result, qhpayKey);
	};


	public static void setQhPublicKey(String publicKey){
		QhPayUtil.qhPublicKey = publicKey;
	}


	public static void setQhPrivateKey(String privateKey){
		QhPayUtil.qhPrivateKey = privateKey;
	}

}
