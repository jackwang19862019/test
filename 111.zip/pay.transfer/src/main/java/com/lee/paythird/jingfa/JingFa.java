package com.lee.paythird.jingfa;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

/**
 * 金发
 */
@Service(JingFa.channelNo)
public class JingFa extends AbstractPay {

    public static final String channelNo = "jingfa";

    static final String payWxWap = "http://interface.yjfpay.com:8081/pay.do";

    static final String payAliWap = "http://interface.yjfpay.com:8082/pay.do";

    static final String payWap = "http://interface.yjfpay.com:8080/pay.do";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public JingFa() {
        payTypeMap.put(OutChannel.wechatpay.name(), "wx");
        payTypeMap.put(OutChannel.wechatwap.name(), "wx_wap");

        payTypeMap.put(OutChannel.aliwap.name(), "alipay_wap");
        payTypeMap.put(OutChannel.alipay.name(), "alipay");

        payTypeMap.put(OutChannel.qqpay.name(), "qq");
        payTypeMap.put(OutChannel.qqwap.name(), "qq_wap");

        payTypeMap.put(OutChannel.jdpay.name(), "jd");
        payTypeMap.put(OutChannel.jdwap.name(), "jd_wap");

        payTypeMap.put(OutChannel.unionpay.name(), "yl");
        payTypeMap.put(OutChannel.unionwap.name(), "yl_wap");

        payTypeMap.put(OutChannel.quickpay.name(), "quick");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "金发支付，请求：{}", JSON.toJSONString(jObj));
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }
        String reqUrl = getUrl(payType);
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new LinkedHashMap<>();
        //版本号
        params.put("version", "1.0");
        //商户号
        params.put("mer_id", upMerchantNo);
        //订单号
        params.put("order_id", orderNo);
        //金额
        params.put("price", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        //异步地址
        params.put("notify_url", getCallbackUrl(channelNo, merchNo, orderNo));
        //支付方式
        params.put("pay_type", payType);
        //随机数
        params.put("randomid", System.currentTimeMillis() + "");

        String signParams = SignatureUtils.buildParams(params, false) + "&key=" + upMerchantKey;
        LogByMDC.info(channelNo, "金发支付签名参数：{}", signParams);
        String sign = SignatureUtils.getMD5(signParams);
        params.put("return_url", returnUrl);
        params.put("sign", sign);
        LogByMDC.info(channelNo, "金发支付订单号：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(reqUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "金发支付订单号：{}，response：{}", orderNo, result);

        params = doBusiness(result, upMerchantKey);
        String error = params.get("error");
        if (!StringUtils.isEmpty(error)) {
            return R.error(error);
        }


        String url = params.get("qrcode_url");
        String price = params.get("price");

        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(PayConstants.web_code_url, url);
        returnMap.put(OrderParamKey.amount.name(), price);
        return R.ok().put(Constant.result_data, returnMap);
    }

    private Map<String, String> doBusiness(String result, String upMerchantKey) {
        Map<String, String> map = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String codeResult = map.get("code");
        String message = map.get("message");
        if (!"00".equals(codeResult)) {
            //编码
            String errorMsg = unicode2String(message);
            LogByMDC.error(channelNo, "金发上游返回：" + errorMsg);
            Map<String, String> errorMap = new HashMap<>();
            errorMap.put("error", errorMsg + "(1、支付方式正在维护 2、金额不属于该支付方式范围)");
            return errorMap;
        }
        LogByMDC.info(channelNo, "金发支付响应：{}", unicode2String(message));
        String data = map.get("data");


        Map<String, String> dataMap = JSON.parseObject(data, new TypeReference<Map<String, String>>() {
        });
        String sign = dataMap.get("sign");
        String pay_order = dataMap.get("pay_order");
        String order_id = dataMap.get("order_id");
        String price = dataMap.get("price");
        String pay_type = dataMap.get("pay_type");
        String qrcode_url = dataMap.get("qrcode_url");
        String signParams = "pay_order=" + pay_order + "&order_id=" + order_id + "&price=" + price + "&pay_type=" + pay_type + "&qrcode_url=" + qrcode_url + "&code=00&key=" + upMerchantKey;
        String md5Sign = SignatureUtils.getMD5(signParams);
        if (!md5Sign.equals(sign)) {
            LogByMDC.info(channelNo, "金发支付响应验签失败：{}", signParams);
            throw new RException("金发支付验签失败");
        }
        return dataMap;
    }

    public static String unicode2String(String unicode) {
        StringBuffer string = new StringBuffer();
        String[] hex = unicode.split("\\\\u");
        for (int i = 1; i < hex.length; i++) {
            // 转换出每一个代码点
            int data = Integer.parseInt(hex[i], 16);

            // 追加成string
            string.append((char) data);
        }
        return string.toString();
    }

    private String getUrl(String payType) {
        if ("wx_wap".equals(payType) || "wx".equals(payType)) {
            return payWxWap;
        } else if ("alipay".equals(payType) || "alipay_wap".equals(payType)) {
            return payAliWap;
        } else {
            return payWap;
        }
    }


    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        String mapKey = "";
        Set<String> keySet = params.keySet();
        for (String key : keySet) {
            mapKey = key;
        }
        params = JSON.parseObject(mapKey, new TypeReference<Map<String, String>>() {
        });
        LogByMDC.info(channelNo, "金发支付回调内容：{}", mapKey);
        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "金发支付订单：{}，重复回调", orderNo);
            return "success";
        }


        String upSign = params.get("sign");
        params.remove("sign");
        String sign = verifySign(params, upMerchantKey);
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "金发支付订单：{}，验证回调签名错误", orderNo);
            throw new RException("金发支付回调验签失败");
        }

        String status = params.get("code");
        if (!"00".equals(status)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "";
        }

        String price = params.get("price");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(price).multiply(new BigDecimal("0.01")));
        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "金发支付订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "金发支付订单：{}，下发通知失败", order.getOrderNo());
            throw new RException("下发通知失败:"+e);
        }
        return "success";
    }


    private String verifySign(Map<String, String> params, String merchantKey) {
        String pay_order = params.get("pay_order");
        String order_id = params.get("order_id");
        String price = params.get("price");
        String pay_type = params.get("pay_type");
        String code = params.get("code");
        String timestamp = params.get("timestamp");
        String signStr = "pay_order=" + pay_order + "&order_id=" + order_id +
                "&price=" + price + "&pay_type=" + pay_type + "&code=" + code + "&timestamp=" + timestamp + "&key=" + merchantKey;
        return SignatureUtils.getMD5(signStr);
    }
}

