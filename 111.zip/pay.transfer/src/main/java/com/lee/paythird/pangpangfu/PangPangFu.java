package com.lee.paythird.pangpangfu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.*;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import com.lee.paythird.utils.HttpsParams;
import com.lee.paythird.xinfa.utils.ToolKit;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.text.SimpleDateFormat;
import java.util.*;

/**
 * 胖胖付
 */
@Service(PangPangFu.channelNo)
public class PangPangFu extends AbstractPay {

    public static final String channelNo = "pangpangfu";

    private final String payUrl = "https://api.pangpangfu.com/v1/pay";


    private final Map<String, String> payTypeMap = new HashMap<>();

    public PangPangFu() {
        payTypeMap.put(OutChannel.alipay.name(), "alipay");
        payTypeMap.put(OutChannel.wechatpay.name(), "wxpay");
        payTypeMap.put(OutChannel.qqpay.name(), "qqpay");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "胖胖支付 支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Date now = new Date();

        BigDecimal money = new BigDecimal(amount);

        Map<String, String> params = new TreeMap<>();
        //充值金额 ( 单位元，两位小数 )
        DecimalFormat df = new DecimalFormat("#.00");
        params.put("amount", df.format(money));
        //当前时间 ( 格式为：yyyyMMddHHmmss，例如：20180101235959 )
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        params.put("currentTime", sdf.format(now));
        //商户号
        params.put("merchant", upMerchantNo);
        //结果通知地址 ( 返回支付结果 )
        params.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        //商户订单号
        params.put("orderNo", orderNo);
        //支付类型 ( alipay=支付宝，wxpay=微信，qqpay=QQ钱包 )
        params.put("payType", payType);
        //同步回调地址 ( 支付成功或订单超时自动跳转的地址 )
        params.put("returnUrl", returnUrl);

        String signParams = sign(params);
        String sign = DigestUtils.md5Hex(signParams + "#" + upMerchantKey).toUpperCase();
        params.put("sign",sign);
        LogByMDC.info(channelNo, "胖胖支付 订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        //List<NameValuePair> list = new ArrayList<>();
        //params.forEach((k,v)->list.add(new BasicNameValuePair(k, v)));
        //String resultHtml = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        //saveOrder(jObj, channel.getChannelNo(), merchantChannel.getUpMerchantNo());
        OrderEntity order = JSONObject.toJavaObject(jObj, OrderEntity.class);
        order.setOrderState(OrderState.init.id());
        order.setCrtDate(now);
        order.setNoticeState(NoticeState.init.id());
        order.setPayCompany(channelNo);
        order.setPayMerch(upMerchantNo);
        orderService.save(order);


        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, " 胖胖支付 回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "胖胖支付 订单：{}，重复回调", order.getOrderNo());
            return "SUCCESS";
        }

        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String upSign = params.get("sign");
        params.remove("sign");


        String sign = SignatureUtils.sign(params, "#" + upMerchantKey);

        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "胖胖支付 订单：{}，验证回调签名错误", orderNo);
            return "ERROR";
        }

        String payFlag = params.get("payFlag");
        if (!"2".equals(payFlag)) {
            LogByMDC.error(channelNo, "胖胖支付 订单：{}，支付未成功，不再向下通知", orderNo);
            return "SUCCESS";
        }

        String amount = params.get("amount");
        String systemNo = params.get("systemNo");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(systemNo);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "胖胖支付 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "胖胖支付 订单：{}，下发通知失败", order.getOrderNo());
        }

        return "SUCCESS";
    }


    private static String sign(Map<String, String> params) {
        StringBuffer sb = new StringBuffer();
        params.forEach((k, v) -> {
            sb.append(k + "=" + v + "&");
        });
        if (!org.springframework.util.StringUtils.isEmpty(sb)) {
            String str = sb.toString();
            str = str.substring(0, str.length() - 1);
            return str;
        }
        return null;
    }
}
