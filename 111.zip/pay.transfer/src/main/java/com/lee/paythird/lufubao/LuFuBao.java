package com.lee.paythird.lufubao;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.*;

/**
 * 陆付宝
 */
@Service(LuFuBao.channelNo)
public class LuFuBao extends AbstractPay {

    public static final String channelNo = "lufubao";

    private final String payUrl = "http://47.107.84.87:9920/trade";
    private final String queryUrl = "http://47.107.84.87:9920/order";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public LuFuBao() {
        payTypeMap.put(OutChannel.alih5.name(), "0");
        payTypeMap.put(OutChannel.aliwap.name(), "1");
        payTypeMap.put(OutChannel.alipay.name(), "3");
        payTypeMap.put("alidm", "6");
        payTypeMap.put(OutChannel.wechatpay.name(), "13");
        payTypeMap.put("aliyl", "1001");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }


        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new HashMap<>();
        //版本号
        params.put("version", "1.0");
        //商户号
        params.put("appid", upMerchantNo);
        //订单号
        params.put("trade_no", orderNo);
        //金额
        params.put("price", amount);
        //异步地址
        params.put("callback", getCallbackUrl(channelNo, merchNo, orderNo));
        //付款用户IP
        params.put("ip", reqIp);
        //返回地址
        params.put("return", returnUrl);
        //商品名称
        params.put("subject", product);
        //支付网关
        //"0:  支付宝手机网站、
        //1:  支付宝PC网站、
        //3： 支付宝扫码、
        //6:  支付宝当面付、
        //13：微信扫码
        //1001：支付宝扫码转银行卡"
        params.put("gateway", payType);



        String sign = sign(params, upMerchantKey);
        params.put("sign", sign);

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, params, String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>(){});
        String status = params.get("status");
        if (!"200".equals(status)) {
            String errMsg = params.get("message");
            LogByMDC.error(channelNo, "订单：{}，上游返回：{}", orderNo, errMsg);
            return R.error("上游返回：" + errMsg);
        }

        String url = params.get("url");
        String price = params.get("price");

        saveOrder(jObj, channelNo, upMerchantNo);


        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(PayConstants.web_code_url, url);
        returnMap.put(OrderParamKey.amount.name(), price);
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        Map<String, String> params = new HashMap<>();
        params.put("version", "1.0");
        params.put("appid", upMerchantNo);
        params.put("trade_no", orderNo);
        String sign = sign(params, upMerchantKey);
        params.put("sign", sign);

        LogByMDC.info(channelNo, "查询订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(queryUrl, params, String.class);
        LogByMDC.info(channelNo, "查询订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>(){});

        String status = params.get("status");
        if (!"200".equals(status)) {
            String errMsg = params.get("message");
            LogByMDC.error(channelNo, "查询订单信息错误，上游返回：{}", errMsg);
            throw new RException("查询订单信息错误，上游返回：" + errMsg);
        }

        List<Map<String, String>> list = JSON.parseObject(params.get("data"), new TypeReference<List<Map<String, String>>>(){});
        if (list.size() > 0) {
            Map<String, String> orderMap = list.get(0);

            status = orderMap.get("status");
            if ("2".equals(status)) {
                String price = orderMap.get("price");
                order.setOrderState(OrderState.succ.id());
                order.setRealAmount(new BigDecimal(price));
                orderService.update(order);
            } else {
                LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", orderNo);
            }
        }
        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);
        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", orderNo);
            return "";
        }



        String upSign = params.get("sign");
        params.remove("sign");
        String sign = sign(params, upMerchantKey);
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return "";
        }

        String status = params.get("status");
        if (!"200".equals(status)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "";
        }

        String price = params.get("price");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(price));
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "";
    }




    private String sign(Map<String, String> params, String merchantKey) {
        Map<String, String> map = new TreeMap<>(params);
        map.put("token", merchantKey);
        Set<String> keySet = map.keySet();
        StringBuffer sb = new StringBuffer();
        for (String key : keySet) {
            String value = map.get(key);
            if (StringUtils.isNotBlank(value) && !"null".equals(value)) {
                sb.append(key);
                sb.append(map.get(key));
            }
        }
        LogByMDC.info(channelNo, "签名原始串：{}", sb.toString());
        return DigestUtils.sha1Hex(sb.toString()).toUpperCase();
    }
}

