package com.lee.paythird.ydw360;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.*;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.ydw360.utils.ToolKit;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

import static com.lee.common.utils.AesUtil.key;

@Service("ydw360")
public class Ydw360Pay extends AbstractPay {

    public static final String channelNo = "ydw360";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public Ydw360Pay() {
        payTypeMap.put(OutChannel.alipay.name(), "ALI_QR");
        payTypeMap.put(OutChannel.alih5.name(), "ALI_H5");
        payTypeMap.put(OutChannel.aliwap.name(), "ALI_WAP");
        payTypeMap.put(OutChannel.wechatpay.name(), "WECHAT_QR");
        payTypeMap.put(OutChannel.wechath5.name(), "WECHAT_H5");
        payTypeMap.put(OutChannel.wechatwap.name(), "WECHAT_WAP");
        payTypeMap.put(OutChannel.qqh5.name(), "QQ_H5");
        payTypeMap.put(OutChannel.qqpay.name(), "QQ_QR");
        payTypeMap.put(OutChannel.jdh5.name(), "JD_H5");
        payTypeMap.put(OutChannel.jdpay.name(), "JD_QR");
        payTypeMap.put(OutChannel.baidupay.name(), "BAIDU_QR");
        payTypeMap.put(OutChannel.unionpay.name(), "UNION_PAY_QR");
        payTypeMap.put(OutChannel.unionh5.name(), "UNION_PAY_H5");
        payTypeMap.put(OutChannel.quickpay.name(), "E_BANK_QUICK");
        payTypeMap.put(OutChannel.alipayd1.name(), "ALI_QR_D1");
        payTypeMap.put(OutChannel.alih5d1.name(), "ALI_H5_D1");
        payTypeMap.put(OutChannel.aliwapd1.name(), "ALI_WAP_D1");
        payTypeMap.put(OutChannel.wechatpayd1.name(), "WECHAT_QR_D1");
        payTypeMap.put(OutChannel.wechath5d1.name(), "WECHAT_H5_D1");
        payTypeMap.put(OutChannel.wechatwapd1.name(), "WECHAT_WAP_D1");


        payTypeMap.put(OutChannel.bank_citic.name(), "E_BANK_CITIC");
        payTypeMap.put(OutChannel.bank_psbc.name(), "E_BANK_PSBC");
        payTypeMap.put(OutChannel.bank_spdb.name(), "E_BANK_SPDB");
        payTypeMap.put(OutChannel.bank_cib.name(), "E_BANK_CIB");
        payTypeMap.put(OutChannel.bank_hxb.name(), "E_BANK_HXB");
        payTypeMap.put(OutChannel.bank_cmbc.name(), "E_BANK_CMBC");
        payTypeMap.put(OutChannel.bank_ceb.name(), "E_BANK_CEB");
        payTypeMap.put(OutChannel.bank_cmb.name(), "E_BANK_CMB");
        payTypeMap.put(OutChannel.bank_bcom.name(), "E_BANK_BCOM");
        payTypeMap.put(OutChannel.bank_ccb.name(), "E_BANK_CCB");
        payTypeMap.put(OutChannel.bank_abc.name(), "E_BANK_ABC");
        payTypeMap.put(OutChannel.bank_boc.name(), "E_BANK_BOC");
        payTypeMap.put(OutChannel.bank_icbc.name(), "E_BANK_ICBC");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }


        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String payUrl = channelObj.getString("payUrl");

        JSONObject merchantChannelObj = JSON.parseObject(merchantChannel.getPayload());
        String md5Key = merchantChannelObj.getString("md5Key");

        String publicKey = merchantChannelObj.getString("payPublicKey");


        Map<String, String> params = new TreeMap<>();
        //订单号，必须按当前时间的yyyyMMdd开头，并以北京时间为准（例如：2019010800001）
        params.put("orderNum", orderNo);
        params.put("version", "V4.0.0.0");
        params.put("charset", ToolKit.CHARSET);//
        params.put("random", ToolKit.randomStr(4));// 4位随机数
        //商户号
        params.put("merNo", merchantChannel.getUpMerchantNo());
        //子商户号（和商户号一样）
        params.put("subMerNo", merchantChannel.getUpMerchantNo());
        //支付网关代码，参考最新支付网关代码.xlsx
        params.put("netway", payType);
        params.put("amount", new BigDecimal(amount).multiply(new BigDecimal("100")).intValue() + "");// 单位:分
        params.put("goodsName", product);// 商品名称：20位
        params.put("callBackUrl", getCallbackUrl(channel.getChannelNo(), merchNo, orderNo));// 回调地址
        params.put("callBackViewUrl", returnUrl);// 回显地址


        try {
            String metaSignJsonStr = JSON.toJSONString(params);
            String sign = ToolKit.MD5(metaSignJsonStr + md5Key, ToolKit.CHARSET);// 32位
            params.put("sign", sign);

            byte[] dataStr = ToolKit.encryptByPublicKey(JSON.toJSONString(params).getBytes(ToolKit.CHARSET), publicKey);
            String param = Base64.getEncoder().encodeToString(dataStr);
            String reqParam = "data=" + URLEncoder.encode(param, ToolKit.CHARSET) + "&merchNo=" + params.get("merNo")
                    + "&version=" + params.get("version");
            String resultJsonStr = ToolKit.request(payUrl, reqParam);
            LogByMDC.info(channelNo, "上游返回参数：{}", resultJsonStr);
            // 检查状态
            JSONObject resultJsonObj = JSON.parseObject(resultJsonStr);
            String stateCode = resultJsonObj.getString("stateCode");
            if (!stateCode.equals("00")) {
                LogByMDC.error(channelNo, "订单：{}，上游返回：{}", orderNo, resultJsonObj.getString("msg"));
                return R.error("上游返回错误：" + resultJsonObj.getString("msg"));
            }
            String resultSign = resultJsonObj.getString("sign");
            resultJsonObj.remove("sign");
            String targetString = ToolKit.MD5(JSON.toJSONString(new TreeMap<>(resultJsonObj)) + md5Key, ToolKit.CHARSET);
            System.out.println(targetString);
            System.out.println(resultSign);
            if (!targetString.equals(resultSign)) {
                LogByMDC.error(channelNo, "订单：{}，签名校验失败", orderNo);
                return R.error("上游签名验证失败");
            }

            String qrcodeUrl = resultJsonObj.getString("qrcodeUrl");

            saveOrder(jObj, channel.getChannelNo(), merchantChannel.getUpMerchantNo());

            Map<String, String> resultMap = new HashMap<>();
            switch (payType) {
                case "ALI_QR":
                case "WECHAT_QR":
                case "QQ_QR":
                case "BAIDU_QR":
                case "UNION_PAY_QR":
                case "JD_QR":
                case "ALI_QR_D1":
                case "WECHAT_QR_D1":
                    resultMap.put(PayConstants.web_qrcode_url, "data:image/png;base64," + Base64.getEncoder().encodeToString(qrcodeUrl.getBytes()));
                    break;
                default:
                    resultMap.put(PayConstants.web_code_url, qrcodeUrl);
            }
            resultMap.put(OrderParamKey.orderNo.name(), orderNo);
            resultMap.put(OrderParamKey.outChannel.name(), outChannel);
            resultMap.put(OrderParamKey.merchNo.name(), merchNo);
            resultMap.put(OrderParamKey.channelNo.name(), channel.getChannelNo());
            resultMap.put(OrderParamKey.amount.name(), amount);

            return R.ok().put(Constant.result_data, resultMap);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，RSA加密失败", orderNo);
            return R.error("RSA加密失败");
        }

    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);
        JSONObject merchantChannelObj = JSON.parseObject(merchantChannel.getPayload());
        String md5Key = merchantChannelObj.getString("md5Key");

        String privateKey = merchantChannelObj.getString("privateKey");


        String data = params.get("data");
        byte[] result;
        try {
            String str = URLDecoder.decode(data, ToolKit.CHARSET);
            byte[] content = Base64.getDecoder().decode(str);
            result = ToolKit.decryptByPrivateKey(content, privateKey);

            String resultData = new String(result, ToolKit.CHARSET);// 解密数据

            JSONObject jsonObj = JSON.parseObject(resultData);
            String resSign = (String) jsonObj.remove("sign");
            String jsonStr = JSON.toJSONString(new TreeMap<>(jsonObj));
            String sign = ToolKit.MD5(jsonStr.toString() + md5Key, ToolKit.CHARSET);
            if (!sign.equals(resSign)) {
                System.out.println("验签失败");
                return "1";
            }

            //商户号
            String merNo = jsonObj.getString("merNo");
            //子商户号（和商户号一样）
            String subMerNo = jsonObj.getString("subMerNo");
            //支付网关代码，最新支付网关代码.xlsx
            String netway = jsonObj.getString("netway");
            //订单号
            String orderNum = jsonObj.getString("orderNum");
            //金额（单位：分）
            String amount = jsonObj.getString("amount");
            //真实金额（单位：分）
            String realAmount = jsonObj.getString("realAmount");
            //商品名称
            String goodsName = jsonObj.getString("goodsName");
            //支付状态，00表示成功
            String payResult = jsonObj.getString("payResult");
            //支付时间，格式：yyyyMMddHHmmss
            String payDate = jsonObj.getString("payDate");

            if (!"00".equals(payResult)) {
                LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNum);
                return "0";
            }

            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(realAmount).multiply(new BigDecimal("0.01")));

            orderService.update(order);

            //通知下游
            try {
                notifyTask.put(order, order.getEncryptType());
            } catch (Exception e) {
                e.printStackTrace();
                LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "回调订单：{}，RSA解密失败", order.getOrderNo());
        }

        return "0";
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {

        JSONObject merchantChannelObj = JSON.parseObject(merchantChannel.getPayload());
        String md5Key = merchantChannelObj.getString("md5Key");
        String publicKey = merchantChannelObj.getString("payPublicKey");

        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String queryUrl = channelObj.getString("queryUrl");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

        Map<String, String> metaSignMap = new TreeMap<String, String>();
        metaSignMap.put("orderNum", order.getOrderNo());
        metaSignMap.put("payDate", sdf.format(order.getCrtDate()));
        metaSignMap.put("merNo", order.getPayMerch());
        metaSignMap.put("netway", payTypeMap.get(order.getOutChannel()));
        metaSignMap.put("amount", order.getAmount().multiply(new BigDecimal("100")).intValue() + "");// 单位:分
        metaSignMap.put("goodsName", order.getProduct());// 商品名称：20位


        try {
            String metaSignJsonStr = JSON.toJSONString(metaSignMap);
            String sign = ToolKit.MD5(metaSignJsonStr + md5Key, ToolKit.CHARSET);// 32位
            System.out.println("sign=" + sign); // 英文字母大写
            metaSignMap.put("sign", sign);

            byte[] dataStr = ToolKit.encryptByPublicKey(JSON.toJSONString(metaSignMap).getBytes(ToolKit.CHARSET), publicKey);
            String param = Base64.getEncoder().encodeToString(dataStr);
            String reqParam = "data=" + URLEncoder.encode(param, ToolKit.CHARSET) + "&merchNo=" + metaSignMap.get("merNo")
                    + "&version=V4.0.0.0";
            String resultJsonStr = ToolKit.request(queryUrl, reqParam);

            LogByMDC.info(channelNo, "查询订单：{}，返回：{}", order.getOrderNo(), resultJsonStr);
            // 检查状态
            JSONObject resultJsonObj = JSON.parseObject(resultJsonStr);
            String stateCode = resultJsonObj.getString("stateCode");
            if (!stateCode.equals("00")) {
                throw new RException(resultJsonObj.getString("msg"));
            }
            String resultSign = resultJsonObj.getString("sign");
            resultJsonObj.remove("sign");
            String targetString = ToolKit.MD5(JSON.toJSONString(new TreeMap<>(resultJsonObj)) + md5Key, ToolKit.CHARSET);
            if (!targetString.equals(resultSign)) {
                LogByMDC.error(channelNo, "订单：{}，同步返回信息签名错误", order.getOrderNo());
                throw new RException("上游返回信息签名验证失败");
            }

            String merNo = resultJsonObj.getString("merNo");
            String netway = resultJsonObj.getString("netway");
            String orderNum = resultJsonObj.getString("orderNum");
            String payStateCode = resultJsonObj.getString("payStateCode");

            Integer orderState = order.getOrderState();
            //支付状态 00:支付成功 01:支付失败 03:签名错误 04:其他错误 05:未知 06:初始 50:网络异常 99:未支付
            switch (payStateCode) {
                case "00":
                    orderState = OrderState.succ.id();
                    break;
                case "01":
                    orderState = OrderState.fail.id();
                case "03":
                case "04":
                case "05":
                case "50":
                case "99":
                    break;
                case "06":
                    orderState = OrderState.init.id();

            }
            order.setOrderState(orderState);

            orderService.update(order);


        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，上游签名验证异常", order.getOrderNo());
            throw new RException("上游签名验证异常");
        }
        return order;
    }


    @Override
    public R orderAcp(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "代付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String bankAccountName = jObj.getString(OrderParamKey.bankAccountName.name());
        String bankAccountNo = jObj.getString(OrderParamKey.bankAccountNo.name());


        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String payUrl = channelObj.getString("acpUrl");

        JSONObject merchantChannelObj = JSON.parseObject(merchantChannel.getPayload());
        String md5Key = merchantChannelObj.getString("md5Key");

        String publicKey = merchantChannelObj.getString("acpPublicKey");


        Map<String, String> params = new TreeMap<>();
        //版本号，固定值：V4.0.0.0
        params.put("version", "V4.0.0.0");
        //商户号
        params.put("merNo", merchantChannel.getUpMerchantNo());
        //订单号
        params.put("orderNum", orderNo);
        //金额，（单位：分）
        params.put("amount", new BigDecimal(amount).multiply(new BigDecimal("100")).intValue() + "");
        //银行代码，参照银行对应表
        params.put("bankCode", bankCode);
        //开户名
        params.put("bankAccountName", bankAccountName);
        //银行卡号
        params.put("bankAccountNo", bankAccountNo);
        //结果通知地址
        params.put("callBackUrl", getAgentCallBackUrl(channel.getChannelNo(), merchant.getMerchantNo(), orderNo));
        //客户端系统编码格式，UTF-8，GBK
        params.put("charset", ToolKit.CHARSET);

        try {
            String metaSignJsonStr = JSON.toJSONString(params);
            String sign = ToolKit.MD5(metaSignJsonStr + key, ToolKit.CHARSET);// 32位
            params.put("sign", sign);
            byte[] dataStr = ToolKit.encryptByPublicKey(JSON.toJSONString(params).getBytes(ToolKit.CHARSET),
                    ToolKit.REMIT_PUBLIC_KEY);
            String param = Base64.getEncoder().encodeToString(dataStr);
            String reqParam = "data=" + URLEncoder.encode(param, ToolKit.CHARSET) + "&merchNo=" + params.get("merNo")
                    + "&version=" + params.get("version");
            String resultJsonStr = ToolKit.request(payUrl, reqParam);
            System.out.println(resultJsonStr);
            // 检查状态
            JSONObject resultJsonObj = JSON.parseObject(resultJsonStr);
            String stateCode = resultJsonObj.getString("stateCode");
            if (!stateCode.equals("00")) {
                LogByMDC.error(channelNo, "订单：{}，上游返回：{}", orderNo, resultJsonObj.getString("msg"));
                return R.error("上游返回：" + resultJsonObj.getString("msg"));
            }
            String resultSign = resultJsonObj.getString("sign");
            resultJsonObj.remove("sign");
            String targetString = ToolKit.MD5(JSON.toJSONString(new TreeMap<>(resultJsonObj)) + md5Key, ToolKit.CHARSET);
            if (!targetString.equals(resultSign)) {
                LogByMDC.error(channelNo, "订单：{}，签名校验失败", orderNo);
                return R.error("上游签名验证失败");
            }

            saveAcpOrder(jObj, channel.getChannelNo(), merchantChannel.getUpMerchantNo());

            Map<String, String> resultMap = new HashMap<>();

            resultMap.put(OrderParamKey.orderNo.name(), orderNo);
            resultMap.put(OrderParamKey.merchNo.name(), merchNo);
            resultMap.put(OrderParamKey.channelNo.name(), channel.getChannelNo());
            resultMap.put(OrderParamKey.amount.name(), amount);

            return R.ok().put(Constant.result_data, resultMap);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，RSA加密失败", orderNo);
            return R.error("RSA加密失败");
        }
    }


    @Override
    public String acpCallback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderAcpEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "代付回调内容：{}", params);
        JSONObject merchantChannelObj = JSON.parseObject(merchantChannel.getPayload());
        String md5Key = merchantChannelObj.getString("md5Key");

        String privateKey = merchantChannelObj.getString("privateKey");


        String data = params.get("data");
        byte[] result;
        try {
            String str = URLDecoder.decode(data, ToolKit.CHARSET);
            byte[] content = Base64.getDecoder().decode(str);
            result = ToolKit.decryptByPrivateKey(content, privateKey);

            String resultData = new String(result, ToolKit.CHARSET);// 解密数据

            JSONObject jsonObj = JSON.parseObject(resultData);
            String resSign = (String) jsonObj.remove("sign");
            String jsonStr = JSON.toJSONString(new TreeMap<>(jsonObj));
            String sign = ToolKit.MD5(jsonStr.toString() + md5Key, ToolKit.CHARSET);
            if (!sign.equals(resSign)) {
                System.out.println("验签失败");
                return "1";
            }

            //商户号
            String merNo = jsonObj.getString("merNo");
            //订单号
            String orderNum = jsonObj.getString("orderNum");
            //金额（单位：分）
            String amount = jsonObj.getString("amount");
            //代付状态，00表示成功
            String remitResult = jsonObj.getString("remitResult");
            //
            String remitDate = jsonObj.getString("remitDate");

            if (!"00".equals(remitResult)) {
                LogByMDC.error(channelNo, "代付订单：{}，支付未成功，不再向下通知", orderNum);
                return "0";
            }

            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));

            orderAcpService.update(order);

            //通知下游
            try {
                notifyTask.put(order, order.getEncryptType());
            } catch (Exception e) {
                e.printStackTrace();
                LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
            }
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "回调代付订单：{}，RSA解密失败", order.getOrderNo());
        }

        return "0";
    }


    @Override
    public OrderAcpEntity queryAcp(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderAcpEntity order) {
            JSONObject merchantChannelObj = JSON.parseObject(merchantChannel.getPayload());
            String md5Key = merchantChannelObj.getString("md5Key");
            String publicKey = merchantChannelObj.getString("payPublicKey");

            JSONObject channelObj = JSON.parseObject(channel.getPayload());
            String queryUrl = channelObj.getString("queryUrl");

            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");

            Map<String, String> metaSignMap = new TreeMap<String, String>();
            metaSignMap.put("orderNum", order.getOrderNo());
            metaSignMap.put("remitDate", sdf.format(order.getCrtDate()));
            metaSignMap.put("merNo", order.getPayMerch());
            metaSignMap.put("amount", order.getAmount().multiply(new BigDecimal("100")).intValue() + "");// 单位:分


            try {
                String metaSignJsonStr = JSON.toJSONString(metaSignMap);
                String sign = ToolKit.MD5(metaSignJsonStr + md5Key, ToolKit.CHARSET);// 32位
                System.out.println("sign=" + sign); // 英文字母大写
                metaSignMap.put("sign", sign);

                byte[] dataStr = ToolKit.encryptByPublicKey(JSON.toJSONString(metaSignMap).getBytes(ToolKit.CHARSET), publicKey);
                String param = Base64.getEncoder().encodeToString(dataStr);
                String reqParam = "data=" + URLEncoder.encode(param, ToolKit.CHARSET) + "&merchNo=" + metaSignMap.get("merNo")
                        + "&version=V4.0.0.0";
                String resultJsonStr = ToolKit.request(queryUrl, reqParam);

                LogByMDC.info(channelNo, "查询订单：{}，返回：{}", order.getOrderNo(), resultJsonStr);
                // 检查状态
                JSONObject resultJsonObj = JSON.parseObject(resultJsonStr);
                String stateCode = resultJsonObj.getString("stateCode");
                if (!stateCode.equals("00")) {
                    throw new RException(resultJsonObj.getString("msg"));
                }
                String resultSign = resultJsonObj.getString("sign");
                resultJsonObj.remove("sign");
                String targetString = ToolKit.MD5(JSON.toJSONString(new TreeMap<>(resultJsonObj)) + md5Key, ToolKit.CHARSET);
                if (!targetString.equals(resultSign)) {
                    LogByMDC.error(channelNo, "订单：{}，同步返回信息签名错误", order.getOrderNo());
                    throw new RException("上游返回信息签名验证失败");
                }

                String merNo = resultJsonObj.getString("merNo");
                String orderNum = resultJsonObj.getString("orderNum");
                String remitResult = resultJsonObj.getString("remitResult");

                Integer orderState = order.getOrderState();
                //支付状态 00:支付成功 01:支付失败 03:签名错误 04:其他错误 05:未知 06:初始 50:网络异常 99:未支付
                switch (remitResult) {
                    case "00":
                        orderState = OrderState.succ.id();
                        break;
                    case "01":
                        orderState = OrderState.ing.id();
                        break;
                    case "02":
                        orderState = OrderState.fail.id();
                        break;
                    case "03":
                    case "04":
                    case "05":
                    case "50":
                    case "99":
                        break;
                    case "06":
                        orderState = OrderState.init.id();

                }
                order.setOrderState(orderState);

                orderAcpService.update(order);


            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
                LogByMDC.error(channelNo, "订单：{}，上游签名验证异常", order.getOrderNo());
                throw new RException("上游签名验证异常");
            }
        return order;
    }
}
