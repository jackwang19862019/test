package com.lee.paythird.richan;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.*;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 日产
 */
//经过与上海团队沟通，这个需要玩家自己打款，暂时不接
@Service(RiChan.channelNo)
public class RiChan extends AbstractPay {

    static final String channelNo = "richan";

    static final String payUrl = "http://cashwork.nissanpay.com/rockpay/gateway.do";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public RiChan() {
        payTypeMap.put(OutChannel.unionwap.name(), "11");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "日产支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());


        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> dataMap = new TreeMap<>();
        dataMap.put("version", "1.6");
        dataMap.put("cid", upMerchantNo);
        dataMap.put("tradeNo", orderNo);
        dataMap.put("amount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        dataMap.put("payType", payType);
        dataMap.put("orderName", product);
        dataMap.put("orderContent", product);
        dataMap.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        dataMap.put("requestTime", DateUtil.getCurrentNumStr());

        String signParams = SignatureUtils.buildParams(dataMap, false) + "&key=" + upMerchantKey;
        String sign = Md5Util.MD5(signParams);
        dataMap.put("sign", sign);

        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(dataMap), String.class);
        LogByMDC.info(channelNo, "日产支付响应 订单：{}，response：{}", orderNo, result);

        Map<String, String> params = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String retcode = params.get("retcode");
        if (!"0".equals(retcode)) {
            String retmsg = params.get("retmsg");
            LogByMDC.info(channelNo, "日产支付响应 订单：{}，上游支付失败：{}", orderNo, retmsg);
            return R.error(retmsg);
        }
        String status = params.get("status");
        if ("2".equals(status)) {
            params.put("status", "处理中");
        }
        params = doBusiness(params);
        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildForm(params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    private Map<String, String> doBusiness(final Map<String, String> params) {
        Map<String, String> nameMap = new LinkedHashMap<>();
        nameMap.put("status", "支付状态");
        nameMap.put("payeeName", "收款人姓名");
        nameMap.put("payeeBankName", "收款人开户行");
        nameMap.put("branchName", "收款行分/支行");
        nameMap.put("payeeAcctNo", "收款人账号");
        nameMap.put("postScript", "附言码");
        nameMap.put("rockTradeNo", "日产支付单号");
        nameMap.put("tradeNo", "商户单号");
        nameMap.put("amount", "订单金额");
        Map<String, String> newMap = new LinkedHashMap<>();
        newMap.put("请注意:","转账时，请务必填写您的姓氏、附言码、以及充值卡号末六位。");
        params.forEach((k, v) -> {
            if (nameMap.containsKey(k)) {
                if (nameMap.get(k).equals("订单金额")){
                    newMap.put(nameMap.get(k), new BigDecimal(v).multiply(new BigDecimal("0.01"))+"元");
                }else {
                    newMap.put(nameMap.get(k), v);
                }
            }
        });
        return newMap;
    }


    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "日产支付回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "日产支付订单：{}，重复回调", order.getOrderNo());
            return "SUCCESS";
        }
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String sign = params.remove("sign");
        //验签
        String signVerify = SignatureUtils.sign(params, upMerchantKey);
        if (!sign.equals(signVerify)) {
            LogByMDC.error(channelNo, "日产支付订单：{}，回调验签失败");
        }
        String trade_no = params.get("rockTradeNo");
        String trade_status = params.get("status");
        String amount = params.get("amount");

        if (!"1".equals(trade_status)) {
            LogByMDC.error(channelNo, "日产支付订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            return "SUCCESS";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(trade_no);

        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "日产支付订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "日产支付订单：{}，下发通知失败", order.getOrderNo());
        }
        return "SUCCESS";
    }

}
