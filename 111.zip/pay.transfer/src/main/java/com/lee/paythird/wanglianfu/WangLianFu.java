package com.lee.paythird.wanglianfu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 网联付
 */
@Service(WangLianFu.channelNo)
public class WangLianFu extends AbstractPay {

    public static final String channelNo = "wanglianfu";

    private final String payUrl = "http://www.wanglianfu.com/Pay_Index.html";

    private final String queryUrl = "http://www.wanglianfu.com/Pay_Pay_queryOrder.html";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public WangLianFu() {
        payTypeMap.put(OutChannel.quickpay.name(), "97");
        payTypeMap.put(OutChannel.alipay.name(), "101");
        payTypeMap.put(OutChannel.wechatpay.name(), "102");
        payTypeMap.put(OutChannel.wechath5.name(), "105");
        payTypeMap.put(OutChannel.alih5.name(), "104");
        payTypeMap.put(OutChannel.unionpay.name(), "107");
        payTypeMap.put(OutChannel.jdpay.name(), "109");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        SimpleDateFormat sdf = new SimpleDateFormat("yy-MM-dd HH:mm:ss");
        Date now = new Date();

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }


        Map<String, String> params = new TreeMap<>();
        //商户号
        params.put("pay_memberid", upMerchantNo);
        //订单号
        params.put("pay_orderid", orderNo);
        //金额
        params.put("pay_amount", amount);
        //订单时间
        params.put("pay_applydate", sdf.format(now));
        //通道编码
        params.put("pay_bankcode", payType);
        //服务器通知地址
        params.put("pay_notifyurl", getCallbackUrl(channelNo, merchNo, orderNo));
        //页面返回地址
        params.put("pay_callbackurl", returnUrl);

        String sign = SignatureUtils.sign(params, "&key=" + upMerchantKey);
        params.put("pay_md5sign", sign.toUpperCase());
//        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
//        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
//        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);


        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        Map<String, String> params = new HashMap<>();
        params.put("orderid", orderNo);
        params.put("pay_memberid", upMerchantNo);

        String sign = SignatureUtils.sign(params, "&key=" + upMerchantKey);
        params.put("sign", sign.toUpperCase());

        LogByMDC.info(channelNo, "查询订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(queryUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "查询订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>(){});
        String status = params.get("status");
        if ("10000".equals(status)) {
            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(order.getAmount());
            orderService.update(order);
        } else {
            LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", order.getOrderNo());
        }
        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "ok";
        }

        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String upSign = params.get("sign");
        params.remove("sign");
        params.remove("attach");

        String sign = SignatureUtils.sign(params, "&key=" + upMerchantKey).toUpperCase();
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return "fail";
        }

        String amount = params.get("amount");
        String transaction_id = params.get("transaction_id");
        String returncode = params.get("returncode");
        if (!"00".equals(returncode)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "ok";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(transaction_id);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }
        return "ok";
    }
}
