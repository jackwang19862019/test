package com.lee.paythird.fangte;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * @author lee
 * @date 2019-07-21 15:00
 */
@Service(FangTe.channelNo)
public class FangTe extends AbstractPay {

    public static final String channelNo = "fangte";

    private final String payUrl = "http://api.fengzikang.top/api/order/unified";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public FangTe() {
        payTypeMap.put(OutChannel.wechath5.name(), "903");
        payTypeMap.put(OutChannel.alipay.name(), "911");
        payTypeMap.put(OutChannel.wechatpay.name(), "912");
        payTypeMap.put(OutChannel.unionpay.name(), "906");
        payTypeMap.put(OutChannel.alih5.name(), "901");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        Map<String, String> params = new HashMap<>();
        //平台分配商户号
        params.put("appid", upMerchantNo);
        //上送订单号唯一, 字符长度20
        params.put("order_no", orderNo);
        //商品金额(单位分)
        params.put("amount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        //商品名称
        params.put("product_name", product);

        params.put("bank_code", payType);
        //异步通知地址
        params.put("notify_url", getCallbackUrl(channelNo, merchNo, orderNo));
        //同步通知地址
        params.put("return_url", returnUrl);

        params.put("sign", sign(params, upMerchantKey));

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>(){});

        String status = params.get("status");
        if (!"1".equals(status)) {
            String message = params.get("message");
            LogByMDC.info("订单：{}，上游返回：{}", orderNo, message);
            return R.error("上游返回：" + message);
        }

        String data = params.get("data");
        params = JSON.parseObject(data, new TypeReference<Map<String, String>>(){});

        String platform_order_no = params.get("platform_order_no");
        String redirect_url = params.get("redirect_url");

        String upAmount = params.get("amount");

        saveOrder(jObj, channelNo, upMerchantNo, platform_order_no);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), new BigDecimal(upAmount).multiply(new BigDecimal("0.01")).toString());
        returnMap.put(PayConstants.web_code_url, redirect_url);
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "SUCCESS";
        }

        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String upSign = params.get("sign");
        params.remove("sign");

        String sign = sign(params, upMerchantKey);

        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return "FAIL";
        }

        String pay_status = params.get("pay_status");
        if (!"1".equals(pay_status)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "SUCCESS";
        }

        String amount = params.get("amount");
        String platform_order_no = params.get("platform_order_no");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(platform_order_no);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }
        return "SUCCESS";
    }


    private String sign(Map<String, String> params, String key) {
        Map<String, String> map = new TreeMap<>(params);
        map.put("secret", key);

        StringBuffer sb = new StringBuffer();

        Set<String> keySet = map.keySet();
        for (String keyName : keySet) {
            String value = map.get(keyName);
            sb.append(keyName).append("=");
            sb.append(value);
            sb.append("&");
        }

        sb.setLength(sb.length() - 1);

        return SignatureUtils.sign(sb.toString(), "").toLowerCase();
    }
}
