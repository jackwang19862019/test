package com.lee.paythird.guolian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.*;
import com.lee.pay.api.OrderReqParams;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 国联
 */
@Service(GuoLian.channelNo)
public class GuoLian extends AbstractPay<OrderReqParams> {

    static final String channelNo = "guolian";

    private static final String payUrl = "http://www.guolianzhifu.com/api/pay/index/getOrder";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public GuoLian() {
        payTypeMap.put(OutChannel.alipay.name(), "1");
        payTypeMap.put(OutChannel.alih5.name(), "2");
        payTypeMap.put(OutChannel.aliwap.name(), "3");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "国联支付请求：{}", jObj.toJSONString());
        OrderReqParams reqParams = JsonToBean(jObj, OrderReqParams.class);
        Map<String, String> params = getParamsMap(merchantChannel, reqParams);

        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "国联支付响应 订单：{}，response：{}", reqParams.getOrderNo(), result);

        Assert.isTrue(isJSONValid(result), "国联支付直接响应:" + result);
        Map<String, String> resultMap = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String ret = resultMap.get("ret");
        Assert.isTrue("1".equals(ret), "国联上游支付状态响应:" + result);
        String qrCode = resultMap.get("msg");

        saveOrder(jObj, channelNo, merchantChannel.getUpMerchantNo());

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), reqParams.getOrderNo());
        returnMap.put(OrderParamKey.outChannel.name(), reqParams.getOutChannel());
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), reqParams.getAmount());
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }

    private static boolean isJSONValid(String test) {
        try {
            JSONObject.parseObject(test);
        } catch (JSONException ex) {
            try {
                JSONObject.parseArray(test);
            } catch (JSONException ex1) {
                return false;
            }
        }
        return true;
    }

    private Map<String, String> getParamsMap(MerchantChannelEntity merchantChannel, OrderReqParams reqParams) {
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upPublicKey = merchantChannel.getUpPublicKey();
        String payType = payTypeMap.get(reqParams.getOutChannel());
        Assert.notNull(payType, "不支持的支付方式:" + reqParams.getOutChannel());
        String merchNo = reqParams.getMerchNo();
        String orderNo = reqParams.getOrderNo();
        String amount = reqParams.getAmount();

        Map<String, String> params = new TreeMap<>();
        params.put("app_id", upMerchantNo);
        params.put("order_num_cp", orderNo);
        params.put("pay_type", payType);
        params.put("money", amount);
        params.put("nonce_str", MatchUtils.generateShortUuid());
        params.put("return_url", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("time", System.currentTimeMillis() + "");
        params.put("ip", reqParams.getReqIp());
        params.put("rt_type", "2");

        String buildParams = SignatureUtils.buildParams(params) + upPublicKey;
        String sign = Md5Utils.MD5(buildParams);
        params.put("sign", sign);
        return params;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "国联支付回调内容：{}", params);
        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "国联支付订单：{}，重复回调", order.getOrderNo());
            return "SUCCESS";
        }

        String upMerchantKey = merchantChannel.getUpPublicKey();
        String sign = params.remove("sign");
        //验签
        boolean signVerify = verifySignParams(params, sign, upMerchantKey);

        if (!signVerify) {
            LogByMDC.error(channelNo, "国联支付订单：{}，回调验签失败", order.getOrderNo());
            return "FAIL";
        }
        String trade_no = params.get("trade_no");
        String trade_status = params.get("pay_result");
        String amount = params.get("money");

        if (!"1".equals(trade_status)) {
            LogByMDC.error(channelNo, "国联支付订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            return "SUCCESS";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(trade_no);
        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "国联支付订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "国联支付订单：{}，下发通知失败{}", order.getOrderNo(), e.getMessage());
        }
        return "SUCCESS";
    }

    private boolean verifySignParams(Map<String, String> params, String sign, String upMerchantKey) {
        TreeMap<String, String> treeMap = new TreeMap<>(params);
        String orderNo = treeMap.get("order_num_cp");
        LogByMDC.info(channelNo, "国联支付订单:{}，参与验签参数:{}", orderNo, JSON.toJSONString(params));
        String buildParams = SignatureUtils.buildParams(params) + upMerchantKey;
        String newSign = Md5Utils.MD5(buildParams);
        return newSign.equals(sign);
    }

}
