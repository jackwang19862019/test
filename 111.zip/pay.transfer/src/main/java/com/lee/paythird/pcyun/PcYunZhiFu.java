package com.lee.paythird.pcyun;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * PC云
 */
@Service(PcYunZhiFu.channelNo)
public class PcYunZhiFu extends AbstractPay {

    public static final String channelNo = "pcyunzhifu";

    static final String payUrl = "http://gateway.188pc.cn/Pay";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public PcYunZhiFu() {
        payTypeMap.put(OutChannel.alipay.name(), "alipay");
        payTypeMap.put(OutChannel.wechatpay.name(), "wxpay");
        payTypeMap.put(OutChannel.qqpay.name(), "qqpay");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "PC云支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());


        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> dataMap = new TreeMap<>();
        dataMap.put("pid", upMerchantNo);
        dataMap.put("type", payType);
        dataMap.put("out_trade_no", orderNo);

        dataMap.put("notify_url", getCallbackUrl(channelNo, merchNo, orderNo));
        dataMap.put("return_url", returnUrl);
        dataMap.put("name", product);
        dataMap.put("money", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));

        String sign = SignatureUtils.sign(dataMap, upMerchantKey);
        dataMap.put("sign", sign);
        dataMap.put("sign_type", "MD5");
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(dataMap), String.class);
        LogByMDC.info(channelNo, "PC云支付响应 订单：{}，response：{}", orderNo, result);
        saveOrder(jObj, channelNo, upMerchantNo);
        String qrCode = null;
        if (!StringUtils.isEmpty(result)) {
            JSONObject jsonObject = JSONObject.parseObject(result);
            String errmsg = jsonObject.getString("errmsg");
            LogByMDC.warn(channelNo, "PC云支付返回 订单：{}，response：{}", orderNo, errmsg);
            return R.error(errmsg);
        }

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }


    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "PC云支付回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "PC云支付订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        String upMerchantKey = merchantChannel.getUpPublicKey();

        String sign = params.get("sign");
        params.remove("sign");
        params.remove("sign_type");
        //验签
        String signVerify = SignatureUtils.sign(params, upMerchantKey);
        if (!sign.equals(signVerify)) {
            LogByMDC.error(channelNo, "PC云支付订单：{}，回调验签失败", order.getOrderNo());
            return "fail";
        }
        String trade_no = params.get("trade_no");
        String trade_status = params.get("trade_status");
        String amount = params.get("money");

        if (!"TRADE_SUCCESS".equals(trade_status)) {
            LogByMDC.error(channelNo, "PC云支付订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            return "success";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(trade_no);

        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "PC云支付订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "PC云支付订单：{}，下发通知失败", order.getOrderNo());
        }
        return "success";
    }

}
