package com.lee.paythird.vfeifu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

@Service(VFeiFu.channelNo)
public class VFeiFu extends AbstractPay {

    public static final String channelNo = "vfeifu";


    private final String payUrl = "http://www.vfeifu.com/api/v1/recharge.action";

    private final String queryUrl = "http://www.vfeifu.com/api/v1/query.action";


    private final Map<String, String> payTypeMap = new HashMap<>();

    public VFeiFu() {
        payTypeMap.put(OutChannel.alih5.name(), "alipay_wap");
        payTypeMap.put(OutChannel.alipay.name(), "alipay_qr");
        payTypeMap.put(OutChannel.aliwap.name(), "alipay_pc");

        payTypeMap.put(OutChannel.wechath5.name(), "wx_wap");
        payTypeMap.put(OutChannel.wechatpay.name(), "wx_qr");

        payTypeMap.put(OutChannel.unionwap.name(), "upacp_pc");
        payTypeMap.put(OutChannel.unionh5.name(), "upacp_wap");
        payTypeMap.put(OutChannel.unionpay.name(), "upacp_qr");

        //聚合支付
        payTypeMap.put("juhe", "juhe");

    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        Map<String, String> params = new TreeMap<>();
        //"商户号。
        //咨询市场经理。
        //必填。"
        params.put("app_id", merchantChannel.getUpMerchantNo());
        //"支付使用的第三方支付渠道，详情参考3.1支付渠道属性。
        //必填。"
        params.put("channel", payType);
        //"商户订单号，适配每个渠道对此参数的要求，必须在商户的系统内唯一。
        //推荐使用 8-30 位，要求数字或字母，不允许特殊字符。"
        params.put("order_no", orderNo);
        //发起支付请求客户端的 IP 地址，格式为 IPv4 整型，如 127.0.0.1。
        params.put("client_ip", reqIp);
        //订单总金额（必须大于 0），单位为对应币种的最小货币单位，人民币为分。如订单总金额为 1 元， amount 为 100。
        params.put("amount", new BigDecimal(amount).multiply(new BigDecimal("100")).intValue() + "");
        //"商品标题，该参数最长为 32 个 Unicode 字符。
        //不允许特殊字符。"
        params.put("subject", product);
        //"商品描述信息，该参数最长为 100 个 Unicode 字符。 
        //不允许特殊字符。"
        params.put("body", product);
        //支付结果异步通知url 。详细参考2.1支付异步通知。
        params.put("notify_url", getCallbackUrl(channelNo, merchNo, orderNo));
        //支付操作完成后界面返回url。
        params.put("return_url", returnUrl);

        String sign = SignatureUtils.sign(params, "&key=" + merchantChannel.getUpPublicKey());
        params.put("sign", sign);
        LogByMDC.info(channelNo, "通道：{}，订单：{}，request：{}", channelNo, orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "通道：{}，订单：{}，response：{}", channelNo, orderNo, result);

        JSONObject jsonObject = JSON.parseObject(result);
        String code = jsonObject.getString("code");
        if (!"200".equals(code)) {
            String msg = jsonObject.getString("msssage");
            LogByMDC.error(channelNo, "通道：{}，订单：{}，请求失败，上游返回：{}", channelNo, orderNo, msg);
            return R.error("请求失败，上游返回：" + msg);
        }

        String data = jsonObject.getString("data");
        Map<String, String> resultMap = JSON.parseObject(data, new TypeReference<Map<String, String>>() {
        });
        String upSign = resultMap.get("sign");
        resultMap.remove("sign");

        sign = SignatureUtils.sign(resultMap, "&key=" + merchantChannel.getUpPublicKey());
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，验证上游返回签名失败", channelNo, orderNo);
            return R.error("验证上游返回签名失败");
        }

        String transaction_no = resultMap.get("transaction_no");

        saveOrder(jObj, channelNo, merchantChannel.getUpMerchantNo(), transaction_no);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);

        String urlType = resultMap.get("url_type");

        String url = resultMap.get("url");
        switch (urlType) {
            case "url":
                returnMap.put(PayConstants.web_code_url, url);
                break;
            case "html":
                returnMap.put(PayConstants.pay_form, url);
                break;
            case "imgurl":
            case "imgbase64":
                returnMap.put(PayConstants.web_qrcode_url, url);
                break;
        }

        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        String orderNo = order.getOrderNo();
        Map<String, String> params = new HashMap<>();
        //"商户号。
        //咨询市场经理。"
        params.put("app_id", merchantChannel.getUpMerchantNo());
        //"平台交易流水号。32 个 Unicode 字符。
        //必填。"。
        params.put("transaction_no", order.getBusinessNo());

        String sign = SignatureUtils.sign(params, "&key=" + merchantChannel.getUpPublicKey());
        params.put("sign", sign);
        LogByMDC.info(channelNo, "通道：{}，订单：{}，queryrequest：{}", channelNo, orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(queryUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "通道：{}，订单：{}，queryresponse：{}", channelNo, order.getOrderNo(), result);
        JSONObject jsonObject = JSON.parseObject(result);
        String code = jsonObject.getString("code");
        if (!"200".equals(code)) {
            String msg = jsonObject.getString("msssage");
            LogByMDC.error(channelNo, "通道：{}，订单：{}，请求失败，上游返回：{}", channelNo, orderNo, msg);
            throw new RException("请求失败，上游返回：" + msg);
        }

        String data = jsonObject.getString("data");
        Map<String, String> resultMap = JSON.parseObject(data, new TypeReference<Map<String, String>>() {
        });
        String upSign = resultMap.get("sign");
        resultMap.remove("sign");

        sign = SignatureUtils.sign(resultMap, "&key=" + merchantChannel.getUpPublicKey());
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，验证上游返回签名失败", channelNo, orderNo);
            throw new RException("验证上游返回签名失败");
        }

        //"实际支付金额。
        //特定支付通道需要用户多支付几分钱识别归属的订单，最终用户支付金额以通知为准。
        //单位为对应币种的最小货币单位，人民币为分。如金额为1元，值为100。"
        String amount = resultMap.get("amount");
        String transaction_no = resultMap.get("transaction_no");
        //"是否已充值成功。
        //0处理中，或状态未知
        //1 成功
        //2 失败"
        String succeeded = resultMap.get("succeeded");

        if ("1".equals(succeeded)) {
            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
            orderService.update(order);
        } else {
            LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", order.getOrderNo());
        }

        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        String orderNo = order.getOrderNo();


        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }

        String upSign = params.get("sign");
        params.remove("sign");

        String sign = SignatureUtils.sign(params, "&key=" + merchantChannel.getUpPublicKey());
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，验证上游返回签名失败", channelNo, orderNo);
            return "success";
        }

        String succeeded = params.get("succeeded");
        if (!"1".equals(succeeded)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，支付未成功，不再向下通知", channelNo, orderNo);
            return "success";
        }

        //"实际支付金额。
        //特定支付通道需要用户多支付几分钱识别归属的订单，最终用户支付金额以通知为准。
        //单位为对应币种的最小货币单位，人民币为分。如金额为1元，值为100。"
        String amount = params.get("amount");

        String transaction_no = params.get("transaction_no");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(transaction_no);

        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "success";
    }
}
