package com.lee.paythird.lf;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 隆发
 */
@Service(LongFa.channelNo)
public class LongFa extends AbstractPay {

    public static final String merchNo_ = "LFP201907091301";
    public static final String channelNo = "longfa";
    static String key = "5C2CC9666A6C72D7F559A988919AB65F";
    static String reqUrl = "http://pay.longfapay.com:88/api/pay";
    static String version = "V3.6.0.0";

    private final static String rsaPublicKey =
                    "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCWRkhnlMBhS+Vq01vFL3/BCLb4f8gbGdBlUEYB" +
                    "HnRUAtk1HmklZXjpCq5xp/YQXppVAgEbDugkCpQRbNE/psfD7TpV6Sa5HpZGf3II/GKlDPm2C7Vi" +
                    "IJZJIyla9yWKpHsTTJ54+NXkk4mlvKc9MEor+OVIg0XZhFzjHFGiYxrYgQIDAQAB";

    private final static String rsaPrivateKey =
            "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAKBt7HNapPnq5xvKycGvpdiUXj/X" +
                    "ciqcm1x+BVvJaz9FeRrM0LRcSsIIvRP1jsjtTqZYK6JjswmrU2B7EacNHIxGwOoPrxiOk9zA/ciq" +
                    "UlLiynPTfBoVSKAqUTnzPsU7RFQBQk8GPzqbBUAQQtndV+4KgBJZ+KqLN9DDjRZTmYl3AgMBAAEC" +
                    "gYEAjeiONn+g3RzHb5MSooxvxEOBlzFJYJ4E42zp6oYhouceN/GiT1gwHLDEJ8qXke4wGv51IoDU" +
                    "VyJAb2CNfdogPB8YRPW0rEFudrwbgtigDAtReHEL3tdwjlfq8UmzEQ3tbal/ZI/HdsFtCR+3j3Vg" +
                    "AafK4iR2S9WxvXu4GDlhprECQQDpkndTrJFGiHbS4aAmFuzkbYNPUkUuMBoY8HSNzvBklC1clGyj" +
                    "EFIiTycVk1Z/tkM3uKC4o47Ej5bb/laAoHb5AkEAr9WBWNmmUi9VuIr12eTi0I7ZqCFe/5/7J/OL" +
                    "d/3GqKvVe18o9pSViz8GyVINWA+V+M2JyeMXKCsx9mf0enjv7wJARcaFcy+oLoPxy0mvx/EtT4gP" +
                    "pBCVrhickzqx9vMNCV7itjd4xLXJc4plyKI9QuW16t1y1fW2Xq3uiUXPnZlSMQJBAItoQ30mUu+m" +
                    "B9igk/uFtS6Vk4vxqVgShxZNya4Azpi8ZC3EbL3TYB1egwrquxmugcEZdL1UBvAaDyrFkNfpOpEC" +
                    "QDpqOq1H2ke/gb5p7UIW39FeWnVPIQXlWobGq7A9DsJLATaFqlxj4Iiz3daRhV7Dy5FIi8dmXP+j" +
                    "XI9zZ+A+Shk=";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public LongFa() {
        payTypeMap.put(OutChannel.alipay.name(), "ZFB");
        payTypeMap.put(OutChannel.aliwap.name(), "ZFB_WAP");
        payTypeMap.put(OutChannel.wechatpay.name(), "WX");
        payTypeMap.put(OutChannel.wechath5.name(), "1001");
        payTypeMap.put(OutChannel.qqpay.name(), "QQ");
        payTypeMap.put(OutChannel.qqwap.name(), "QQ_WAP");
        payTypeMap.put(OutChannel.jdh5.name(), "JD");
        payTypeMap.put(OutChannel.jdwap.name(), "JD_WAP");
        payTypeMap.put(OutChannel.baidupay.name(), "BAIDU");
        payTypeMap.put(OutChannel.unionsm.name(), "UNION_WALLET");
    }


    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "隆发支付 开始支付：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("隆发支付 不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> metaSignMap = new TreeMap<>();
        metaSignMap.put("orderNo", orderNo);
        metaSignMap.put("randomNo", ToolKit.randomStr(4));

        metaSignMap.put("merchNo", merchNo_);
        metaSignMap.put("netwayType", payType);
        metaSignMap.put("amount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        metaSignMap.put("goodsName", product);
        metaSignMap.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        metaSignMap.put("notifyViewUrl", returnUrl);

        String metaSignJsonStr = ToolKit.mapToJson(metaSignMap);
        String sign = ToolKit.MD5(metaSignJsonStr + key, ToolKit.CHARSET);
        metaSignMap.put("sign", sign);

        Map<String, String> returnMap = new HashMap<>();
        try {
            byte[] dataStr = ToolKit.encryptByPublicKey(ToolKit.mapToJson(metaSignMap)
                    .getBytes(ToolKit.CHARSET), rsaPublicKey);
            String param = new BASE64Encoder().encode(dataStr);
            String reqParam = "data=" + URLEncoder.encode(param, ToolKit.CHARSET) + "&merchNo=" + merchNo_ + "&version=" + version;

            LogByMDC.info(channelNo, "隆发支付 订单：{}，request：{}", orderNo, JSON.toJSONString(metaSignMap));
            String resultJsonStr = ToolKit.request(reqUrl, reqParam);
            LogByMDC.info(channelNo, "隆发支付 订单：{}，response：{}", orderNo, resultJsonStr);

            JSONObject resultJsonObj = JSONObject.parseObject(resultJsonStr);
            String stateCode = resultJsonObj.getString("stateCode");
            if (!stateCode.equals("00")) {
                String errMsg = resultJsonObj.getString("msg");
                LogByMDC.error(channelNo, "隆发支付 订单：{}，上游返回：{}", orderNo, errMsg);
                return R.error("隆发支付 上游返回：" + errMsg);
            }
            //开始验签
            String resultSign = resultJsonObj.getString("sign");
            resultJsonObj.remove("sign");
            String targetString = ToolKit.MD5(resultJsonObj.toString() + key, ToolKit.CHARSET);
            if (targetString.equals(resultSign)) {
                throw new RException("隆发支付 同步返回数据验签失败");
            }
            saveOrder(jObj, channelNo, upMerchantNo);
            String qrCodeUrl = resultJsonObj.getString("qrcodeUrl");

            returnMap.put(OrderParamKey.orderNo.name(), orderNo);
            returnMap.put(OrderParamKey.outChannel.name(), outChannel);
            returnMap.put(OrderParamKey.merchNo.name(), merchNo);
            returnMap.put(OrderParamKey.channelNo.name(), channelNo);
            returnMap.put(PayConstants.web_code_url, qrCodeUrl);
            returnMap.put(OrderParamKey.amount.name(), amount);
        } catch (UnsupportedEncodingException e) {
            LogByMDC.error(channelNo, "隆发支付 订单：{}，失败", orderNo);
        }
        return R.ok().put(Constant.result_data, returnMap);
    }


    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "隆发支付 回调内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.info(channelNo, "隆发支付 订单：{}，重复回调", order.getOrderNo());
            return "SUCCESS";
        }

        String orderNo = order.getOrderNo();
        //开始解密异步返回的数据
        String pay_result = params.get("data");
        LogByMDC.info(channelNo, "隆发支付 订单：{}，解密数据前data{}", orderNo, pay_result);
        try {
            byte[] result = ToolKit.decryptByPrivateKey(new BASE64Decoder().decodeBuffer(pay_result), rsaPrivateKey);
            String resultData = new String(result, ToolKit.CHARSET);
            JSONObject jsonObject = JSON.parseObject(resultData);
            LogByMDC.info(channelNo, "隆发支付 订单：{}，解密数据后data{}", orderNo, result);
            if (!checkSignForLongFa(JSONObject.parseObject(JSON.toJSONString(jsonObject)))) {
                LogByMDC.error(channelNo, "隆发支付 订单：{}，异步返回数据验签失败", orderNo);
                throw new RException("隆发支付 异步返回数据验签失败{}");
            }
            //这个也是第三方支付单号，上游没有返回，只能拿这个
            String sys_no = jsonObject.get("orderNo").toString();
            //实际支付金额，单位:分
            String amount_pay = jsonObject.get("amount").toString();

            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(amount_pay).multiply(new BigDecimal("0.01")));
            order.setBusinessNo(sys_no);
            orderService.update(order);
        } catch (Exception e) {
            LogByMDC.error(channelNo, "订单：{}，解密/更新数据失败", order.getOrderNo());
            throw new RException("解密/更新数据失败");
        }
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "隆发支付 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "隆发订单：{}，下发通知失败", order.getOrderNo());
        }
        return "SUCCESS";
    }

    private boolean checkSignForLongFa(JSONObject jsonObj) {
        Map<String, String> metaSignMap = new TreeMap<>();
        metaSignMap.put("merchNo", jsonObj.getString("merchNo"));
        metaSignMap.put("netwayType", jsonObj.getString("netwayType"));
        metaSignMap.put("orderNo", jsonObj.getString("orderNo"));
        metaSignMap.put("amount", jsonObj.getString("amount"));
        metaSignMap.put("goodsName", jsonObj.getString("goodsName"));
        metaSignMap.put("payStateCode", jsonObj.getString("payStateCode"));// 支付状态
        metaSignMap.put("payDate", jsonObj.getString("payDate"));// yyyyMMddHHmmss
        String jsonStr = ToolKit.mapToJson(metaSignMap);
        String sign = ToolKit.MD5(jsonStr + key, ToolKit.CHARSET);
        return sign.equals(jsonObj.getString("sign"));
    }

}
