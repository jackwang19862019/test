package com.lee.paythird.kuaifu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.*;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * 快付
 */
@Service(KuaiFu.channelNo)
public class KuaiFu extends AbstractPay {

    public static final String channelNo = "kuaifu";

    private final String payUrl = "http://ban.paykuaifu.com/cgi-bin/netpayment/pay_gate.cgi";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public KuaiFu() {
        payTypeMap.put(OutChannel.alih5.name(), "9");
        payTypeMap.put(OutChannel.aliwap.name(), "10");
        payTypeMap.put(OutChannel.wechatwap.name(), "11");
        payTypeMap.put(OutChannel.wechath5.name(), "13");
        payTypeMap.put(OutChannel.qqwap.name(), "14");
        payTypeMap.put(OutChannel.qqh5.name(), "15");
        payTypeMap.put(OutChannel.alipay.name(), "16");
        payTypeMap.put(OutChannel.wechatpay.name(), "18");
        payTypeMap.put(OutChannel.unionwap.name(), "19");
        payTypeMap.put(OutChannel.jdwap.name(), "20");
        payTypeMap.put(OutChannel.jdh5.name(), "21");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "进入快付支付订单：{}", JSON.toJSONString(jObj));
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }


        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new LinkedHashMap<>();
        params.put("apiName", "WEB_PAY_B2C");
        params.put("apiVersion", "1.0.0.0");
        params.put("platformID", upMerchantNo);
        params.put("merchNo", upMerchantNo);
        params.put("orderNo", orderNo);

        String currentDateStr = DateUtil.getCurrentDateStr();
        params.put("tradeDate", currentDateStr);

        params.put("amt", String.valueOf(new BigDecimal(amount)));
        params.put("merchUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("tradeSummary", "支付描述");

        String signParams = SignatureUtils.buildParams(params, false) + upMerchantKey;
        String sign = Md5Util.MD5(signParams);
        params.put("signMsg", sign);
        params.put("choosePayType", payType);

        /*LogByMDC.info(channelNo, "快付支付订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "快付支付订单：{}，response：{}", orderNo, result);*/
        saveOrder(jObj, channelNo, upMerchantNo);

        LogByMDC.info(channelNo, "快付支付pay_form直接给下游：{}，response：{}", orderNo, JSON.toJSONString(params));
        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        returnMap.put(OrderParamKey.amount.name(), amount);
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "快付支付回调内容：{}", params);
        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "快付支付回调订单：{}，重复回调", orderNo);
            return "SUCCESS";
        }
        String upSign = params.remove("sign");
        String sign = verifySign(params, upMerchantKey);
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "快付支付回调订单：{}，验证回调签名错误", orderNo);
            return "";
        }

        String status = params.get("orderStatus");
        if (!"1".equals(status)) {
            LogByMDC.error(channelNo, "快付支付回调订单：{}，支付未成功，不再向下通知", orderNo);
            return "";
        }

        String price = params.get("tradeAmt");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(price));
        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.error(channelNo, "快付支付回调订单：{}，下发通知成功",order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "快付支付回调订单：{}，下发通知失败", order.getOrderNo());
        }

        return "SUCCESS";
    }

    private String verifySign(Map<String, String> params, String upMerchantKey) {
        LogByMDC.error(channelNo, "快付支付回调验签参数", JSON.toJSONString(params));
        String apiName = params.get("apiName");
        String notifyTime = params.get("notifyTime");
        String tradeAmt = params.get("tradeAmt");
        String merchNo = params.get("merchNo");
        String merchParam = params.get("merchParam");
        String orderNo = params.get("orderNo");
        String tradeDate = params.get("tradeDate");
        String accNo = params.get("accNo");
        String accDate = params.get("accDate");
        String orderStatus = params.get("orderStatus");
        StringBuilder sb = new StringBuilder();
        sb.append("apiName=" + apiName);
        sb.append("&notifyTime=" + notifyTime);
        sb.append("&tradeAmt=" + tradeAmt);
        sb.append("&merchNo=" + merchNo);
        sb.append("&merchParam=" + merchParam);
        sb.append("&orderNo=" + orderNo);
        sb.append("&tradeDate=" + tradeDate);
        sb.append("&accNo=" + accNo);
        sb.append("&accDate=" + accDate);
        sb.append("&orderStatus=" + orderStatus);
        String signStr = sb.toString() + upMerchantKey;
        String sign = Md5Util.MD5(signStr);
        return sign;
    }

}

