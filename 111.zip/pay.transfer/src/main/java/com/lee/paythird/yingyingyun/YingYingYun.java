package com.lee.paythird.yingyingyun;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * 赢赢云
 */
@Service(YingYingYun.channelNo)
public class YingYingYun extends AbstractPay {

    public static final String channelNo = "yingyingyun";

    private final String payUrl = "http://gateway.winner-winner.cn/order/pay";

    private final String queryUrl = "http://gateway.winner-winner.cn/payapi/query/orderstatus";

    private final Map<String, String> payTypeMap = new HashMap<>();

    private DecimalFormat df = new DecimalFormat("#.00");

    public YingYingYun() {
        payTypeMap.put(OutChannel.alipay.name(), "ALIPAY");
        payTypeMap.put(OutChannel.alih5.name(), "ALIPAYH5");
        payTypeMap.put(OutChannel.wechatpay.name(), "WEIXIN");
        payTypeMap.put(OutChannel.wechath5.name(), "WEIXINH5");
        payTypeMap.put(OutChannel.qqpay.name(), "QQ");
        payTypeMap.put(OutChannel.qqh5.name(), "QQH5");
        payTypeMap.put(OutChannel.jdpay.name(), "JD");
        payTypeMap.put(OutChannel.jdh5.name(), "JDH5");
        payTypeMap.put(OutChannel.unionpay.name(), "YINLIAN");
        payTypeMap.put(OutChannel.quickpay.name(), "KUAIJIE");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new HashMap<>();
        //Account ID，由赢赢云分配
        params.put("accountid", upMerchantNo);
        //通道类型
        params.put("type", payType);
        //单位元(人民币)，2 位小数，最小支付 金额为 0.02
        params.put("amount", df.format(new BigDecimal(amount)));
        //订单号
        params.put("orderid", orderNo);
        //异步通知地址
        params.put("notifyurl", getCallbackUrl(channelNo, merchNo, orderNo));

        String sign = SignatureUtils.sign(params, "&authtoken=" + upMerchantKey);

        //支付用户 IP
        params.put("clientip", reqIp);

        params.put("sign", sign.toUpperCase());

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));

        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        Map<String, String> params = new HashMap<>();
        params.put("accountid", upMerchantNo);
        params.put("orderid", orderNo);

        String sign = SignatureUtils.sign(params, "&authtoken=" + upMerchantKey).toUpperCase();
        params.put("sign", sign);

        LogByMDC.info(channelNo, "查询订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(queryUrl, params, String.class);
        LogByMDC.info(channelNo, "查询订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>() {});

        String code = params.get("code");
        if (!"000000".equals(code)) {
            String errMsg = params.get("msg");
            LogByMDC.error(channelNo, "订单：{}，上游返回：{}", orderNo, errMsg);
            throw new RException("上游返回：" + errMsg);
        }
        String status = params.get("status");
        if ("2".equals(status)) {
            String platformorderid = params.get("platformorderid");
            String amount = params.get("amount");

            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(amount));
            orderService.update(order);
        } else {
            LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", order.getOrderNo());
        }


        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put("code", "success");
        resultMap.put("msg", "");
        String result = JSON.toJSONString(resultMap);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return result;
        }

        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String upSign = params.get("sign");
        params.remove("sign");
        params.remove("desc");
        params.remove("completetime");

        String platformorderid = params.get("platformorderid");
        params.remove("platformorderid");

        String sign = SignatureUtils.sign(params, "&authtoken=" + upMerchantKey).toUpperCase();
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return result;
        }

        String amount = params.get("amount");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(platformorderid);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return result;
    }
}
