package com.lee.paythird.utils;

import java.util.Map;
import java.util.Set;

public class BuildFormUtils {

    public static String buildForm(Map<String, String> params) {
        StringBuffer sb = new StringBuffer();
        sb.append("<form>");
        Set<String> keySet = params.keySet();
        for (String key : keySet) {
            sb.append("<p>");
            sb.append(key);
            sb.append("：");
            sb.append(params.get(key));
            sb.append("</p>");
        }

        sb.append("</form>");
        return sb.toString();
    }


    public static String buildSubmitForm(String url, Map<String, String> params) {
        StringBuffer sb = new StringBuffer();
        sb.append("<form id=\"form\"");
        sb.append(" action=\"");
        sb.append(url);
        sb.append("\" method=\"post\">");
        Set<String> keySet = params.keySet();
        for (String key : keySet) {
            sb.append("<input type=\"hidden\" name=\"");
            sb.append(key);
            sb.append("\" value=\"");
            sb.append(params.get(key));
            sb.append("\">");
        }

        sb.append("</form>");
        sb.append("<script>document.getElementById('form').submit()</script>");
        return sb.toString();
    }
}
