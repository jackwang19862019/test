package com.lee.paythird.xinba;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.Md5Util;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 辛巴
 */
@Service(XinBa.channelNo)
public class XinBa extends AbstractPay {

    static final String channelNo = "xinba";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public XinBa() {
        payTypeMap.put(OutChannel.alipay.name(), "ALIPAY_QR");
        payTypeMap.put(OutChannel.alih5.name(), "ALIPAY_H5");

        payTypeMap.put(OutChannel.wechatpay.name(), "WEIXIN_QR");
        payTypeMap.put(OutChannel.wechath5.name(), "WEIXIN_H5");

        payTypeMap.put(OutChannel.unionpay.name(), "UNIONPAY_QR");
        payTypeMap.put(OutChannel.quickpay.name(), "UNIONPAY_BC");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "辛巴支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());


        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        String payUrl = getPayUrlByType(payType);

        Map<String, String> dataMap = new TreeMap<>();

        dataMap.put("orderId", orderNo);
        dataMap.put("totalAmount", amount);
        dataMap.put("payType", payType);
        dataMap.put("extendField", product);
        dataMap.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        dataMap.put("appId", upMerchantNo);

        String signParams = SignatureUtils.buildParams(dataMap, false) + "&key=" + upMerchantKey;
        System.out.println("签名串：" + signParams);
        LogByMDC.info(channelNo, "辛巴支付签名 订单：{}，参与签名参数：{}", orderNo, signParams);
        String sign = Md5Util.MD5(signParams);
        dataMap.put("sign", sign.toUpperCase());

        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, dataMap));
        return R.ok().put(Constant.result_data, returnMap);
    }

    private String getPayUrlByType(String payType) {
        if (payType.contains("H5") || payType.contains("BC")) {
            return "http://apis.simbarpay.com/qrcode/pay";
        } else {
            return "http://apis.simbarpay.com/qrcode/pay";
        }
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        Map<String, String> resp = new TreeMap<>();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        LogByMDC.info(channelNo, "辛巴回调内容：{}", params);
        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "辛巴订单：{}，重复回调", order.getOrderNo());
            resp.put("rspCode", "success");
            resp.put("rspMsg", "重复回调");
            resp.put("sign",SignatureUtils.sign(resp, upMerchantKey).toUpperCase());
            return JSON.toJSONString(resp);
        }

        String sign = params.remove("sign");
        //验签
        String signVerify = SignatureUtils.buildParams(params, true) + "&key=" + upMerchantKey;
        LogByMDC.info(channelNo, "辛巴回调签名 订单：{}，参与验签参数：{}", order.getOrderNo(), signVerify);
        signVerify = Md5Util.MD5(signVerify);

        if (!sign.equals(signVerify)) {
            LogByMDC.error(channelNo, "辛巴订单：{}，回调验签失败,验签参数:{}", order.getOrderNo(), signVerify);
            resp.put("rspCode", "fail");
            resp.put("rspMsg", "验签失败");
            resp.put("sign",SignatureUtils.sign(resp, upMerchantKey).toUpperCase());
            return JSON.toJSONString(resp);
        }
        String trade_no = params.get("transactionId");
        String trade_status = params.get("orderState");
        String amount = params.get("payAmount");

        if (!"000000".equals(trade_status)) {
            LogByMDC.error(channelNo, "辛巴订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            resp.put("rspCode", "fail");
            resp.put("rspMsg", "支付未成功");
            resp.put("sign",SignatureUtils.sign(resp, upMerchantKey).toUpperCase());
            return JSON.toJSONString(resp);
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(trade_no);

        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "辛巴订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "辛巴订单：{}，下发通知失败", order.getOrderNo());
        }
        resp.put("rspCode", "success");
        resp.put("rspMsg", "回调成功");
        resp.put("sign",SignatureUtils.sign(resp, upMerchantKey).toUpperCase());
        return JSON.toJSONString(resp);
    }


}
