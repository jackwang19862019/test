package com.lee.paythird.chenggong;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.QRCodeUtils;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

/**
 * 成功
 */
@Service(ChengGong.channelNo)
public class ChengGong extends AbstractPay {

    public static final String channelNo = "chenggong";

    public final String payDomain = "https://trade.cgzf88.com";

    public final String quickPayUrl = payDomain + "/payGateway/payment/quickPay/v2";

    public final String scanPayUrl = payDomain + "/payGateway/payment/qrCode/v2";

    public final String getewayPayUrl = payDomain + "/payGateway/payment/gateway/v2";

    public final String h5PayUrl = payDomain + "/payGateway/payment/h5/v2";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public ChengGong() {
        payTypeMap.put(OutChannel.qqh5.name(), "qq_wallet_h5");
        payTypeMap.put(OutChannel.wechath5.name(), "wechat_h5");
        payTypeMap.put(OutChannel.alih5.name(), "alipay_h5");

        payTypeMap.put(OutChannel.quickpay.name(), "quick_pay");

        payTypeMap.put(OutChannel.alipay.name(), "alipay_qr");
        payTypeMap.put(OutChannel.wechatpay.name(), "wechat_qr");
        payTypeMap.put(OutChannel.qqpay.name(), "qq_wallet_qr");
        payTypeMap.put(OutChannel.unionpay.name(), "unionpay_qr");
        payTypeMap.put(OutChannel.jdpay.name(), "jd_wallet_qr");
        payTypeMap.put(OutChannel.baidupay.name(), "baidu_wallet_qr");

        payTypeMap.put("gateway", "gateway_pay");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String payUrl = quickPayUrl;
        if (payType.endsWith("h5")) {
            payUrl = h5PayUrl;
        } else if (payType.endsWith("qr")) {
            payUrl = scanPayUrl;
        } else if (payType.startsWith("gateway")) {
            payUrl = getewayPayUrl;
        }

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmssSSS");

        SimpleDateFormat sdf1 = new SimpleDateFormat("yyyyMMddHHmmss");

        Date now = new Date();

        Map<String, String> params = new HashMap<>();
        //平台下发的商户号
        params.put("mchntCode", upMerchantNo);
        //支付渠道
        params.put("channelCode", payType);
        //"时间戳格式为：年[4位]月[2位]日[2位]时[2位]分[2位]秒[2位]毫秒[3位]
        //例如：20071117020101221"
        params.put("ts", sdf.format(now));
        //商户订单号
        params.put("mchntOrderNo", orderNo);
        //单位为对应币种的最小货币单位，人民币为分。如订单总金额为1元，orderAmount为100
        params.put("orderAmount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        //发起支付请求客户端的 IPv4 地址，如: 127.0.0.1
        params.put("clientIp", reqIp);
        //商品的标题
        params.put("subject", product);
        //商品的描述信息
        params.put("body", product);
        //异步结果通知地址
        params.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        //支付完成后，跳转到商户方的页面
        params.put("pageUrl", returnUrl);
        //订单提交时间
        params.put("orderTime", sdf1.format(now));
        //订单失效时间
        params.put("orderExpireTime", sdf1.format(DateUtils.addMinutes(now, 10)));
        //可选参数，JSON格式。如：{“notifyVersion”:”1.1”}
        //可选参数，固定值：1.1。该参数填写1.1，则通知接口参数会多返回：body、description、subject、payAmount三个参数。
        params.put("extra1", "{\"notifyVersion\":\"1.1\"}");

        String sign = SignatureUtils.sign(params, upMerchantKey).toUpperCase();
        params.put("sign", sign);

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, params, String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>(){});

        String retCode = params.get("retCode");
        if (!"0000".equals(retCode)) {
            String retMsg = params.get("retMsg");
            LogByMDC.info(channelNo,"订单：{}，上游返回：{}", orderNo, retMsg);
            return R.error("上游返回：" + retMsg);
        }

        //单位为对应币种的最小货币单位，人民币为分。如订单总金额为1元，orderAmount为100
        String orderAmount = params.get("orderAmount");
        //系统订单号
        String sysOrderNo = params.get("sysOrderNo");
        //商户将该地址制作成二维码图片，供客户扫码，与imgSrc、payUrl不能同时为空，商户需要结合imgSrc、payUrl判断取值（该地址不能直接打开！）。见说明中的判断流程！
        String codeUrl = params.get("codeUrl");
        //已经生成好的二维码图片，直接展示出供客户扫码，与codeUrl、payUrl不能同时为空，商户需要结合codeUrl、payUrl判断取值（可以直接打开展示）。见说明中的判断流程！
        String imgSrc = params.get("imgSrc");
        //平台的二维码收银界面，打开该界面展示二维码，按照页面上引导的内容完成扫码支付，商户需要结合codeUrl、imgSrc判断取值（可以直接打开展示）。见说明中的判断流程！
        payUrl = params.get("payUrl");

        saveOrder(jObj, channelNo, upMerchantNo, sysOrderNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), new BigDecimal(orderAmount).multiply(new BigDecimal("0.01")).toString());
        if (StringUtils.isNotBlank(codeUrl)) {
            returnMap.put(PayConstants.web_qrcode_url, "data:image/png;base64," + QRCodeUtils.generate(codeUrl));
        } else if (StringUtils.isNotBlank(imgSrc)) {
            returnMap.put(PayConstants.web_qrcode_url, imgSrc);
        } else {
            returnMap.put(PayConstants.web_code_url, payUrl);
        }
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String upSign = params.get("sign");
        params.remove("sign");

        String sign = SignatureUtils.sign(params, upMerchantKey).toLowerCase();

        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return "FAIL";
        }

        String payResult = params.get("payResult");
        if (!"1".equals(payResult)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "success";
        }

        String sysOrderNo = params.get("sysOrderNo");
        String payAmount = params.get("payAmount");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(payAmount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(sysOrderNo);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "chengGong支付 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "success";
    }
}
