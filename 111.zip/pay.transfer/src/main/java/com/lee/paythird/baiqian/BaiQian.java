package com.lee.paythird.baiqian;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * 佰钱
 */
@Service(BaiQian.channelNo)//TODO佰钱不接
public class BaiQian extends AbstractPay {

    public static final String channelNo = "baiqian";

    static final String payUrl = "https://bq.baiqianpay.com/webezf/web/?app_act=openapi/bq_pay/pay";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public BaiQian() {
        payTypeMap.put(OutChannel.alipay.name(), "ZFB");
        payTypeMap.put(OutChannel.wechatpay.name(), "WX");
        payTypeMap.put(OutChannel.qqpay.name(), "QQ");
        payTypeMap.put(OutChannel.jdpay.name(), "JDQB");
        payTypeMap.put(OutChannel.unionwap.name(), "YL");
        payTypeMap.put(OutChannel.quickpayh5.name(), "KJ");

        payTypeMap.put(OutChannel.aliwap.name(), "ZFB_WAP");
        payTypeMap.put(OutChannel.qqwap.name(), "QQ_WAP");
        payTypeMap.put(OutChannel.jdwap.name(), "JDQB_WAP");
        payTypeMap.put(OutChannel.wechath5.name(), "WX_WAP");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "佰富支付 支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        /*Map<String, String> metaSignMap = new TreeMap<>();
        metaSignMap.put("merchantNo", merchNo_);
        metaSignMap.put("netwayCode", payType);
        metaSignMap.put("randomNum", randomStr(4));
        metaSignMap.put("orderNum", orderNo);
        metaSignMap.put("payAmount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));// 单位:分
        metaSignMap.put("goodsName", product);// 商品名称：20位
        metaSignMap.put("callBackUrl", getCallbackUrl(channelNo, merchNo, orderNo));// 回调地址
        metaSignMap.put("frontBackUrl", returnUrl);// 回显地址
        metaSignMap.put("requestIP", reqIp);// 客户ip地址
        String metaSignJsonStr = JSON.toJSONString(metaSignMap);
        String sign = MD5(metaSignJsonStr + md5Key, "UTF-8");
        metaSignMap.put("sign", sign);
        String reqparam = "paramData=" + JSON.toJSONString(metaSignMap);
        LogByMDC.info(channelNo, "佰富发起支付 订单：{}，request：{}", orderNo, JSON.toJSONString(reqparam));
        String resultJsonStr = request(payUrl, reqparam);
        LogByMDC.info(channelNo, "佰富支付返回 订单：{}，response：{}", orderNo, resultJsonStr);
        // 检查状态
        JSONObject resultJsonObj = JSONObject.parseObject(resultJsonStr);
        String stateCode = resultJsonObj.getString("resultCode");
        if (!stateCode.equals("00")) {
            String resultMsg = resultJsonObj.getString("resultMsg");
            LogByMDC.warn(channelNo, "佰富支付返回 订单：{}，response：{}", orderNo, resultMsg);
            return R.error(resultMsg);
        }
        String resultSign = resultJsonObj.getString("sign");
        resultJsonObj.remove("sign");
        Map map = new TreeMap(resultJsonObj);//重新排序
        String targetString = MD5(JSON.toJSONString(map) + md5Key, "UTF-8");
        if (!targetString.equals(resultSign)) {
            LogByMDC.warn(channelNo, "佰富支付返回验签失败 订单：{}，response：{}", orderNo);
            throw new RException("验签失败");
        }
        saveOrder(jObj, channelNo, upMerchantNo);
        String qrCode = resultJsonObj.getString("CodeUrl");
        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);*/
        return null;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, " 佰富支付 回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "佰富支付 订单：{}，重复回调", order.getOrderNo());
            return "000000";
        }

        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String paramData = params.get("paramData");
        JSONObject jsonObject = JSONObject.parseObject(paramData);

        String upSign = jsonObject.getString("sign");
        jsonObject.remove("sign");
        //再次排序
        Map<String, String> map = new TreeMap(jsonObject);
        //String sign = MD5(JSON.toJSONString(map) + md5Key, "UTF-8");

        /*if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "佰富支付 订单：{}，验证回调签名错误", orderNo);
            return "fail";
        }*/

        String payFlag = map.get("resultCode");
        if (!"00".equals(payFlag)) {
            LogByMDC.error(channelNo, "佰富支付 订单：{}，支付未成功，不再向下通知", orderNo);
            return "000000";
        }

        String amount = map.get("payAmount");
        String systemNo = map.get("orderNum");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(systemNo);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "佰富订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "佰富支付 订单：{}，下发通知失败", order.getOrderNo());
        }
        return "000000";
    }

    private static String randomStr(int num) {
        String str = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        StringBuilder sb = new StringBuilder(num);
        for (int i = 0; i < num; i++) {
            char ch = str.charAt(new Random().nextInt(str.length()));
            sb.append(ch);
        }
        return sb.toString();
    }
}
