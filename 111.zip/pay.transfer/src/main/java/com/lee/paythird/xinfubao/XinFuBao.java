package com.lee.paythird.xinfubao;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 信付宝
 */
@Service(XinFuBao.channelNo)
public class XinFuBao extends AbstractPay {

    public static final String channelNo = "xinfubao";

    private final String payUrl = "http://www.fbirdpay.com/api/payDefray/send";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public XinFuBao() {
        payTypeMap.put(OutChannel.alipay.name(), "1");
        payTypeMap.put(OutChannel.wechatpay.name(), "2");
        payTypeMap.put(OutChannel.unionpay.name(), "3");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new TreeMap<>();
        //商户订单号
        params.put("clientOrderId", orderNo);
        //商户号
        params.put("account", upMerchantNo);
        //商品描述
        params.put("subject", product);
        //交易金额(分)
        params.put("money", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        //商户端用户id
        params.put("clientUserId", userId);
        //商户端用户ip地址
        params.put("clientUserIp", reqIp);
        //回调地址
        params.put("callback", getCallbackUrl(channelNo, merchNo, orderNo));
        //支付类型:1.支付宝，2.微信, 3 银联
        params.put("payType", payType);

        String sign = SignatureUtils.sign(params, "&publicKey=" + upMerchantKey);
        params.put("secretKey", sign.toUpperCase());

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, params, String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>(){});

        String code = params.get("code");
        if (!"0".equals(code)) {
            String message = params.get("message");
            LogByMDC.error(channelNo, "订单：{}，请求失败，上游返回：{}", orderNo, message);
            return R.error("上游返回：" + message);
        }
        String data = params.get("data");
        params = JSON.parseObject(data, new TypeReference<Map<String, String>>(){});

        //签名数据
        String secretKey = params.get("secretKey");
        params.remove("secretKey");
        //金额(分)
        String money = params.get("money");
        //渠道订单号
        String orderId = params.get("orderId");
        //支付扫码地址
        String payUrl = params.get("payUrl");

        sign = SignatureUtils.sign(params, "&publicKey=" + upMerchantKey).toUpperCase();

        if (!sign.equals(secretKey)) {
            String message = "验证上游返回签名失败";
            LogByMDC.error(channelNo, "订单：{}，{}", orderNo, message);
            return R.error(message);
        }

        saveOrder(jObj, channelNo, upMerchantNo, orderId);


        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, payUrl);
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        //商户订单
        //ID
        String clientOrderId = params.get("clientOrderId");
        //渠道订单号
        String orderId = params.get("orderId");
        //金额(分)
        String money = params.get("money");
        //交易状态: 0:未支付，1:支付成功，2:支付失败
        String payStatus = params.get("payStatus");
        //签名
        String secretKey = params.get("secretKey");
        //商户号
        String account = params.get("account");

        String sign = SignatureUtils.sign(params, "&publicKey=" + upMerchantKey).toUpperCase();
        if (!sign.equals(secretKey)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，验证上游返回签名失败", channelNo, orderNo);
            return "success";
        }

        if (!"1".equals(payStatus)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，支付未成功，不再向下通知", channelNo, orderNo);
            return "success";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(money).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(orderId);

        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "信付宝支付订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "信付宝订单：{}，下发通知失败", order.getOrderNo());
        }

        return "success";
    }
}
