package com.lee.paythird.daxiong;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.api.OrderReqParams;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.daxiong.signature.HmacSHA1Signature;
import com.lee.paythird.daxiong.signature.SignatureUtil;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 大熊
 */
@Service(DaXiong.channelNo)
public class DaXiong extends AbstractPay<OrderReqParams> {

    static final String channelNo = "daxiong";

    private static final String payUrl = "http://47.56.101.219:1001/pay/goblin_aliH5Pay.do";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public DaXiong() {
        payTypeMap.put(OutChannel.alih5.name(), "alipayh5");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "大熊支付请求：{}", jObj.toJSONString());
        OrderReqParams reqParams = JsonToBean(jObj, OrderReqParams.class);
        Map<String, String> params = getParamsMap(merchantChannel, reqParams);
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "大熊支付响应 订单：{}，response：{}", reqParams.getOrderNo(), result);
        Map<String, String> resultMap = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String status = resultMap.get("code");
        Assert.isTrue("10000".equals(status), "大熊支付上游响应:" + resultMap.get("msg"));

        String qrCode = resultMap.get("payurl");
        saveOrder(jObj, channelNo, merchantChannel.getUpMerchantNo());

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), reqParams.getOrderNo());
        returnMap.put(OrderParamKey.outChannel.name(), reqParams.getOutChannel());
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), reqParams.getAmount());
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }

    private Map<String, String> getParamsMap(MerchantChannelEntity merchantChannel, OrderReqParams reqParams) {
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upPublicKey = merchantChannel.getUpPublicKey();
        String payType = payTypeMap.get(reqParams.getOutChannel());
        Assert.notNull(payType, "不支持的支付方式:" + reqParams.getOutChannel());
        String merchNo = reqParams.getMerchNo();
        String orderNo = reqParams.getOrderNo();
        String amount = reqParams.getAmount();

        Map<String, String> params = new TreeMap<>();
        params.put("merchantId", upMerchantNo);
        params.put("timestamp", String.valueOf(new Date().getTime()));
        params.put("tradeNo", orderNo);
        params.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("totalAmount", amount);
        params.put("subject", reqParams.getProduct());
        params.put("body", reqParams.getProduct());

        String sign = getSign(params, upPublicKey);
        params.put("signature", sign);

        return params;
    }

    private String getSign(Map<String, String> params, String key) {
        HmacSHA1Signature hmacSHA1Signature = new HmacSHA1Signature();
        String content = SignatureUtil.getSignatureContent(params, true);
        return hmacSHA1Signature.sign(content, key, "UTF-8");
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "大熊支付回调内容：{}", params);
        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "大熊支付回调订单：{}，重复回调", order.getOrderNo());
            return "SUCCESS";
        }

        String upMerchantKey = merchantChannel.getUpPublicKey();
        //验签
        boolean signVerify = verifySignParams(params, upMerchantKey);
        if (!signVerify) {
            LogByMDC.error(channelNo, "大熊支付回调订单：{}，回调验签失败", order.getOrderNo());
            return "FAIL";
        }
        String trade_no = params.get("trade_no");
        String trade_status = params.get("trade_status");
        String amount = params.get("total_amount");

        if (!"TRADE_SUCCESS".equals(trade_status)) {
            LogByMDC.error(channelNo, "大熊支付回调订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            return "SUCCESS";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(trade_no);
        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "大熊支付回调订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "大熊支付回调订单：{}，下发通知失败{}", order.getOrderNo(), e.getMessage());
            throw new RException("通知下游报错:" + e.getMessage());
        }
        return "SUCCESS";
    }

    private boolean verifySignParams(Map<String, String> paramsMap, String key) {
        String signature = paramsMap.remove("signature");
        HmacSHA1Signature hmacSHA1Signature = new HmacSHA1Signature();
        String content = SignatureUtil.getSignatureContent(paramsMap, true);
        String sign = hmacSHA1Signature.sign(content, key, "UTF-8");
        return sign.equals(signature);
    }


}
