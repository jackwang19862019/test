package com.lee.paythird.yjpay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.QRCodeUtils;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Service(Yjpay.channelNo)
public class Yjpay extends AbstractPay {

    public static final String channelNo = "yjpay";

    private final String payUrl = "http://api.itzoon.com/api/addOrder";

    private Map<String, String> payTypeMap = new HashMap<>();

    public Yjpay() {
        payTypeMap.put(OutChannel.alih5.name(), "wap");
        payTypeMap.put(OutChannel.alipay.name(), "qrcode");


        //近期上限中
        payTypeMap.put(OutChannel.wechath5.name(), "wxwap");
        payTypeMap.put(OutChannel.wechatpay.name(), "wxqrcode");
        payTypeMap.put(OutChannel.quickpay.name(), "ylkj");
        payTypeMap.put(OutChannel.unionwap.name(), "ylwg");
        payTypeMap.put(OutChannel.unionpay.name(), "ylsm");
        payTypeMap.put(OutChannel.qqpay.name(), "qqqb");
    }


    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new HashMap<>();
        //商户号，由平台分配
        params.put("merchant", upMerchantNo);
        //金额，单位为分
        params.put("amount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        //支付产品类型
        params.put("pay_type", payType);
        //商户订单号
        params.put("order_no", orderNo);
        //下单时间，Unix时间戳秒
        params.put("order_time", String.valueOf(System.currentTimeMillis()));
        //商品描述
        params.put("subject", product);
        //异步回调地址
        params.put("notify_url", getCallbackUrl(channelNo, merchNo, orderNo));
        //同步回调地址
        params.put("callback_url", returnUrl);

        String strParams = SignatureUtils.buildParams(params);
        String sign = DigestUtils.sha1Hex(strParams + "&key=" + upMerchantKey);

        params.put("sign", sign);

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });

        String code = params.get("code");
        String success = params.get("success");
        String error = params.get("error");
        if (!"0000".equals(code) || !"true".equals(success) || !"false".equals(error)) {
            String errMsg = params.get("errorMsg");
            String msg = params.get("msg");
            LogByMDC.error(channelNo, "订单：{}，上游返回：{}", orderNo, errMsg == null ? msg : errMsg);
            return R.error("上游返回：" + (errMsg == null ? msg : errMsg));
        }

        result = params.get("result");

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });

        String upSign = params.get("sign");
        params.remove("sign");

        strParams = SignatureUtils.buildParams(params);
        sign = DigestUtils.sha1Hex(strParams + "&key=" + upMerchantKey).toUpperCase();
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，验证上游返回签名失败", channelNo, orderNo);
            return R.error("验证上游返回签名失败");
        }

        String qrCode = params.get("qrCode");


        saveOrder(jObj, channelNo, merchantChannel.getUpMerchantNo());

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);

        returnMap.put(PayConstants.web_qrcode_url, "data:image/png;base64," + QRCodeUtils.generate(qrCode));

        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }

        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String upSign = params.get("sign");
        params.remove("sign");

        String strParams = SignatureUtils.buildParams(params);
        String sign = DigestUtils.sha1Hex(strParams + "&key=" + upMerchantKey).toUpperCase();

        if (!sign.equalsIgnoreCase(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，签名验证失败", orderNo);
            return "success";
        }

        //平台订单号
        String tranNo = params.get("tranNo");
        //单位元
        String amount = params.get("amount");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(tranNo);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
            LogByMDC.error(channelNo, "下发通知失败", e);
        }

        return "success";
    }
}
