package com.lee.paythird.tgyule;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Service(TGYuLe.channelNo)
public class TGYuLe extends AbstractPay {

    public static final String channelNo = "tgyule";

    public final String payUrl = "http://pay.tgyule.club/WebHandler/H5PayHandler.ashx";

    public final String queryUrl = "http://pay.tgyule.club/WebHandler/H5DemandHanlder.ashx";

    // 查单 返回没有权限  上游 反馈 不需要查单


    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String callbackUrl = getCallbackUrl(channelNo, merchNo, orderNo);

        Map<String, String> params = new HashMap<>();
        //客户 ID
        params.put("CustomerId", upMerchantNo);
        //订单号
        params.put("OrderId", orderNo);
        //金额
        params.put("Money", amount);
        //异步地址
        params.put("notifyUrl", callbackUrl);

        Map<String, String> signMap = new HashMap<>(params);
        signMap.put("key", upMerchantKey);

        String signStr = String.format("CustomerId=%s&key=%s&Money=%s&notifyUrl=%s&OrderId=%s",
                upMerchantNo, upMerchantKey, amount, callbackUrl, orderNo);
        LogByMDC.info(channelNo, "签名原串：{}", signStr);

        String sign = SignatureUtils.sign(signStr, "").toUpperCase();
        params.put("MD5sign", sign);

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>(){});

        String result_state = params.get("result_state");
        if (!"true".equals(result_state)) {
            String msg = params.get("msg");
            LogByMDC.error(channelNo, "订单：{}，请求失败，上游返回：{}", orderNo, msg);
            return R.error("上游返回：" + msg);
        }

        saveOrder(jObj, channelNo, upMerchantNo);

        String pay_url = params.get("payUrl");

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, pay_url);
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();


        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }

        String upSign = params.get("sign");
        //状态代码
        String code = params.get("code");
        //平台订单号
        String OrderNumber = params.get("OrderNumber");
        //交易金额
        String money = params.get("money");
        //客户订单号
        String OrderId = params.get("OrderId");
        //交易日期
        String orderDate = params.get("orderDate");


        String signStr = String.format("code=%s&key=%s&money=%s&orderDate=%s&OrderId=%s&OrderNumber=%s",
                code, upMerchantKey, money, orderDate, OrderId, OrderNumber);

        String sign = SignatureUtils.sign(signStr, "").toUpperCase();
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，验证上游返回签名失败", channelNo, orderNo);
            return "success";
        }

        if (!"200".equals(code)) {
            LogByMDC.error(channelNo, "通道：{}，订单：{}，支付未成功，不再向下通知", channelNo, orderNo);
            return "success";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(money));
        order.setBusinessNo(OrderNumber);

        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "success";
    }
}
