package com.lee.paythird.mypayshop;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.QRCodeUtils;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Service(MyPayShop.channelNo)
public class MyPayShop extends AbstractPay {

    public static final String channelNo = "mypayshop";

    private final String payUrl = "http://j1.mypayshop.vip/channel/Common/mail_interface";

    private final String queryUrl = "http://j1.mypayshop.vip/channel/Common/query_pay";

    private Map<String, String> payTypeMap = new HashMap<>();

    public MyPayShop() {
        payTypeMap.put(OutChannel.wechatpay.name(), "wechatangel");
        payTypeMap.put(OutChannel.wechath5.name(), "wechatangelwap");
        payTypeMap.put(OutChannel.alipay.name(), "alipay");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new HashMap<>();
        //必填参数json， html（详情请看，返回说明）
        params.put("return_type", "json");
        //商户号
        params.put("api_code", upMerchantNo);
        //必须，支付渠道：查看压缩包内 对接通道.txt
        //可通过http://ip地址/channel/common/api_query查询，有显示的英文都是可用接口
        params.put("is_type", payType);
        //必须，保留2位小数，不能传0
        params.put("price", amount);
        //必须，在商户系统中保持唯一
        params.put("order_id", orderNo);
        //必须 时间戳
        params.put("time", System.currentTimeMillis() + "");
        //必须 粗略说明支付目的（例如 购买食杂）
        params.put("mark", product);
        //必须，成功后网页跳转地址（例如 http://www.qq.com）
        params.put("return_url", returnUrl);
        //通知状态异步回调接收地址
        params.put("notify_url", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("sign", SignatureUtils.sign(params, "&key=" + upMerchantKey).toUpperCase());

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, params, String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });

        String returncode = params.get("returncode");
        if (StringUtils.isNotBlank(returncode)) {
            String errMsg = params.get("returnmsg");
            LogByMDC.error(channelNo, "订单：{}，上游返回：{}", orderNo, errMsg);
            return R.error("上游返回：" + errMsg);
        }
        //码内容：想展示二维码内容，可以payurl值放到这个网址后面：https://pan.baidu.com/share/qrcode?w=280&h=280&url=
        String payurl = params.get("payurl");
        //显示给用户的订单金额(一定要把这个价格显示在支付页上，而不是订单金额)
        String real_price = params.get("real_price");
        //是您在发起支付接口传入的您的自定义订单号
        String order_id = params.get("order_id");
        //是此订单在Api服务器上的唯一编号
        String paysapi_id = params.get("paysapi_id");


        saveOrder(jObj, channelNo, merchantChannel.getUpMerchantNo(), paysapi_id);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), real_price);

        returnMap.put(PayConstants.web_qrcode_url, "data:image/png;base64," + QRCodeUtils.generate(payurl));

        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {

        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        Map<String, String> map = new HashMap<>();
        map.put("api_code", upMerchantNo);
        map.put("order_id", order.getOrderNo());
        map.put("sign", SignatureUtils.sign(map, "&key=" + upMerchantKey).toUpperCase());

        LogByMDC.info(channelNo, "查询订单：{}，request：{}", orderNo, JSON.toJSONString(map));
        String result = restTemplate.postForObject(queryUrl, map, String.class);
        LogByMDC.info(channelNo, "查询订单：{}，response：{}", orderNo, result);

        map = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });

        if (StringUtils.isNotBlank(map.get("returncode"))) {
            String msg = map.get("msssage");
            LogByMDC.error(channelNo, "订单：{}，请求失败，上游返回：{}", orderNo, msg);
            throw new RException("请求失败，上游返回：" + msg);
        }

        String upSign = map.get("sign");
        map.remove("sign");

        String sign = SignatureUtils.sign(map, "&key=" + upMerchantKey).toUpperCase();
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证上游返回签名失败", orderNo);
            throw new RException("验证上游返回签名失败");
        }

        String code = map.get("code");
        String real_price = map.get("real_price");
        if ("1".equals(code)) {
            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(real_price));
            orderService.update(order);
        } else {
            LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", order.getOrderNo());
        }
        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }

        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();


        String sign = params.get("sign");
        params.remove("sign");

        params.put("api_code", upMerchantNo);
        String mySign = SignatureUtils.sign(params, "&key=" + upMerchantKey).toUpperCase();
        if (!mySign.equalsIgnoreCase(sign)) {
            LogByMDC.error(channelNo, "订单：{}，签名验证失败", orderNo);
            return "FAIL";
        }

        //是此订单在Api服务器上的唯一编号
        String paysapi_id = params.get("paysapi_id");
        //是您在发起支付接口传入的您的自定义订单号
        String order_id = params.get("order_id");
        //必须，支付渠道:
        String is_type = params.get("is_type");
        //是您在发起支付接口传入的订单价格
        String price = params.get("price");
        //表示用户实际支付的金额。一般会和price值一致，如果同时存在多个用户支付同一金额，就会和price存在一定差额，差额一般在1-2分钱上下，越多人同时支付，差额越大。
        String real_price = params.get("real_price");
        //你提交上来的订单备注信息
        String mark = params.get("mark");
        //订单状态判断标准：
        //0 未处理 1 交易成功 2 支付失败 3 关闭交易 4 支付超时
        String code = params.get("code");

        if (!"1".equals(code)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "SUCCESS";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(real_price));
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "SUCCESS";
    }
}
