package com.lee.paythird.bifubao;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.*;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;


/**
 * 必付宝
 */
@Service(BiFuBao.channelNo)
public class BiFuBao extends AbstractPay {

    public static final String channelNo = "bifubao";

    static final String payUrl = "https://api.bfbaopay.com/bifubao-gateway/front-pay/h5-pay.htm";

    private static final Map<String, String> payTypeMap = new HashMap<>();

    public BiFuBao() {
        payTypeMap.put(OutChannel.alipay.name(), "18");
        payTypeMap.put(OutChannel.wechatpay.name(), "19");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "必付宝支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("必付宝支付请求 不支持的支付类型");
        }
        String merchantNo = getMerchantNoByPayType(payType);
        String md5Key = getMd5KeyByPayType(payType);
        if (StringUtils.isEmpty(merchantNo) || StringUtils.isEmpty(md5Key)) {
            LogByMDC.info(channelNo, "必付宝支付未找到商户号或md5秘钥：1、{},2、{}", merchantNo, md5Key);
            return R.error("必付宝支付未找到商户号或md5秘钥");
        }

        Map<String, String> params = new TreeMap<>();
        params.put("MERCHANT_ID", merchantNo);
        params.put("TRAN_CODE", orderNo);
        params.put("TRAN_AMT", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        params.put("REMARK", "商品描述");
        params.put("TYPE", payType);
        params.put("NO_URL", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("RET_URL", returnUrl);
        params.put("SUBMIT_TIME", DateUtil.getCurrentNumStr());
        params.put("VERSION", "1");
        String signParams = SignatureUtils.buildParams(params, false) + md5Key;
        String sign = Md5Util.MD5(signParams);
        params.put("SIGNED_MSG", sign);

        LogByMDC.info(channelNo, "必付宝 支付参数转发给下游：{}", JSON.toJSONString(params));
        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    private String getMd5KeyByPayType(String payType) {
        if (payType.equals("18")) {
            //支付宝网银
            return "b4ec0d5d34501ee1";
        }
        if (payType.equals("19")) {
            //微信收银台
            return "1759e68c758cac9c";
        }
        return null;
    }

    private String getMerchantNoByPayType(String payType) {
        if (payType.equals("18")) {
            //支付宝网银
            return "SP005317PENSTONE0";
        }
        if (payType.equals("19")) {
            //微信收银台
            return "SP005317POCKET0";
        }
        return null;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "必付宝 异步回调内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "必付宝订单：{}，重复回调", order.getOrderNo());
            return "success";
        }
        String signUp = params.remove("SIGNED_MSG");
        String type = params.get("TYPE");
        LogByMDC.error(channelNo, "必付宝验签支付类型：{}", type);
        String signKey = getMd5KeyByPayType(type);
        LogByMDC.error(channelNo, "必付宝订单验签MD5：{}", signKey);
        String sign = getSign(params, signKey);
        if (!sign.equals(signUp)){
            LogByMDC.info(channelNo, "必付宝异步回调 订单：{}，验签失败", order.getOrderNo());
            return "fail";
        }
        String status = params.get("STATUS");
        if (!"1".equals(status)){
            LogByMDC.info(channelNo, "必付宝异步回调 订单：{}，支付失败", order.getOrderNo());
            return "success";
        }

        String amount = params.get("TRAN_AMT");
        String systemNo = params.get("TRAN_CODE");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(systemNo);
        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "必付宝订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "必付宝订单：{}，下发通知失败", order.getOrderNo());
        }
        return "success";

    }

    private String getSign(Map<String, String> params, String signKey) {
        //验签
        LogByMDC.error(channelNo, "必付宝验签参数：{}", JSON.toJSONString(params));
        String signParams = SignatureUtils.buildParams(params, true) + signKey;
        return Md5Util.MD5(signParams);
    }
}
