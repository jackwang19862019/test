package com.lee.paythird.shenfu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.*;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.dom4j.Document;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.dom4j.Element;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service(Shenfu.channelNo)
public class Shenfu extends AbstractPay {

    public static final String channelNo = "shenfu";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public Shenfu() {
        payTypeMap.put(OutChannel.alipay.name(), "alipay_scan");
        payTypeMap.put(OutChannel.wechatpay.name(), "weixin_scan");
        payTypeMap.put(OutChannel.qqpay.name(), "tenpay_scan");
        payTypeMap.put(OutChannel.unionpay.name(), "ylpay_scan");


        payTypeMap.put(OutChannel.qqh5.name(), "h5_qq");
        payTypeMap.put(OutChannel.wechath5.name(), "h5_wx");
        payTypeMap.put(OutChannel.alih5.name(), "h5_ali");
        payTypeMap.put(OutChannel.unionh5.name(), "h5_union");
        payTypeMap.put(OutChannel.jdh5.name(), "h5_jd");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());


        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }


        String privateKey = merchantChannel.getUpPrivateKey();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = new Date();

        Map<String, String> params = new HashMap<>();
        //商家号
        params.put("merchant_code", merchantChannel.getUpMerchantNo());
        //业务类型
        params.put("service_type", payType);
        //服务器异步通知地址
        params.put("notify_url", getCallbackUrl(channelNo, merchNo, orderNo));

        //客户端IP
        params.put("client_ip", reqIp);
        //商户网站唯一订单号
        params.put("order_no", orderNo);
        //商户订单时间
        params.put("order_time", sdf.format(now));
        //商户订单总金额
        params.put("order_amount", amount);
        //商品名称
        params.put("product_name", product);


        if (OutChannel.alipay.name().equals(outChannel)
                || OutChannel.wechatpay.name().equals(outChannel)
                || OutChannel.qqpay.name().equals(outChannel)
                || OutChannel.unionpay.name().equals(outChannel)) {
            //接口版本
            params.put("interface_version", "V3.1");
        } else {
            //接口版本
            params.put("interface_version", "V3.0");
            params.put("input_charset", "UTF-8");
        }


        String signSrc = SignatureUtils.buildParams(params);

        try {
            String sign = RSAUtils.sign(signSrc.getBytes("UTF-8"), privateKey);
            params.put("sign", sign);
            //签名方式
            params.put("sign_type", "RSA-S");
        } catch (Exception e) {
            e.printStackTrace();
            return R.error("系统内部错误");
        }

        if (OutChannel.alipay.name().equals(outChannel)
                || OutChannel.wechatpay.name().equals(outChannel)
                || OutChannel.qqpay.name().equals(outChannel)
                || OutChannel.unionpay.name().equals(outChannel)) {
            return requestScan(channel, merchant, merchantChannel, jObj, params);
        } else {
            return buildH5Html(channel, merchant, merchantChannel, jObj, params);
        }
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String queryUrl = channelObj.getString("queryUrl");

        Map<String, String> params = new HashMap<>();
        params.put("service_type", "single_trade_query");
        params.put("merchant_code", merchantChannel.getUpMerchantNo());
        params.put("interface_version", "V3.0");
        params.put("order_no", order.getOrderNo());

        String signSrc = SignatureUtils.buildParams(params);
        params.put("sign_type", "RSA-S");

        try {
            String sign = RSAUtils.sign(signSrc.getBytes("UTF-8"), merchantChannel.getUpPrivateKey());
            params.put("sign", sign);
            //签名方式
            params.put("sign_type", "RSA-S");
        } catch (Exception e) {
            LogByMDC.error(channelNo, "RSA解析错误", e);
            throw new RException("系统内部错误");
        }

        String result = restTemplate.postForObject(queryUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "返回参数：{}", result);
        Document document;
        try {
            document = DocumentHelper.parseText(result);
        } catch (DocumentException e) {
            LogByMDC.error(channelNo, "解析上游返回xml失败", e);
            throw new RException("解析上游返回xml失败");
        }

        Element rootEle = document.getRootElement();
        Element resEle = rootEle.element("response");

        List<Element> elements = resEle.elements();

        Map<String, String> map = new HashMap<>();
        for (Element e : elements) {
            map.put(e.getName(), e.getStringValue());
        }

        String is_success = map.get("is_success");
        String order_amount = map.get("order_amount");
        String trade_no = map.get("trade_no");
        String trade_status = map.get("trade_status");


        if ("T".equals(is_success) && "SUCCESS".equals(trade_status)) {

            String sign = map.get("sign");
            map.remove("sign");
            map.remove("sign_type");

            signSrc = SignatureUtils.buildParams(map);

            try {
                if (!RSAUtils.verify(signSrc.getBytes("UTF-8"), merchantChannel.getUpPublicKey(), sign)) {
                    LogByMDC.error(channelNo, "订单：{}，验证上游签名失败", order.getOrderNo());
                    throw new RException("验证上游签名失败");
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(order_amount).multiply(new BigDecimal("0.01")));
            order.setBusinessNo(trade_no);
            orderService.update(order);
        } else {
            LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", order.getOrderNo());

        }

        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }

        String sign = params.get("sign");
        params.remove("sign");
        params.remove("sign_type");

        try {
            if (!RSAUtils.verify(SignatureUtils.buildParams(params).getBytes("UTF-8"), merchantChannel.getUpPublicKey(), sign)) {
                LogByMDC.error(channelNo, "订单：{}，上游通知签名验证不通过");
                return "SUCCESS";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "SUCCESS";
        }


        String order_amount = params.get("order_amount");
        String trade_no = params.get("trade_no");
        String trade_status = params.get("trade_status");

        if (!"SUCCESS".equals(trade_status)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            return "SUCCESS";
        }


        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(order_amount));
        order.setBusinessNo(trade_no);

        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "支付订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
            LogByMDC.error(channelNo, e.getMessage(), e);
        }

        return "SUCCESS";
    }


    private R requestScan(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj, Map<String, String> params) {
        LogByMDC.info(channelNo, "请求数据：{}", JSON.toJSONString(params));

        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String amount = jObj.getString(OrderParamKey.amount.name());

        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String payUrl = channelObj.getString("qrPayUrl");

        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "返回参数：{}", result);
        Document document;
        try {
            document = DocumentHelper.parseText(result);
        } catch (DocumentException e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "解析上游返回xml失败", e);
            return R.error("解析上游返回xml失败");
        }

        Element rootEle = document.getRootElement();
        Element resEle = rootEle.element("response");

        List<Element> elements = resEle.elements();

        Map<String, String> map = new HashMap<>();
        for (Element e : elements) {
            map.put(e.getName(), e.getStringValue());
        }

        String sign = map.get("sign");
        map.remove("sign");
        map.remove("sign_type");

        String signSrc = SignatureUtils.buildParams(map);

        try {
            if (!RSAUtils.verify(signSrc.getBytes("UTF-8"), merchantChannel.getUpPublicKey(), sign)) {
                LogByMDC.error(channelNo, "订单：{}，验证上游签名失败", orderNo);
                return R.error("验证上游签名失败");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        String resp_code = map.get("resp_code");
        String resp_desc = map.get("resp_desc");
        String result_code = map.get("result_code");
        String result_desc = map.get("result_desc");
        String qrcode = map.get("qrcode");

        if (!"SUCCESS".equals(resp_code)) {
            LogByMDC.error(channelNo, "订单：{},失败，上游返回：{}", orderNo, resp_desc);
            return R.error("上游返回：" + resp_desc);
        }

        if (!"0".equals(result_code)) {
            LogByMDC.error(channelNo, "订单：{},失败，上游返回：{}", orderNo, result_desc);
            return R.error("上游返回：" + result_desc);
        }

        saveOrder(jObj, channelNo, params.get("merchant_code"));


        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_qrcode_url, "data:image/png;base64," + QRCodeUtils.generate(qrcode));
        return R.ok().put(Constant.result_data, returnMap);
    }


    private R buildH5Html(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj, Map<String, String> params) {
        LogByMDC.info(channelNo, "请求数据：{}", JSON.toJSONString(params));

        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String amount = jObj.getString(OrderParamKey.amount.name());

        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String payUrl = channelObj.getString("h5PayUrl");

        saveOrder(jObj, channelNo, params.get("merchant_code"));


        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }


}
