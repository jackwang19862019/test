package com.lee.paythird.demo;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.*;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

@Service(DemoPay.channelNo)
public class DemoPay extends AbstractPay {


    public static final String channelNo = "demo";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public DemoPay() {
        payTypeMap.put(OutChannel.wechatpay.name(), "wxpay");
        payTypeMap.put(OutChannel.qqpay.name(), "qqpay");
        payTypeMap.put(OutChannel.alipay.name(), "alipay");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        Map<String, String> channelMap = JSON.parseObject(channel.getPayload(), new TypeReference<Map<String, String>>() {});
        String payUrl = channelMap.get("payUrl");

        Map<String, String> map = new HashMap<>();
        //商品名称
        map.put("goods", product);
        //异步回调地址
        map.put("notify_url", getCallbackUrl(channel.getChannelNo(), merchant.getMerchantNo(), orderNo));
        //商户订单号
        map.put("param", orderNo);
        //支付金额
        map.put("price", amount);
        //同步通知地址
        map.put("return_url", returnUrl);
        //商户PID/APPID
        map.put("seller", merchantChannel.getUpMerchantNo());
        //支付类型：alipay qqpay wxpay
        map.put("type", payType);
        //拼接url参数加上商户Key然后md5加密

        map.put("sign", SignatureUtils.sign(map, merchantChannel.getUpPublicKey()));
        //固定值MD5
        map.put("sign_type", "MD5");

        String paramStr = SignatureUtils.buildParams(map);

        LogByMDC.info(channelNo, "recharge params:{}", payUrl + "?" + paramStr);


        saveOrder(jObj, channel.getChannelNo(), merchantChannel.getUpMerchantNo());

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put(PayConstants.web_code_url, payUrl + "?" + paramStr);
        resultMap.put(OrderParamKey.orderNo.name(), orderNo);
        resultMap.put(OrderParamKey.outChannel.name(), outChannel);
        resultMap.put(OrderParamKey.merchNo.name(), merchNo);
        resultMap.put(OrderParamKey.channelNo.name(), channel.getChannelNo());

        return R.ok().put(Constant.result_data, resultMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);
        //充值金额
        String money = params.get("money");
        //商品名字
        String name = params.get("name");
        //商户订单号/下游请求订单号
        String out_trade_no = params.get("out_trade_no");
        //商户PID/APPID
        String pid = params.get("pid");
        //平台订单号/上游订单号
        String trade_no = params.get("trade_no");
        //支付状态 TRADE_FAIL为未支付 TRADE_SUCCESS 为已经支付
        String trade_status = params.get("trade_status");
        //支付方式 wxpay alipay qqpay bank bankwy
        String type = params.get("type");
        //固定值 MD5
        String sign_type = params.get("sign_type");
        //拼接url参数加上商户Key然后md5加密
        String sign = params.get("sign");

        params.remove("sign");
        params.remove("sign_type");

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", out_trade_no);
            return "SUCCESS";
        }
        Map<String, String> channelMap = JSON.parseObject(channel.getPayload(), new TypeReference<Map<String, String>>() {});
        String merchantNo = channelMap.get("merchantNo");
        String merchantKey = channelMap.get("merchantKey");

        String mySign = SignatureUtils.sign(params, merchantKey);
        if (!mySign.equalsIgnoreCase(sign)) {
            LogByMDC.error(channelNo, "订单：{}，签名验证失败", out_trade_no);
            return "FAIL";
        }

        if (!"TRADE_SUCCESS".equals(trade_status)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", out_trade_no);
            return "SUCCESS";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(money));
        order.setBusinessNo(trade_no);

        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "SUCCESS";
    }
}
