package com.lee.paythird;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Constant;
import com.lee.pay.constenum.NoticeState;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.entity.OrderAcpEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.pay.order.delay.NotifyTask;
import com.lee.pay.service.ConfigService;
import com.lee.pay.service.OrderAcpService;
import com.lee.pay.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.web.client.RestTemplate;

import java.util.Date;

public abstract class AbstractPay<T> implements PayService {

    @Autowired
    protected RestTemplate restTemplate;

    @Autowired
    protected OrderService orderService;

    @Autowired
    protected OrderAcpService orderAcpService;

    @Autowired
    private ConfigService configService;

    @Autowired
    protected NotifyTask notifyTask;

    @Value("${server.contextPath}")
    private String contextPath;

    /**
     * callback/{channelNo}/{merchantNo}/{orderNo}
     *
     * @return
     */
    protected String getCallbackUrl(String channelNo, String merchantNo, String orderNo) {
        String domain = configService.selectByKey(Constant.PLATFORM_DOMAIN_KEY);
        String callbackUrl = domain + contextPath + "/callback/" + channelNo + "/" + merchantNo + "/" + orderNo;
        return callbackUrl;
    }

    /**
     * acp/callback/{channelNo}/{merchantNo}/{orderNo}
     *
     * @return
     */
    protected String getAgentCallBackUrl(String channelNo, String merchantNo, String orderNo) {
        String domain = configService.selectByKey(Constant.PLATFORM_DOMAIN_KEY);
        String callbackUrl = domain + contextPath + "/acp/callback/" + channelNo + "/" + merchantNo + "/" + orderNo;
        return callbackUrl;
    }


    protected void saveOrder(JSONObject jObj, String channelNo, String upMerchantNo) {
        saveOrder(jObj, channelNo, upMerchantNo, null);
    }

    protected void saveOrder(JSONObject jObj, String channelNo, String upMerchantNo, String businessNo) {
        OrderEntity order = JSONObject.toJavaObject(jObj, OrderEntity.class);
        order.setOrderState(OrderState.init.id());
        order.setCrtDate(new Date());
        order.setNoticeState(NoticeState.init.id());
        order.setPayCompany(channelNo);
        order.setPayMerch(upMerchantNo);
        order.setBusinessNo(businessNo);
        orderService.save(order);
    }

    protected void saveAcpOrder(JSONObject jObj, String channelNo, String upMerchantNo) {
        OrderAcpEntity order = JSONObject.toJavaObject(jObj, OrderAcpEntity.class);
        order.setOrderState(OrderState.init.id());
        order.setCrtDate(new Date());
        order.setNoticeState(NoticeState.init.id());
        order.setPayCompany(channelNo);
        order.setPayMerch(upMerchantNo);
        orderAcpService.save(order);
    }

    protected T JsonToBean(JSONObject jObj, Class<T> beanCls) {
        return JSONObject.toJavaObject(jObj, beanCls);
    }

}
