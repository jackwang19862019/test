package com.lee.paythird.xinfutong;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import jdk.nashorn.internal.ir.CallNode;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 信付通
 */
@Service(XinFuTong.channelNo)
public class XinFuTong extends AbstractPay {

    public static final String channelNo = "xinfutong";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public XinFuTong() {
        payTypeMap.put(OutChannel.alipay.name(), "ALIPAY");
        payTypeMap.put(OutChannel.alih5.name(), "ALIPAY");

        payTypeMap.put(OutChannel.wechatpay.name(), "WXPAY");
        payTypeMap.put(OutChannel.wechath5.name(), "WXPAY");

        payTypeMap.put(OutChannel.unionpay.name(), "UNIONQRPAY");
        payTypeMap.put(OutChannel.quickpay.name(), "EASYQUICK");
        payTypeMap.put(OutChannel.unionwap.name(), "BANKPAY");
    }

    private Map<String, String> getChangeParams(String payType, String merchantNo, String orderNo) {
        Map<String, String> map = new HashMap<>();
        String payUrl = "https://ebank.xfuoo.com/payment/v1/order/" + merchantNo + "-" + orderNo;
        if (payType.equals(OutChannel.alih5.name()) || payType.equals(OutChannel.wechath5.name())) {
            map.put("isApp", "h5");
        } else {
            map.put("isApp", "web");
        }
        if (payType.equals(OutChannel.unionwap.name()) || payType.equals(OutChannel.quickpay.name())) {
            map.put("paymethod", "bankPay");
        } else {
            map.put("paymethod", "directPay");
        }
        map.put("defaultbank", payTypeMap.get(payType));
        map.put("payUrl", payUrl);
        return map;
    }

    public static String string2Sha1(String str) {
        if (str == null || str.length() == 0) {
            return null;
        }
        char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'a', 'b', 'c', 'd', 'e', 'f'};
        try {
            MessageDigest mdTemp = MessageDigest.getInstance("SHA1");
            mdTemp.update(str.getBytes("UTF-8"));

            byte[] md = mdTemp.digest();
            int j = md.length;
            char buf[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                buf[k++] = hexDigits[byte0 >>> 4 & 0xf];
                buf[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(buf);
        } catch (Exception e) {
            return null;
        }
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "信付通支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("信付通不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        LogByMDC.info(channelNo, "信付通订单：{}，变动参数获取request：{}", orderNo, outChannel, orderNo);
        Map<String, String> changeParams = getChangeParams(outChannel, upMerchantNo, orderNo);
        LogByMDC.info(channelNo, "信付通订单：{}，变动参数获取response：{}", orderNo, JSON.toJSONString(changeParams));

        Map<String, String> params = new TreeMap<>();
        params.put("defaultbank", changeParams.get("defaultbank"));
        params.put("isApp", changeParams.get("isApp"));
        params.put("body", product);
        params.put("charset", "UTF-8");
        params.put("merchantId", upMerchantNo);
        params.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("orderNo", orderNo);
        params.put("paymentType", "1");
        params.put("paymethod", changeParams.get("paymethod"));
        params.put("returnUrl", returnUrl);
        params.put("service", "online_pay");
        params.put("title", product);
        params.put("totalFee", amount);

        String signParams = SignatureUtils.buildParams(params, false) + upMerchantKey;
        LogByMDC.info(channelNo, "信付通订单：{}，参与加签参数：{}", orderNo, signParams);
        String sign = string2Sha1(signParams);
        params.put("signType", "SHA");
        params.put("sign", sign.toUpperCase());
        LogByMDC.info(channelNo, "信付通订单：{}，下发给下游from参数：{}", orderNo, JSON.toJSONString(params));
        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(changeParams.get("payUrl"), params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        LogByMDC.info(channelNo, "信付通回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "信付通回调订单：{}，重复回调", orderNo);
            return "success";
        }
        String sign = params.remove("sign");
        params.remove("signType");

        String signParams = SignatureUtils.buildParams(params, true)+ upMerchantKey;
        LogByMDC.error(channelNo, "信付通回调订单：{}，验签参数", signParams);
        String signStr = string2Sha1(signParams).toUpperCase();
        LogByMDC.error(channelNo, "信付通回调订单：{}，验签sign", signStr);
        if (!sign.equals(signStr)){
            LogByMDC.error(channelNo, "信付通回调订单：{}，验签失败", orderNo);
            return "fail";
        }
        String trade_status = params.get("trade_status");
        if (!"TRADE_FINISHED".equals(trade_status)){
            LogByMDC.error(channelNo, "信付通回调订单：{}，上游返回支付不成功", orderNo);
            return "fail";
        }

        String money = params.get("total_fee");
        String tradeNo = params.get("trade_no");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(money));
        order.setBusinessNo(tradeNo);
        orderService.update(order);

        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "信付通支付订单：{}，下发通知成功", orderNo);
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "信付通订单：{}，下发通知失败", orderNo);
        }
        return "success";
    }
}
