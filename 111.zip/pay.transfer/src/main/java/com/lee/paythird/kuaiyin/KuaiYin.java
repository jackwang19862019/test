package com.lee.paythird.kuaiyin;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.Md5Utils;
import com.lee.common.utils.R;
import com.lee.pay.api.OrderReqParams;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 快银
 */
@Service(KuaiYin.channelNo)
public class KuaiYin extends AbstractPay<OrderReqParams> {

    static final String channelNo = "kuaiyin";

    private static final String payUrl = "http://gateway.fastwinpro.com/pay/index.aspx";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public KuaiYin() {
        payTypeMap.put(OutChannel.alipay.name(), "1002");
        payTypeMap.put(OutChannel.alih5.name(), "1006");

        payTypeMap.put(OutChannel.wechatpay.name(), "1001");
        payTypeMap.put(OutChannel.wechath5.name(), "1005");

        payTypeMap.put(OutChannel.qqpay.name(), "1007");
        payTypeMap.put(OutChannel.qqh5.name(), "1008");

        payTypeMap.put(OutChannel.unionpay.name(), "1013");
        payTypeMap.put(OutChannel.unionh5.name(), "1014");

        payTypeMap.put(OutChannel.jdpay.name(), "1009");
        payTypeMap.put(OutChannel.jdh5.name(), "1010");

        payTypeMap.put("szfbsm", "1016");
        payTypeMap.put("szfbh5", "1017");

        payTypeMap.put("swxsm", "1018");
        payTypeMap.put("swxh5", "1019");

    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "快银支付请求：{}", jObj.toJSONString());
        OrderReqParams reqParams = JsonToBean(jObj, OrderReqParams.class);
        Map<String, String> params = getParamsMap(merchantChannel, reqParams);
        saveOrder(jObj, channelNo, merchantChannel.getUpMerchantNo());

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), reqParams.getOrderNo());
        returnMap.put(OrderParamKey.outChannel.name(), reqParams.getOutChannel());
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), reqParams.getAmount());
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }


    private Map<String, String> getParamsMap(MerchantChannelEntity merchantChannel, OrderReqParams reqParams) {
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upPublicKey = merchantChannel.getUpPublicKey();
        String payType = payTypeMap.get(reqParams.getOutChannel());
        Assert.notNull(payType, "不支持的支付方式:" + reqParams.getOutChannel());
        String merchNo = reqParams.getMerchNo();
        String orderNo = reqParams.getOrderNo();
        String amount = reqParams.getAmount();

        Map<String, String> params = new TreeMap<>();
        params.put("merchant", upMerchantNo);
        params.put("version", "1.0");
        params.put("paytype", payType);
        params.put("orderid", orderNo);
        params.put("amount", new BigDecimal(amount) + "");
        params.put("ordertime", System.currentTimeMillis() + "");
        params.put("returnurl", reqParams.getReturnUrl());
        params.put("notifyurl", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("signtype", "1");
        params.put("ip", reqParams.getReqIp());
        String sign = Md5Utils.MD5(getSign(params, upPublicKey));
        params.put("sign", sign);
        return params;
    }

    private String getSign(Map<String, String> params, String upPublicKey) {
        StringBuffer sb = new StringBuffer();
        sb.append("amount=" + params.get("amount"))
                .append("merchant=" + params.get("merchant"))
                .append("notifyurl=" + params.get("notifyurl"))
                .append("orderid=" + params.get("orderid"))
                .append("ordertime=" + params.get("ordertime"))
                .append("paytype=" + params.get("paytype"))
                .append("returnurl=" + params.get("returnurl"))
                .append("signtype=" + params.get("signtype"))
                .append("version=" + params.get("version"));
        return sb.toString() + upPublicKey;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "快银支付回调内容：{}", params);
        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "快银支付回调订单：{}，重复回调", order.getOrderNo());
            return "10000";
        }

        String upMerchantKey = merchantChannel.getUpPublicKey();
        //验签
        boolean signVerify = verifySignParams(params, upMerchantKey);
        if (!signVerify) {
            LogByMDC.error(channelNo, "快银支付回调订单：{}，回调验签失败", order.getOrderNo());
            return "FAIL";
        }
        String trade_no = params.get("orderid");
        String trade_status = params.get("code");
        String amount = params.get("oamount");
        String msg = params.get("msg");

        if (!"10000".equals(trade_status)) {
            LogByMDC.error(channelNo, "快银支付回调订单：{}，支付未成功{}，不再向下通知", trade_no, msg);
            return "10000";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(trade_no);
        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "快银支付回调订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "快银支付回调订单：{}，下发通知失败{}", order.getOrderNo(), e.getMessage());
            throw new RException("下发通知报错:" + e.getMessage());
        }
        return "10000";
    }

    private boolean verifySignParams(Map<String, String> params, String upMerchantKey) {
        Map<String, String> treeMap = new TreeMap<>(params);
        String sign = treeMap.remove("sign");
        treeMap.remove("attach");
        treeMap.remove("msg");
        String signParams = SignatureUtils.buildParams(treeMap);
        signParams = signParams.replace("&", "");
        LogByMDC.info(channelNo, "快银支付回调订单:{}，参与验签参数:{}", treeMap.get("orderid"), signParams);
        String buildParams = signParams + upMerchantKey;
        String newSign = Md5Utils.MD5(buildParams);
        return newSign.equals(sign);
    }

}
