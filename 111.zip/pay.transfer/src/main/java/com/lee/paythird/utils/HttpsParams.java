package com.lee.paythird.utils;

import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.MediaType;
import org.springframework.util.LinkedMultiValueMap;
import org.springframework.util.MultiValueMap;

import java.util.Map;
import java.util.Set;

public class HttpsParams {

    public static HttpEntity<Object>  buildFormEntity(Map<String, String> params) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        Set<String> keySet = params.keySet();
        for (String key : keySet) {
            form.add(key, params.get(key));
        }

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Content-Type", MediaType.APPLICATION_FORM_URLENCODED_VALUE + ";charset=utf-8");
        return new HttpEntity<>(form, headers);
    }

    public static HttpEntity<Object>  buildFormEntity(Map<String, String> params, String header) {
        MultiValueMap<String, Object> form = new LinkedMultiValueMap<>();
        Set<String> keySet = params.keySet();
        for (String key : keySet) {
            form.add(key, params.get(key));
        }

        MultiValueMap<String, String> headers = new LinkedMultiValueMap<>();
        headers.add("Authorization", header);
        headers.add("Content-Type", MediaType.APPLICATION_FORM_URLENCODED_VALUE);
        return new HttpEntity<>(form, headers);
    }

}
