package com.lee.paythird.chenyitong;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.common.utils.RSAUtils;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 诚意通
 */
@Service(ChenYiTong.channelNo)
public class ChenYiTong extends AbstractPay {

    public static final String channelNo = "chenyitong";

    private final String payUrl = "http://gate.chengyitpay.com/api/pay/v2";

    private static final String md5Key = "228f5fe95c42868a79cd78d7e4e0185f";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public ChenYiTong() {
        payTypeMap.put(OutChannel.quickpay.name(), "UNIONFASTPAY");
        payTypeMap.put(OutChannel.alipay.name(), "UFALIPAY");
        payTypeMap.put(OutChannel.wechatpay.name(), "UFWECHAT");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "诚易通 支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }


        Map<String, String> map = new LinkedHashMap<>();
        map.put("p1_mchtid", upMerchantNo);
        map.put("p2_paytype", payType);//UNIONFASTPAY  UFALIPAY  UFWECHAT
        map.put("p3_paymoney", amount);
        map.put("p4_orderno", orderNo);
        map.put("p5_callbackurl", returnUrl);
        map.put("p6_notifyurl", "http://www.baidu.com/jump.aspx");
        map.put("p7_version", "v2.9");
        map.put("p8_signtype", "2");
        map.put("p9_attach", memo);
        map.put("p10_appname", "appname");
        map.put("p11_isshow", "0");
        map.put("p12_orderip", reqIp);
        map.put("p13_memberid", upMerchantNo);
        String str = SignatureUtils.buildParams(map, false);
        LogByMDC.info(channelNo, "诚易通 参与加签字符串{}", str);
        String sign = DigestUtils.md5Hex(str + md5Key);
        map.put("sign", sign);
        String rsaStr = JSON.toJSONString(map);
        LogByMDC.info(channelNo, "诚易通 参与加密字符{}, ", rsaStr);
        Map<String, String> mapRequest = new HashMap();
        try {
            String bytes = RSAUtils.encryptByPublicKey(rsaStr, upMerchantKey);
            mapRequest.put("mchtid", upMerchantNo);
            mapRequest.put("reqdata", URLEncoder.encode(bytes, "UTF-8"));
        } catch (Exception e) {
            throw new RException("诚易通RSA加密数据失败");
        }
        Map<String, String> resultMap = new HashMap<>();
        Map<String, String> returnMap = new HashMap<>();
        if (!"UNIONFASTPAY".equals(payType)) {
            String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(mapRequest), String.class);
            LogByMDC.info(channelNo, "诚易通 支付请求返回：{}", result);
            //验签
            resultMap = verifyResultMap(result);
            saveOrder(jObj, channelNo, upMerchantNo);
            returnMap.put(OrderParamKey.orderNo.name(), orderNo);
            returnMap.put(OrderParamKey.outChannel.name(), outChannel);
            returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
            returnMap.put(OrderParamKey.channelNo.name(), channelNo);
            returnMap.put(OrderParamKey.amount.name(), amount);
            returnMap.put(PayConstants.web_code_url, resultMap.get("r6_qrcode"));
        } else {
            returnMap.put(OrderParamKey.orderNo.name(), orderNo);
            returnMap.put(OrderParamKey.outChannel.name(), outChannel);
            returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
            returnMap.put(OrderParamKey.channelNo.name(), channelNo);
            returnMap.put(OrderParamKey.amount.name(), amount);
            returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, mapRequest));
        }
        return R.ok().put(Constant.result_data, returnMap);
    }

    private Map<String, String> verifyResultMap(String result) {
        try {
            result = URLDecoder.decode(result, "UTF8");
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
        }
        Map<String, String> map = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String rspCode = map.get("rspCode");
        String rspMsg = map.get("rspMsg");
        if (!"1".equals(rspCode)) {
            throw new RException("支付失败，上游返回：" + rspMsg);
        }
        //data转成map
        String data = map.get("data");
        Map<String, String> dataMap = JSON.parseObject(data, new TypeReference<TreeMap<String, String>>() {
        });
        String r4_amount = dataMap.get("r4_amount");
        dataMap.put("r4_amount",new BigDecimal(r4_amount).intValue()+"");
        LogByMDC.info(channelNo, "诚易通 验签data数据{}", JSON.toJSONString(data));
        //验签
        String sign = dataMap.remove("sign");
        String str = SignatureUtils.buildParams(dataMap, true);
        String signNew = DigestUtils.md5Hex(str + md5Key);
        if (!sign.equals(signNew)){
            LogByMDC.info(channelNo, "诚易通 验签失败");
            throw new RException("诚易通验签失败");
        }
        return dataMap;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "诚易通回调 内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "诚易通回调订单：{}，重复回调", order.getOrderNo());
            return "ok";
        }

        String privateKey = merchantChannel.getUpPrivateKey();

        String ordernumber = params.get("ordernumber");
        String reqdata = params.get("reqdata");
        //解密
        Map<String, String> dataMap = decryptionReqData(reqdata, privateKey);
        String paymoney = dataMap.get("paymoney");
        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(paymoney));
        order.setBusinessNo(ordernumber);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "诚易通回调 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "诚易通回调 订单：{}，下发通知失败", order.getOrderNo());
        }
        return "ok";
    }

    private Map<String, String> decryptionReqData(String reqData, String upPrivateKey) {
        Assert.isTrue(StringUtils.isAnyEmpty(upPrivateKey, reqData), "商户私钥为空或回调参数为空");
        Map<String, String> dataMap;
        try {
            String decodeStr = URLDecoder.decode(reqData, "UTF-8");
            String data = new String(RSAUtils.decryptByPrivateKey(decodeStr.getBytes(), upPrivateKey));
            dataMap = JSON.parseObject(data, new TypeReference<Map<String, String>>() {
            });
            LogByMDC.info(channelNo, "诚易通回调解密数据{}", data);
        } catch (Exception e) {
            e.printStackTrace();
            throw new RException("诚易通回调数据解密失败");
        }
        //验签
        String sign = dataMap.remove("sign");
        String str = SignatureUtils.buildParams(dataMap, false);
        String signNew = DigestUtils.md5Hex(str + md5Key);
        Assert.isTrue(sign.equals(signNew), "诚易通回调 验签失败");
        return dataMap;
    }
}
