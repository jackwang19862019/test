package com.lee.paythird.daxuan;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service(DaXuan.channelNo)
public class DaXuan extends AbstractPay {

    public static final String channelNo = "daxuan";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public DaXuan() {
        payTypeMap.put(OutChannel.wechath5.name(), "901");
        payTypeMap.put(OutChannel.wechatpay.name(), "902");
        payTypeMap.put(OutChannel.alipay.name(), "903");
        payTypeMap.put(OutChannel.alih5.name(), "904");
        payTypeMap.put(OutChannel.qqh5.name(), "905");
        payTypeMap.put(OutChannel.unionpay.name(), "907");
        payTypeMap.put(OutChannel.qqpay.name(), "908");
        payTypeMap.put(OutChannel.baidupay.name(), "909");
        payTypeMap.put(OutChannel.jdpay.name(), "910");
    }

    private final String payUrl = "http://www.linxuans.com/Pay_Index.html";


    //TODO: 无法连接支付服务器!
    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());

        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

        Date now = new Date();

        Map<String, String> params = new HashMap<>();
        //商户号
        params.put("pay_memberid", upMerchantNo);
        //订单号
        params.put("pay_orderid", orderNo);
        //提交时间  时间格式：2016-12-26 18:18:18
        params.put("pay_applydate", sdf.format(now));
        //银行编码
        params.put("pay_bankcode", payType);
        //服务端通知
        params.put("pay_notifyurl", getCallbackUrl(channel.getChannelNo(), merchNo, orderNo));
        //页面跳转通知
        params.put("pay_callbackurl", returnUrl);
        //订单金额
        params.put("pay_amount", amount);


        String paramStr = SignatureUtils.buildParams(params);

        String sign = SignatureUtils.getMD5(paramStr + "&key=" + upMerchantKey);

        //商品名称
        params.put("pay_productname", product);

        //MD5签名
        params.put("pay_md5sign", sign.toUpperCase());


        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        return null;
    }
}
