package com.lee.paythird.hanfu;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.Md5Util;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 悍付
 */
@Service(HanFu.channelNo)
public class HanFu extends AbstractPay {

    static final String channelNo = "hanfu";

    static final String payUrl = "https://www.hanpays.co/data/api/hanshi/receivables";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public HanFu() {
        payTypeMap.put(OutChannel.alipay.name(), "alipay");
        payTypeMap.put(OutChannel.alih5.name(), "alipayH5");
        payTypeMap.put(OutChannel.aliwap.name(), "alipayCard");

        payTypeMap.put(OutChannel.wechatpay.name(), "wechat");

        payTypeMap.put(OutChannel.unionpay.name(), "quickpayQR");
        payTypeMap.put(OutChannel.unionh5.name(), "quickpayH5");

        payTypeMap.put(OutChannel.unionsm.name(), "unionpayQR");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "悍付支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());


        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> dataMap = new TreeMap<>();
        amount = new BigDecimal(amount).intValue() + "";

        dataMap.put("scode", upMerchantNo);
        dataMap.put("orderid", orderNo);
        dataMap.put("paytype", payType);
        dataMap.put("amount", amount);
        dataMap.put("productname", product);
        dataMap.put("memo", product);
        dataMap.put("currcode", "CNY");
        dataMap.put("callback", getCallbackUrl(channelNo, merchNo, orderNo));
        dataMap.put("return_url", returnUrl);

        String signParams = buildSignParams(dataMap) + "&" + upMerchantKey;
        LogByMDC.info(channelNo, "悍付支付签名 订单：{}，参与签名参数：{}", orderNo, signParams);
        String sign = Md5Util.MD5(signParams);
        dataMap.put("sign", sign);

        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(dataMap), String.class);
        LogByMDC.info(channelNo, "悍付支付响应 订单：{}，response：{}", orderNo, result);
        String resultStr = "Moved Permanently. Redirecting to";
        String qrCode;
        if (result.contains(resultStr)) {
            qrCode = result.replace(resultStr, "").trim();
        } else {
            LogByMDC.info(channelNo, "悍付支付响应 订单：{}，上游返回：{}", orderNo, result);
            return R.error("上游返回：" + result);
        }

        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }

    private String buildSignParams(Map<String, String> dataMap) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(dataMap.get("scode") + "|");
        stringBuilder.append(dataMap.get("orderid") + "|");
        stringBuilder.append(dataMap.get("amount") + "|");
        stringBuilder.append(dataMap.get("currcode") + "|");
        stringBuilder.append(dataMap.get("callback"));
        return stringBuilder.toString();
    }


    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "悍付回调内容：{}", params);
        if (order == null) {
            String orderid = params.get("orderid");
            String rspmsg = params.get("rspmsg");
            LogByMDC.error(channelNo, "悍付订单：{}，无状态回调,支付请求失败没必要回调：{}", orderid, rspmsg);
            //啥姿势都有
            return "success";
        }
        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "悍付订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        String upMerchantKey = merchantChannel.getUpPublicKey();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String sign = params.remove("sign");
        //验签
        String signVerify = buildVerifySignParams(params, upMerchantNo) + "&" + upMerchantKey;
        LogByMDC.info(channelNo, "悍付回调签名 订单：{}，参与验签参数：{}", order.getOrderNo(), signVerify);
        signVerify = Md5Util.MD5(signVerify);

        if (!sign.equals(signVerify)) {
            LogByMDC.error(channelNo, "悍付订单：{}，回调验签失败,验签参数:{}", order.getOrderNo(), signVerify);
            return "fail";
        }
        String trade_no = params.get("orderno");
        String trade_status = params.get("status");
        String amount = params.get("realAmount");

        if (!"1".equals(trade_status)) {
            LogByMDC.error(channelNo, "悍付订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            return "success";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(trade_no);

        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "悍付订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "悍付订单：{}，下发通知失败", order.getOrderNo());
        }
        return "success";
    }

    private String buildVerifySignParams(Map<String, String> params, String upMerchantNo) {
        StringBuilder stringBuilder = new StringBuilder();
        stringBuilder.append(upMerchantNo + "|");
        stringBuilder.append(params.get("orderid") + "|");
        stringBuilder.append(params.get("amount") + "|");
        stringBuilder.append(params.get("status") + "|");
        stringBuilder.append(params.get("realAmount"));
        return stringBuilder.toString();
    }

}
