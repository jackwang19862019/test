package com.lee.paythird.k1pay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.ydw360.utils.ToolKit;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

@Service(K1Pay.channelNo)
public class K1Pay extends AbstractPay {

    public static final String channelNo = "k1pay";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public K1Pay() {
        payTypeMap.put(OutChannel.wechatwap.name(), "901");
        payTypeMap.put(OutChannel.wechatpay.name(), "902");
        payTypeMap.put(OutChannel.alipay.name(), "903");
        payTypeMap.put(OutChannel.alih5.name(), "904");
        payTypeMap.put(OutChannel.qqh5.name(), "905");
        payTypeMap.put(OutChannel.quickpay.name(), "907");
        payTypeMap.put(OutChannel.qqpay.name(), "908");
        payTypeMap.put(OutChannel.baidupay.name(), "909");
        payTypeMap.put(OutChannel.jdpay.name(), "910");
        payTypeMap.put(OutChannel.wechath5.name(), "911");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String payUrl = channelObj.getString("payUrl");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = new Date();

        Map<String, String> params = new TreeMap<>();
        //商户号
        params.put("pay_memberid", merchantChannel.getUpMerchantNo());
        //订单号
        params.put("pay_orderid", orderNo);
        //提交时间  时间格式：2016-12-26 18:18:18
        params.put("pay_applydate", sdf.format(now));
        //银行编码
        params.put("pay_bankcode", payType);
        //服务端通知
        params.put("pay_notifyurl", getCallbackUrl(channel.getChannelNo(), merchNo, orderNo));
        //页面跳转通知
        params.put("pay_callbackurl", returnUrl);
        //订单金额
        params.put("pay_amount", amount);


        String paramStr = SignatureUtils.buildParams(params);

        String sign = SignatureUtils.getMD5(paramStr + "&key=" + merchantChannel.getUpPublicKey());

        //商品名称
        params.put("pay_productname", product);

        //MD5签名
        params.put("pay_md5sign", sign.toUpperCase());

        LogByMDC.info(channelNo, "快易支付发送给上游的参数：{}", JSON.toJSONString(params));

        String result = ToolKit.request(payUrl, SignatureUtils.buildParams(params));
        LogByMDC.info(channelNo, "上游返回参数：{}", result);
        JSONObject jsonObject = null;
        try {
            jsonObject = JSON.parseObject(result);
            String msg = jsonObject.getString("msg");
            LogByMDC.error(channelNo, "订单：{}，上游返回：{}", orderNo, msg);
            return R.error("上游返回：" + msg);
        } catch (JSONException e) {
            saveOrder(jObj, channel.getChannelNo(), merchantChannel.getUpMerchantNo());

            Map<String, String> resultMap = new HashMap<>();
            resultMap.put(OrderParamKey.orderNo.name(), orderNo);
            resultMap.put(OrderParamKey.outChannel.name(), outChannel);
            resultMap.put(OrderParamKey.merchNo.name(), merchNo);
            resultMap.put(OrderParamKey.channelNo.name(), channel.getChannelNo());
            resultMap.put(PayConstants.pay_form, result);
            resultMap.put(OrderParamKey.amount.name(), amount);

            return R.ok().put(Constant.result_data, resultMap);
        }

    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {

        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String queryUrl = channelObj.getString("queryUrl");

        Map<String, String> params = new HashMap<>();
        params.put("pay_memberid", merchantChannel.getUpMerchantNo());
        params.put("pay_orderid", order.getOrderNo());

        params.put("pay_md5sign", SignatureUtils.sign(params, "&key=" + merchantChannel.getUpPublicKey()).toUpperCase());

        String result = ToolKit.request(queryUrl, SignatureUtils.buildParams(params));
        LogByMDC.info(channelNo, "查询订单：{}，返回：{}", order.getOrderNo(), result);

        Map<String, String> resultMap = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String originSign = resultMap.get("sign");
        resultMap.remove("sign");

        String sign = SignatureUtils.sign(resultMap, "&key=" + merchantChannel.getUpPublicKey()).toUpperCase();
        if (sign.equals(originSign)) {
            //商户编号
            String memberid = resultMap.get("memberid");
            //订单号
            String orderid = resultMap.get("orderid");
            //订单金额
            String amount = resultMap.get("amount");
            //支付成功时间
            String time_end = resultMap.get("time_end");
            //交易流水号
            String transaction_id = resultMap.get("transaction_id");
            //交易状态
            String returncode = resultMap.get("returncode");
            //交易状态
            String trade_state = resultMap.get("trade_state");
            if ("00".equals(returncode) && "SUCCESS".equals(trade_state)) {
                order.setOrderState(OrderState.succ.id());
                orderService.update(order);
            } else {
                LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", order.getOrderNo());
            }

        }

        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }

        String originSign = params.get("sign");
        params.remove("sign");
        params.remove("attach");

        String paramStr = SignatureUtils.buildParams(params);

        String sign = SignatureUtils.getMD5(paramStr + "&key=" + merchantChannel.getUpPublicKey()).toUpperCase();

        if (!sign.equals(originSign)) {
            LogByMDC.error(channelNo, "回调订单：{}，签名验证失败", order.getOrderNo());
            return "OK";
        }

        //商户编号
        String memberid = params.get("memberid");
        //订单号
        String orderid = params.get("orderid");
        //订单金额
        String amount = params.get("amount");
        //交易流水号
        String transaction_id = params.get("transaction_id");
        //交易状态
        String returncode = params.get("returncode");

        if (!"00".equals(returncode)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderid);
            return "OK";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(transaction_id);

        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "OK";
    }
}
