package com.lee.paythird.epaiyun;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.NoticeState;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.pay.service.MerchantChannelService;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service(EPaiYun.channelNo)
public class EPaiYun extends AbstractPay {

    public static final String channelNo = "epaiyun";

    private final String payUrl = "http://pay.eekio.cn/pay/index";

    private final String queryUrl = "http://pay.eekio.cn/pay/index/getOrderInfo";

    @Autowired
    private MerchantChannelService merchantChannelService;

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {

        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        OrderEntity order = JSONObject.toJavaObject(jObj, OrderEntity.class);
        order.setOrderState(OrderState.init.id());
        order.setCrtDate(new Date());
        order.setNoticeState(NoticeState.init.id());
        order.setPayCompany(channelNo);
        order.setPayMerch(upMerchantNo);
        order = orderService.save(order);
        Long orderId = order.getOrderId();

        Map<String, String> params = new HashMap<>();
        params.put("order_sn", String.valueOf(orderId));
        params.put("type", "html");
        params.put("appid", upMerchantNo);
        params.put("money", amount);

        String signParams = String.format("appid=%s&money=%s&order_sn=%s&api_key=%s",
                upMerchantNo, amount, orderNo, upMerchantKey);

        params.put("sign", SignatureUtils.sign(signParams, ""));
        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        Map<String, String> params = new HashMap<>();
        params.put("appid", upMerchantNo);
        params.put("order_sn", String.valueOf(order.getOrderId()));

        String signParams = String.format("appid=%s&order_sn=%s&api_key=%s",
                upMerchantNo, orderNo, upMerchantKey);

        params.put("sign", SignatureUtils.sign(signParams, ""));

        LogByMDC.info(channelNo, "查询订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(queryUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "查询订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String status = params.get("status");
        if (!"1".equals(status)) {
            String errMsg = params.get("message");
            LogByMDC.error(channelNo, "订单：{}，上游返回：" + errMsg);
            throw new RException("上游返回：" + errMsg);
        }

        params = JSON.parseObject(params.get("data"), new TypeReference<Map<String, String>>() {
        });

        status = params.get("status");
        //订单状态 wait:待支付 payed:已支付 expire:已过期 fixed:手动补单
        if ("payed".equals(status) || "fixed".equals(status)) {
            String price = params.get("price");

            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(price));
            orderService.update(order);
        } else {
            LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", order.getOrderNo());
        }

        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);

        String order_sn = params.get("order_sn");

        order = orderService.selectById(Long.valueOf(order_sn));
        String orderNo = order.getOrderNo();

        merchantChannel = merchantChannelService.selectByMerchantNoAndChannelNo(order.getMerchNo(), channelNo);
        String upMerchantKey = merchantChannel.getUpPrivateKey();


        String price = params.get("price");
        String time = params.get("time");

        String upSign = params.get("sign");

        String signParams = String.format("order_sn=%s&price=%s&time=%s&api_key=%s",
                order_sn, price, time, upMerchantKey);

        String sign = SignatureUtils.sign(signParams, "");
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return "success";
        }

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(price));
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "success";
    }
}
