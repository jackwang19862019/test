package com.lee.paythird;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.R;
import com.lee.pay.entity.*;

import java.util.Map;

public interface PayService {

    default R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        throw new RException("该通道不支持支付");
    }

    default R orderAcp(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        throw new RException("该通道不支持代付");
    }

    default OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        throw new RException("该通道不支持查询");
    }

    default OrderAcpEntity queryAcp(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderAcpEntity orderAcp) {
        throw new RException("该通道不支持代付查询");
    }

    default String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        return "SUCCESS";
    }

    default String acpCallback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderAcpEntity order, Map<String, String> params) {
        return "SUCCESS";
    }


}
