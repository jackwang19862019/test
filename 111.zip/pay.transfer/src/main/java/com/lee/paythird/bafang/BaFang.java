package com.lee.paythird.bafang;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

/**
 * 八方
 */
@Service(BaFang.channelNo)
public class BaFang extends AbstractPay {

    public static final String channelNo = "bafang";

    private final String payUrl = "https://bafang.site/get_way/?密码：58shouyou666";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public BaFang() {
        payTypeMap.put(OutChannel.alipay.name(), "ali");
        payTypeMap.put(OutChannel.wechatpay.name(), "wx");
        payTypeMap.put(OutChannel.unionpay.name(), "un");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        Map<String, String> params = new HashMap<>();
        //商户编号
        params.put("mid", upMerchantNo);
        //订单编号，唯一，不能重复发起
        params.put("order", orderNo);
        //订单金额，单位:分
        params.put("amount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        //版本号,目前固定值为2
        params.put("ver", "2");
        //支付方式，ali支付宝 wx微信 un银联
        params.put("type", payType);
        //时间戳，毫秒
        params.put("time", String.valueOf(System.currentTimeMillis()));
        //异步通知地址
        params.put("notify", getCallbackUrl(channelNo, merchNo, orderNo));
        //部分产品付款成功后可以跳转到用户指定的页面
        params.put("return", returnUrl);
        //部分通道需要传唯一用户标识符
        params.put("uuid", userId);
        //终端用户的ip，建议传输此值，传入此值会精确匹配当前城市的用户，提高付款成功率，部分产品不传输此值，将无法获取支付链接
        params.put("ip", reqIp);

        String sign = SignatureUtils.sign(params, "&key=" + upMerchantKey).toUpperCase();
        params.put("sign", sign);

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>(){});

        String msg = params.get("msg");
        if (!"ok".equals(msg)) {
            String err = params.get("err");
            LogByMDC.info("订单：{}，上游返回：{}", orderNo, err);
            return R.error("上游返回：" + err);
        }

        //实际需要支付的金额，单位:分
        String amount_pay = params.get("amount_pay");
        String qrcode = params.get("qrcode");

        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), new BigDecimal(amount_pay).multiply(new BigDecimal("0.01")).toString());
        returnMap.put(PayConstants.web_code_url, qrcode);
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "ok";
        }

        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String upSign = params.get("sign");
        params.remove("sign");

        String sign = SignatureUtils.sign(params, "&key=" + upMerchantKey).toUpperCase();
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return "fail";
        }

        String pay_result = params.get("pay_result");
        if (!"1".equals(pay_result)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "ok";
        }

        //平台订单号
        String sys_no = params.get("sys_no");
        //实际支付金额，单位:分
        String amount_pay = params.get("amount_pay");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount_pay).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(sys_no);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "八方支付 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }
        return "SUCCESS";
    }
}
