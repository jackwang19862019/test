package com.lee.paythird.ok;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.Map;

/**
 * @author lee
 * @date 2019-07-25 13:39
 */
@Service(OKPay.channelNo)
public class OKPay extends AbstractPay {

    public static final String channelNo = "ok";

    private final String payUrl = "https://pay.oooko.com/";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public OKPay() {
        payTypeMap.put(OutChannel.alipay.name(), "1");
        payTypeMap.put(OutChannel.wechatpay.name(), "2");
        payTypeMap.put(OutChannel.qqpay.name(), "3");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        DecimalFormat df = new DecimalFormat("#.00");

        Map<String, String> params = new HashMap<>();
        //商户uid
        params.put("uid", upMerchantNo);
        //必填。单位：元。精确小数点后2位
        params.put("price", df.format(new BigDecimal(amount)));
        //
        params.put("istype", payType);
        //通知回调网址
        params.put("notify_url", getCallbackUrl(channelNo, merchNo, orderNo));
        //跳转网址
        params.put("return_url", returnUrl);
        //商户自定义订单号
        params.put("orderid", orderNo);
        //商户自定义客户号
        params.put("orderuid", userId);
        //商品名称
        params.put("goodsname", product);
        //协议版本号
        params.put("version", "2");
        //支付用户的真实IP
        params.put("ip", reqIp);

        String sign = sign(params, upMerchantKey);
        params.put("key", sign);

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));

        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.pay_form, BuildFormUtils.buildSubmitForm(payUrl, params));
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        //一定存在。不参与签名 请判断当状态为3时，为支付成功回调。 1-支付中,2-失败,3-成功,4-超时关闭,5-无可用二维码
        String status = params.get("status");

        String upSign = params.get("key");
        params.remove("key");
        params.remove("status");

        String sign = sign(params, upMerchantKey);
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return "fail";
        }
        if (!"3".equals(status)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "success";
        }

        String realprice = params.get("realprice");
        //上游订单号
        String paysapi_id = params.get("paysapi_id");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(realprice));
        order.setBusinessNo(paysapi_id);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "success";
    }


    private String sign(Map<String, String> params, String key) {
        Map<String, String> map = new HashMap<>(params);
        map.put("token", key);

        String paramStr = SignatureUtils.buildParams(map);
        System.out.println(paramStr);

        return SignatureUtils.sign(paramStr, "").toLowerCase();
    }
}
