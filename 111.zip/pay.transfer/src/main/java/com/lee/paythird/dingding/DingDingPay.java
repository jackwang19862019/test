package com.lee.paythird.dingding;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.QRCodeUtils;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 钉钉（上海原先接了，没用这个）
 */
@Service(DingDingPay.channelNo)
public class DingDingPay extends AbstractPay {

    public static final String channelNo = "dingding";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public DingDingPay() {
        payTypeMap.put(OutChannel.alih5.name(), "aliPayH5");
        payTypeMap.put(OutChannel.alipay.name(), "aliPaySM");
        //维护
        payTypeMap.put(OutChannel.wechath5.name(), "wxPayH5");
        payTypeMap.put(OutChannel.wechatpay.name(), "wxPaySM");
        payTypeMap.put(OutChannel.unionpay.name(), "unionPaySM");
        //维护
        payTypeMap.put(OutChannel.unionwap.name(), "unionPayWG");
        //维护
        payTypeMap.put(OutChannel.quickpay.name(), "unionPayKJ");
        payTypeMap.put(OutChannel.jdpay.name(), "jdPaySM");
        payTypeMap.put(OutChannel.qqpay.name(), "qqPayQB");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }


        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String payUrl = channelObj.getString("payUrl");

        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date now = new Date();

        Map<String, String> params = new TreeMap<>();
        //接口版本号
        params.put("version", "v1.0");
        //接口类型
        params.put("type", payType);
        //商户编号
        params.put("userId", merchantChannel.getUpMerchantNo());
        //商户流水号
        params.put("requestNo", orderNo);
        //订单金额  订单金额，以分为单位，如1 元传为100
        params.put("amount", new BigDecimal(amount).multiply(new BigDecimal("100")).intValue() + "");
        //异步回调地址
        params.put("callBackURL", getCallbackUrl(channel.getChannelNo(), merchNo, orderNo));
        //前台回调地址 支付完成后跳转地址，补 充:此项不一定支持跳转
        params.put("redirectUrl", returnUrl);

        String paramStr = SignatureUtils.buildParams(params);

        String sign = SignatureUtils.getMD5(paramStr + "&key=" + merchantChannel.getUpPublicKey());

        //MD5签名
        params.put("sign", sign);

        LogByMDC.info(channelNo, "发送给钉钉支付的参数：{}", JSON.toJSONString(params));

        String result = restTemplate.postForObject(payUrl, params, String.class);
        LogByMDC.info(channelNo, "订单：{}，上游返回参数：{}", orderNo, result);
        Map<String, String> resultMap = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });

        String status = resultMap.get("status");
        if (!"1".equals(status)) {
            LogByMDC.error(channelNo, "订单：{}，上游返回状态未成功，消息：{}", orderNo, resultMap.get("message"));
            return R.error(resultMap.get("message"));
        }


        String upPayUrl = resultMap.get("payUrl");
        String payHTML = resultMap.get("payHTML");
        String requestNo = resultMap.get("requestNo");
        String upOrderNo = resultMap.get("orderNo");

        String originSign = resultMap.get("sign");
        resultMap.remove("sign");
        resultMap.remove("payUrl");
        resultMap.remove("payHTML");

        sign = SignatureUtils.sign(resultMap, "&key=" + merchantChannel.getUpPublicKey());
        if (!sign.equals(originSign)) {
            LogByMDC.error(channelNo, "订单：{}，上游返回信息验证签名失败", orderNo);
            return R.error("上游返回信息验证签名失败");
        }


        saveOrder(jObj, channel.getChannelNo(), merchantChannel.getUpMerchantNo());


        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channel.getChannelNo());
        returnMap.put(OrderParamKey.amount.name(), amount);

        if (StringUtils.isNotBlank(payHTML)) {
            returnMap.put(PayConstants.pay_form, payHTML);
        } else {
            switch (payType) {
                case "aliPaySM":
                case "unionPaySM":
                case "jdPaySM":
                    returnMap.put(PayConstants.web_qrcode_url, "data:image/png;base64," + QRCodeUtils.generate(upPayUrl));
                    break;
                case "wxPaySM":
                    returnMap.put(PayConstants.web_qrcode_url, upPayUrl);
                    break;
                default:
                    returnMap.put(PayConstants.web_code_url, upPayUrl);
            }
        }

        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String queryUrl = channelObj.getString("queryUrl");

        Map<String, String> params = new HashMap<>();
        //商户编号
        params.put("userId", merchantChannel.getUpMerchantNo());
        //商户流水号
        params.put("requestNo", order.getOrderNo());

        params.put("sign", SignatureUtils.sign(params, "&key=" + merchantChannel.getUpPublicKey()));

        String result = restTemplate.postForObject(queryUrl, params, String.class);
        LogByMDC.info(channelNo, "查询订单：{}，返回：{}", order.getOrderNo(), result);

        Map<String, String> resultMap = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });

        String message = resultMap.get("message");
        if (StringUtils.isNotBlank(message) && !"000000".equals(message)) {
            LogByMDC.error(channelNo, "订单：{}，上游返回：{}", message);
            throw new RException("上游返回：" + message);
        }

        String originSign = resultMap.get("sign");
        resultMap.remove("sign");
        resultMap.remove("attachData");

        String sign = SignatureUtils.sign(resultMap, "&key=" + merchantChannel.getUpPublicKey());
        if (!sign.equals(originSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证上游返回签名不一致", order.getOrderNo());
            throw new RException("验证上游返回签名错误");
        }

        String status = resultMap.get("status");

        if ("00".equals(status)) {
            String payAmount = resultMap.get("payAmount");
            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(payAmount).multiply(new BigDecimal("0.01")));
            orderService.update(order);
        } else {
            LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", order.getOrderNo());
        }
        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {

        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }

        String originSign = params.get("sign");
        params.remove("sign");
        params.remove("attachData");

        String paramStr = SignatureUtils.buildParams(params);

        String sign = SignatureUtils.getMD5(paramStr + "&key=" + merchantChannel.getUpPublicKey());

        if (!sign.equals(originSign)) {
            LogByMDC.error(channelNo, "回调订单：{}，签名验证失败", order.getOrderNo());
            return "000000";
        }

        //商户编号
        String userId = params.get("userId");
        //状态
        // 1:预下单成功 2:预下单失败 3:交易成功
        //4 :交易失败 5:交易超时
        //6 :交易中
        String status = params.get("status");
        //成功则返回”000000”,失败返 回原因
        String message = params.get("message");
        //订单金额 订单金额，以分为单位，如1元 表示为100
        String amount = params.get("amount");
        //实际支付金额 实际支付金额，以分为单位，如 1元表示为100
        String payAmount = params.get("payAmount");
        //商户流水号
        String requestNo = params.get("requestNo");
        //系统流水号
        String orderNo = params.get("orderNo");
        //支付时间
        String payTime = params.get("payTime");


        if (!"3".equals(status)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", requestNo);
            return "000000";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(payAmount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(orderNo);

        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "钉钉支付 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }


        return "000000";
    }
}
