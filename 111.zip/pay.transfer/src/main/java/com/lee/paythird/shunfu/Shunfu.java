package com.lee.paythird.shunfu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.QRCodeUtils;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;

/**
 * 顺付
 */
@Service(Shunfu.channelNo)
public class Shunfu extends AbstractPay {
    //顺付
    public static final String channelNo = "shunfu";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public Shunfu() {
        payTypeMap.put(OutChannel.quickpay.name(), "QUICK");
        payTypeMap.put(OutChannel.unionpay.name(), "B2C");


        payTypeMap.put(OutChannel.alih5.name(), "ALI_H5");
        payTypeMap.put(OutChannel.wechath5.name(), "WECHAT_H5");
        payTypeMap.put(OutChannel.wechatpay.name(), "WECHAT_NATIVE");
    }


    private final String gatewayPayUrl = "http://www.fjzyrl.com/api/open/gatewayPay";

    private final String juhePayUrl = "http://www.fjzyrl.com/api/open/unifiedPay";

    private final String queryUrl = "http://www.fjzyrl.com/api/open/query/queryTradeOrder";


    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        if (payType.equals("QUICK") || payType.equals("B2C")) {
            return gateway(channel, merchant, merchantChannel, jObj);
        } else {
            return juhe(channel, merchant, merchantChannel, jObj);
        }
    }

    @Override
    public OrderEntity query(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order) {
        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        Map<String, String> params = new HashMap<>();
        params.put("orderNumber", orderNo);
        params.put("merchantNumber", upMerchantNo);

        params.put("key", upMerchantKey);

        params.put("sign", SignatureUtils.sign(params, ""));
        params.remove("key");

        LogByMDC.info(channelNo, "查询订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(queryUrl, params, String.class);
        LogByMDC.info(channelNo, "查询订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });

        String success = params.get("success");
        if (!"true".equals(success)) {
            params = JSON.parseObject(params.get("message"), new TypeReference<Map<String, String>>() {
            });
            LogByMDC.error(channelNo, "查询订单：{}， 上游返回：{}", orderNo, params.get("content"));
            throw new RException("上游返回：" + params.get("content"));
        }

        params = JSON.parseObject(params.get("context"), new TypeReference<Map<String, String>>() {
        });

        String upSign = params.get("sign");
        params.remove("sign");
        params.put("key", upMerchantKey);

        String sign = SignatureUtils.sign(params, "");
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，上游返回签名校验错误", orderNo);
            throw new RException("上游返回签名校验错误");
        }

        String orderNumber = params.get("orderNumber");
        String orderStatus = params.get("orderStatus");
        String amount = params.get("amount");

        if ("SUC".equals(orderStatus)) {
            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
            order.setBusinessNo(orderNumber);
            orderService.update(order);
        } else {
            LogByMDC.warn(channelNo, "查询订单：{}，尚未支付成功", orderNo);
        }

        return order;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "SUC";
        }

        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String upSign = params.get("sign");
        params.remove("sign");
        params.put("key", upMerchantKey);

        String sign = SignatureUtils.sign(params, "");
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，验证回调签名错误", orderNo);
            return "SUC";
        }

        String orderStatus = params.get("orderStatus");
        if (!"SUC".equals(orderStatus)) {
            LogByMDC.error(channelNo, "订单：{}，支付未成功，不再向下通知", orderNo);
            return "SUC";
        }

        String amount = params.get("amount");
        String orderNumber = params.get("orderNumber");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(orderNumber);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "订单：{}，下发通知失败", order.getOrderNo());
        }

        return "SUC";
    }


    private R gateway(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());


        String payType = payTypeMap.get(outChannel);

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new HashMap<>();
        //商户号
        params.put("merchantNumber", upMerchantNo);
        //默认V2.0.0
        params.put("version", "V2.0.0");
        //商户单号
        params.put("orderNumber", orderNo);
        //交易金额 以分为单位，1.00元填入值为100
        params.put("amount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        //CNY-人民币，默认为CNY
        params.put("currency", "CNY");
        try {
            String goods = URLEncoder.encode(product, "UTF-8");
            //商品名称
            params.put("commodityName", goods);
            //商品描述
            params.put("commodityDesc", goods);
        } catch (UnsupportedEncodingException e) {
            LogByMDC.error(channelNo, "商品URLEncoder错误");
            return R.error("URLEncoder错误");
        }
        //支付类型
        params.put("payType", payType);
        //"银行卡类型。 储蓄卡：SAVINGS"
        params.put("cardType", "SAVINGS");
        //客户端IP
        params.put("orderCreateIp", reqIp);
        //银行编号
        params.put("bankNumber", "1000");
        //页面返回地址
        params.put("returnUrl", returnUrl);
        //异步通知地址
        params.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        //商户平台中的用户唯一编号
        params.put("userId", userId);

        params.put("key", upMerchantKey);

        String sign = SignatureUtils.sign(params, "");
        params.remove("key");

        params.put("sign", sign);

        saveOrder(jObj, channelNo, params.get("merchant_code"));


        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, gatewayPayUrl + "?" + SignatureUtils.buildParams(params));
        return R.ok().put(Constant.result_data, returnMap);
    }


    private R juhe(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());


        String payType = payTypeMap.get(outChannel);

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> params = new HashMap<>();
        //商户号
        params.put("merchantNumber", upMerchantNo);
        //默认V2.0.0
        params.put("version", "V2.0.0");
        //商户单号
        params.put("orderNumber", orderNo);
        //交易金额 以分为单位，1.00元填入值为100
        params.put("amount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        //CNY-人民币，默认为CNY
        params.put("currency", "CNY");
        //商品名称
        params.put("commodityName", product);
        //商品描述
        params.put("commodityDesc", product);
        //支付类型
        params.put("payType", payType);
        //客户端IP
        params.put("orderCreateIp", reqIp);
        //异步通知地址
        params.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));

        params.put("key", upMerchantKey);

        String sign = SignatureUtils.sign(params, "");
        params.remove("key");

        params.put("sign", sign);

        LogByMDC.info(channelNo, "订单：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(juhePayUrl, params, String.class);
        LogByMDC.info(channelNo, "订单：{}，response：{}", orderNo, result);

        params = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });

        String success = params.get("success");
        if (!"true".equals(success)) {
            params = JSON.parseObject(params.get("message"), new TypeReference<Map<String, String>>() {
            });
            LogByMDC.error(channelNo, "上游返回：{}", params.get("content"));
            return R.error("上游返回：" + params.get("content"));
        }

        params = JSON.parseObject(params.get("context"), new TypeReference<Map<String, String>>() {
        });

        String upSign = params.get("sign");
        params.remove("sign");
        params.put("key", upMerchantKey);

        sign = SignatureUtils.sign(params, "");
        if (!sign.equals(upSign)) {
            LogByMDC.error(channelNo, "订单：{}，上游返回签名校验错误", orderNo);
            return R.error("上游返回签名校验错误");
        }

        String orderNumber = params.get("orderNumber");

        String payUrl = params.get("payurl");

        saveOrder(jObj, channelNo, upMerchantNo, orderNumber);


        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_qrcode_url, "data:image/png;base64," + QRCodeUtils.generate(payUrl));
        return R.ok().put(Constant.result_data, returnMap);
    }
}
