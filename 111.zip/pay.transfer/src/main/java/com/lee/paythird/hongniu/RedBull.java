package com.lee.paythird.hongniu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.DateUtil;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLDecoder;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 红牛
 */
@Service(RedBull.channelNo)
public class RedBull extends AbstractPay {

    public static final String channelNo = "hongniu";

    private static final String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlzkstCGepbr/6+5c0vgCTZsDwqDttOJqROlFJp7YUD7cVcmqW8ljkw4RnFuAMqGt1wBYh50F8kG4alz2HnHxSx99DQaYtQ6rGKjxd+QJPkQzyrE8XHOY1AqsZsyl/m4MBuLPz0ovo6pOBbnm1CtmJNTWPxC2n/ER+m0vXiY5TjtAbkQI0a88J6/0GskRI6mHK8782c2wpUA1bh2u0yXqbkRF7TvKiNc2099OzIgvszAnMVFi/X5Cyqg7Jiup0PenbVL2nonNlhga3V09oLepVvxhe81sbLsSbnBwMdb4UCqX9G2dQtfwhbs06R+yMC88YxDClPcg1Xqk1yW+ON+lZQIDAQAB";

    private static final String payUrl = "https://gateway.fantom.vip/api/v0.1/Deposit/Order";

    private static final String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCbCD1gnzLfKKZLEBYgC9SFUz7kexeeDpkbOGlHl421rTcEhKNlzj27oA/6v9ZjVG6ArQk78QNazRtDkzUr4z6zQji+IYhA3cmeGft1+SUZy9+ceMPjSaH219r0QnJ5oBE5GEVpOs1PwRSE5KaYw7O1ZxnoKrDPx1Mi7H0TwGI4GX3NlT4FHpmNpnRYjinKMp/AJR7dVtY7gI4XYhdxifLiHHzbUraFaB7RBhQOji5rgM+ZMpYZT1xD0VFdkNwlktlFuNnMgcWtwPWGdRYnzh35ILZHmTsS1e+WPja24mp+UJ5cQpoFNOF+UV6ZXbEvJ7YaGzA6wYyF5boZPdtiDdfrAgMBAAECggEAN9uvKaoSjT87M153alJ43xTQW0hSiRtfZORdYnMjlurzIMidiufVbE3OlB0cpKteKTSvWA6Nk+DEywM2LDrzc2kPwsmYKy7+Ht3jsWz0RigjyF/mzHTSS3sYo9txHYtjyTuKftC1+t9pgjxUHkSc8mZUekcvb520waeNpVkyyl0qsay8oxIZMzizojcwGesUbVJFWiZYKsgajZiLszvNwfY9Qvgc8hIavG2lDPRKKY9bU8gWts2gFT3qQC41ZKXa3HHUQ6WGmdCIiHoTpKG/kI/PuMVQ6QDpq/HkfNYIp1GUodOs6cY9DquxIblkZBA9o0D0mAANxjpC8vlrgGrccQKBgQDxf9mgchuDBE7pL+Q1NjiUAK1S6Y72YI2DlI9bUFFxXLn+zuQh76z9ap1uk75qahKKHzrUollYD3Z2vjRoaiUCNKzKcB9MSRNrxJzTvtEg2lwaXGBX20iWyCZG/ETwFeXrNBnD8ngnxh2W9dT3eGGT1Fi/QxqtpGC7WSOtzuD3GQKBgQCkV0eQnCS56gnKPxB4EsFPA9ZvgJqmspVmRtCCWNfKBUVb37p7if/8oXra21Gc5CGlHleGJu+yc0dmJsFm2qDPrieJFXvO3SWi5gQk+ofrlg2D1WXci8gUKIbtSB+XpL9DkmcaCJlJVnKCxOjKZOGhkV9aDIlO73ujEn5ZI0P7owKBgCkoMc2fRMMKW+xvxgOvjuriRqenuD6S6+styVS1lnusYuJjHgwOjbvOjLAIq9303938Pol4daOFVxobhlD5Lf93PK9vdlYI6i9mnZeUoI1pyWKQtbajX3aa+7MDUThdcwanpXB4hTO6FtbgZIAcWvzXppxJ8mT/a6DiKyt2424ZAoGADwDE0MfgdnSORj9xonSb3znLdsx30eYVy4uFd5Diylem2FdZb/POQeMAE0DYd4lAJRHbDa06TsFFcGbzWw90hOEyTMqATgdUa0WydSnGBNTjEPkHXpYIQwbcIodmEvMAXwvbi73jOJXCyHtvgSKqkpRx7web9W/Ziq6iiEK27x8CgYEAraDEh0cwb/Sf5RKUwLj/75QbBc9HTnWPSGfL9vl0rjzQ5ySTeuzKRVscZMbuouICK0SatnlAwoDYw0QUErc8urD0FdWW3AjWPzUmzfELjsxfw5/6s3Q3nJi4B16PqMk4eIuAk+uh20RMAKovZv/Z3LJpa3blQv+kwouotKem1p4=";

    private static SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
    private static SimpleDateFormat signSdf = new SimpleDateFormat("yyyyMMddHHmmss");

    private final Map<String, String> payTypeMap = new HashMap<>();

    public RedBull() {
        payTypeMap.put(OutChannel.alipay.name(), "1101");
        payTypeMap.put(OutChannel.wechatpay.name(), "1102");
        payTypeMap.put(OutChannel.onlinepay.name(), "1002");
        payTypeMap.put(OutChannel.quickpayh5.name(), "1003");
        payTypeMap.put(OutChannel.unionwap.name(), "1105");
        payTypeMap.put(OutChannel.qqpay.name(), "1103");
        payTypeMap.put(OutChannel.jdpay.name(), "1104");
        payTypeMap.put(OutChannel.alih5.name(), "1201");
        payTypeMap.put(OutChannel.qqh5.name(), "1203");
        payTypeMap.put(OutChannel.wechath5.name(), "1202");
        payTypeMap.put(OutChannel.jdh5.name(), "1204");
        payTypeMap.put(OutChannel.unionsm.name(), "1205");

    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "红牛支付 支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        BigDecimal money = new BigDecimal(amount);

        Map<String, String> params = new TreeMap<>();
        params.put("brandNo", upMerchantNo);
        params.put("orderNo", orderNo);
        DecimalFormat df = new DecimalFormat("#.00");
        params.put("price", df.format(money));
        params.put("serviceType", payType);
        params.put("userName", upMerchantNo);
        params.put("clientIP", reqIp);
        params.put("signature", getSign(params));
        params.put("callbackUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("frontUrl", returnUrl);
        params.put("signType", "RSA-S");

        LogByMDC.info(channelNo, "红牛支付 订单请求：{}，request：{}", orderNo, JSON.toJSONString(params));
        long start = System.currentTimeMillis();
        LogByMDC.info(channelNo, "=============红牛支付 订单：{}，请求开始时间：{}", orderNo, DateUtil.parseTimeSecStrSSS(System.currentTimeMillis()));
        String request = request(payUrl, JSON.toJSONString(params));
        long end = System.currentTimeMillis();
        LogByMDC.info(channelNo, "=============红牛支付 订单：{}，请求结束时间：{}", orderNo, DateUtil.parseTimeSecStrSSS(System.currentTimeMillis()));
        LogByMDC.info(channelNo, "=============红牛支付 订单：{}，累计耗时：{}", orderNo, (end - start) + "毫秒");

        LogByMDC.info(channelNo, "红牛支付 订单返回：{}，request：{}", orderNo, request);

        JSONObject jsonObject = JSONObject.parseObject(request);
        String resultCode = jsonObject.getString("code");
        if (!"0".equals(resultCode)) {
            String err = jsonObject.getString("message");
            return R.error("红牛支付 上游返回：" + err);
        }
        String data = jsonObject.getString("data");
        String qrCode = JSONObject.parseObject(data).getString("payUrl");
        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }

    private static String getSign(Map<String, String> params) {
        System.out.println("参与加签的参数:" + JSON.toJSONString(params));
        String signStr = sign(params);
        System.out.println("转换后的参数：" + signStr);
        byte[] sign = new byte[0];
        try {
            sign = RSAUtils.signMd5ByPriKey(signStr, privateKey);
        } catch (Exception e) {
            throw new RException("红牛支付签名失败");
        }
        return Base64.getEncoder().encodeToString(sign);
    }

    public static String request(String url, String params) {
        try {
            System.out.println("请求报文:" + params);
            URL urlObj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(1000 * 5);
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Content-Length", String.valueOf(params.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(params.toString().getBytes("UTF-8"));
            outStream.flush();
            outStream.close();
            return getResponseBodyAsString(conn.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            throw new RException("请求红牛支付异常：" + e.getMessage());
        }
    }

    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuffer data = new StringBuffer();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, "UTF-8"));
            }
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
            throw new RException("红牛支付处理支付响应异常：" + e.getMessage());
        }
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, " 红牛支付 回调内容：{}", params);


        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "红牛支付 订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }

        String orderNo = order.getOrderNo();

        String dealTime = params.get("dealTime");
        String orderTime = params.get("orderTime");
        try {
            dealTime = signSdf.format(sdf.parse(dealTime));
            orderTime = signSdf.format(sdf.parse(orderTime));
        } catch (ParseException e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "红牛支付 订单：{}，时间转换错误：{}", orderNo);
            throw new RException("红牛支付回调时间转换异常：" + e.getMessage());
        }

        String signStr = String.format("actualPrice=%s&dealTime=%s&orderNo=%s&orderStatus=%s&orderTime=%s&price=%s&tradeNo=%s",
                params.get("actualPrice"), dealTime, params.get("orderNo"), params.get("orderStatus"),
                orderTime, params.get("price"), params.get("tradeNo"));
        LogByMDC.info(channelNo, "红牛支付 订单：{}，验证回调签名参数：{}", orderNo, signStr);
        try {
            boolean isValid = RSAUtils.checkSignByPubkey(signStr, Base64.getDecoder()
                    .decode(URLDecoder.decode(params.get("signature"), "UTF-8")), publicKey.trim());
            if (!isValid) {
                LogByMDC.error(channelNo, "红牛支付 订单：{}，验证回调签名失败", orderNo);
                throw new RException("红牛支付回调验签失败");
            }
        } catch (Exception e) {
            LogByMDC.error(channelNo, "红牛支付 订单：{}，验证回调签名错误", orderNo);
            throw new RException("红牛支付验签报错:" + e);
        }
        String payFlag = params.get("orderStatus");
        if (!"1".equals(payFlag)) {
            LogByMDC.error(channelNo, "红牛支付 订单：{}，支付未成功，不再向下通知", orderNo);
            return "OK";
        }

        String amount = params.get("actualPrice");
        String systemNo = params.get("systemNo");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(systemNo);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "红牛支付 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "红牛支付 订单：{}，下发通知失败", order.getOrderNo());
            throw new RException("红牛支付通知下游异常:" + e);
        }
        return "OK";
    }


    private static String sign(Map<String, String> params) {
        StringBuffer sb = new StringBuffer();
        params.forEach((k, v) -> {
            sb.append(k + "=" + v + "&");
        });
        if (!org.springframework.util.StringUtils.isEmpty(sb)) {
            String str = sb.toString();
            str = str.substring(0, str.length() - 1);
            return str;
        }
        return null;
    }
}
