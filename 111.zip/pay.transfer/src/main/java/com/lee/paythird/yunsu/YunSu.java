package com.lee.paythird.yunsu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.Md5Utils;
import com.lee.common.utils.R;
import com.lee.pay.api.OrderReqParams;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 云速
 */
@Service(YunSu.channelNo)
public class YunSu extends AbstractPay<OrderReqParams> {

    static final String channelNo = "yunsu";

    private static final String payUrl = "http://vh333.com:8089/ppayApi/order/payOrder";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public YunSu() {
        payTypeMap.put(OutChannel.alipay.name(), "alipay");
        payTypeMap.put(OutChannel.wechatpay.name(), "wechat");
        payTypeMap.put(OutChannel.unionpay.name(), "unionpay");
        payTypeMap.put(OutChannel.qqpay.name(), "qqpay");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "云速支付请求：{}", jObj.toJSONString());
        OrderReqParams reqParams = JsonToBean(jObj, OrderReqParams.class);
        Map<String, String> params = getParamsMap(merchantChannel, reqParams);

        String result = restTemplate.postForObject(payUrl, params, String.class);
        LogByMDC.info(channelNo, "云速支付响应 订单：{}，response：{}", reqParams.getOrderNo(), result);
        Map<String, String> resultMap = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String status = resultMap.get("code");
        Assert.isTrue("0".equals(status), "云速上游支付状态响应:" + resultMap.get("errMsg"));
        JSONObject jsonObject = JSONObject.parseObject(resultMap.get("object"));
        String qrCode = jsonObject.getString("data");
        saveOrder(jObj, channelNo, merchantChannel.getUpMerchantNo());

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), reqParams.getOrderNo());
        returnMap.put(OrderParamKey.outChannel.name(), reqParams.getOutChannel());
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), reqParams.getAmount());
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }

    private Map<String, String> getParamsMap(MerchantChannelEntity merchantChannel, OrderReqParams reqParams) {
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upPublicKey = merchantChannel.getUpPublicKey();
        String payType = payTypeMap.get(reqParams.getOutChannel());
        Assert.notNull(payType, "不支持的支付方式:" + reqParams.getOutChannel());
        String merchNo = reqParams.getMerchNo();
        String orderNo = reqParams.getOrderNo();
        String amount = reqParams.getAmount();

        Map<String, String> params = new TreeMap<>();
        params.put("version", "1.0");
        params.put("merId", upMerchantNo);
        params.put("orderId", orderNo);
        params.put("totalMoney", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        params.put("ip", reqParams.getReqIp());
        params.put("tradeType", payType);
        params.put("describe", reqParams.getProduct());
        params.put("notify", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("redirectUrl", reqParams.getReturnUrl());
        params.put("remark", reqParams.getMemo());
        params.put("fromtype", "wap");

        String sign = Md5Utils.MD5(getSign(params, upPublicKey));
        assert sign != null;
        params.put("sign", sign.toUpperCase());
        return params;
    }

    private String getSign(Map<String, String> params, String upPublicKey) {
        return "merId=" + params.get("merId") + "&orderId=" + params.get("orderId") +
                "&totalMoney=" + params.get("totalMoney") + "&tradeType=" + params.get("tradeType") + "&" + upPublicKey;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "云速支付回调内容：{}", params);
        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "云速支付回调订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        String upMerchantKey = merchantChannel.getUpPublicKey();
        //验签
        boolean signVerify = verifySignParams(params, upMerchantKey);
        if (!signVerify) {
            LogByMDC.error(channelNo, "云速支付回调订单：{}，回调验签失败", order.getOrderNo());
            return "FAIL";
        }
        String trade_no = params.get("tradeId");
        String trade_status = params.get("code");
        String amount = params.get("money");

        if (!"0".equals(trade_status)) {
            LogByMDC.error(channelNo, "云速支付回调订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            return "success";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(trade_no);
        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "云速支付回调订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "云速支付回调订单：{}，下发通知失败{}", order.getOrderNo(), e.getMessage());
            throw new RException("通知下游报错:" + e.getMessage());
        }
        return "success";
    }

    private boolean verifySignParams(Map<String, String> payTypeMap, String upMerchantKey) {
        String sign = payTypeMap.get("sign");
        String verifySignParams =
                "code" + payTypeMap.get("code")
                        + "merId" + payTypeMap.get("merId")
                        + "money" + payTypeMap.get("money")
                        + "orderId" + payTypeMap.get("orderId")
                        + "payWay" + payTypeMap.get("payWay")
                        + "remark" + payTypeMap.get("remark")
                        + "time" + payTypeMap.get("time")
                        + "tradeId" + payTypeMap.get("tradeId")
                        + upMerchantKey;
        LogByMDC.info(channelNo, "云速支付回调验签订单:{}，参与验签参数:{}", payTypeMap.get("orderId"), verifySignParams);
        String newSign = Md5Utils.MD5(verifySignParams).toUpperCase();
        return newSign.equals(sign);
    }


}
