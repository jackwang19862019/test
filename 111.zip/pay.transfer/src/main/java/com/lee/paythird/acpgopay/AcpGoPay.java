package com.lee.paythird.acpgopay;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.api.OrderReqParams;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderAcpEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import com.lee.paythird.xinfa.utils.ToolKit;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.text.DecimalFormat;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 唯一代码gopay，TT代付
 */
@Service(AcpGoPay.channelNo)
public class AcpGoPay extends AbstractPay<OrderReqParams> {

    public static final String channelNo = "gopay";

    private static final String acpUrl = "https://gopay.run/api/6/withdraw/order/%s/";

    private static final String accountUrl = "https://gopay.run/api/6/account/list/%s/";

    private static final String payUrl = "https://gopay.run/api/6/recharge/order/TT/";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public AcpGoPay() {
        payTypeMap.put(OutChannel.wechatpay.name(), "weixin");
        payTypeMap.put(OutChannel.alipay.name(), "alipay");
        payTypeMap.put(OutChannel.qqpay.name(), "qq");
    }


    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "TT代付支付，pay请求：{}", JSON.toJSONString(jObj));
        OrderReqParams orderReqParams = JsonToBean(jObj, OrderReqParams.class);
        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String headerParams = channelObj.getString("headerParams");

        String payType = payTypeMap.get(orderReqParams.getOutChannel());
        Assert.isTrue(!StringUtils.isBlank(payType), "不支持的支付类型");

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String urlStr = String.format(accountUrl, upMerchantNo);
        /*//查询可充值列表
        String canBePayResult = restTemplate.patchForObject(urlStr, HttpsParams.buildFormEntity(null, headerParams), String.class);
        LogByMDC.info(channelNo, "TT代付支付，pay查询充值列表返回：{}", canBePayResult);
        JSONObject jsonObject = JSONObject.parseObject(canBePayResult);
        String status = jsonObject.getString("status");
        if (!"true".equals(status)) {
            String content = jsonObject.getString("content");
            String errorMsg = unicodeToString(content);
            LogByMDC.info(channelNo, "TT代付支付，pay查询充值列表失败返回：{}", errorMsg);
            throw new RException("支付方查询可充值列表失败" + errorMsg);
        }
        String data = jsonObject.getString("data");
        Assert.isTrue("[]".equals(data), "支付方无可充值列表");
        List<String> dataList = Arrays.asList(data.split(","));
        Assert.isTrue(!CollectionUtils.isEmpty(dataList), "支付方无可充值列表");
        //匹配下游上传的支付方式
        List<JSONObject> objectList = new ArrayList<>();
        for (int i = 0; i < dataList.size(); i++) {
            String str = dataList.get(i);
            JSONObject jb = JSONObject.parseObject(str);
            String accountType = jb.getString("AccountType");
            Assert.notNull(accountType, "支付方查询可充值列表返回AccountType为空");
            if (payType.equals(accountType)) {
                objectList.add(jb);
            }
        }
        if (CollectionUtils.isEmpty(objectList)) {
            throw new RException("支付方暂时无法提供您选择的支付"+payType+"充值列表，请您更换其他支付方式尝试");
        }
        //随机人的支付卡号输出
        int size = objectList.size();
        int num = 1 + (int)(Math.random() * (size-1+1));
        JSONObject matchJo = objectList.get(num);*/
        //这两个参数就是充值订单的参数
        String accountNumber = "642558215652455221";//matchJo.getString("AccountNumber");
        DecimalFormat df = new DecimalFormat("#.00");
        String amount = df.format(new BigDecimal(orderReqParams.getAmount()));

        Map<String, String> requestMap = new HashMap<>();
        requestMap.put("AccountNumber", accountNumber);
        requestMap.put("TransactionAmount", amount);
        requestMap.put("Authorization", headerParams);
        LogByMDC.info(channelNo, "发起支付开始：{},参数：{}", orderReqParams.getOrderNo(), JSON.toJSONString(requestMap));
        String request = ToolKit.request(payUrl, SignatureUtils.buildParams(requestMap));
        LogByMDC.info(channelNo, "请求支付方返回结果：{}，response：{}", orderReqParams.getOrderNo(), request);
        JSONObject jo = JSONObject.parseObject(request);
        String content = jo.getString("content");
        String msg = unicodeToString(content);
        String status = jo.getString("status");
        if ("false".equals(status)) {
            LogByMDC.info(channelNo, "请求支付方返回支付失败：{}，response：{}", orderReqParams.getOrderNo(), msg);
            throw new RException("请求支付方返回支付失败：" + msg);
        }
        /*String signParams = SignatureUtils.buildParams(params, false) + "&key=" + upMerchantKey;
        LogByMDC.info(channelNo, "金发支付签名参数：{}", signParams);
        String sign = SignatureUtils.getMD5(signParams);
        params.put("return_url", returnUrl);
        params.put("sign", sign);

        LogByMDC.info(channelNo, "金发支付订单号：{}，request：{}", orderNo, JSON.toJSONString(params));
        String result = restTemplate.postForObject(reqUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "金发支付订单号：{}，response：{}", orderNo, result);

        params = doBusiness(result, upMerchantKey);
        String error = params.get("error");
        if (!StringUtils.isEmpty(error)) {
            return R.error(error);
        }

        String url = params.get("qrcode_url");
        String price = params.get("price");

        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchNo);
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(PayConstants.web_code_url, url);
        returnMap.put(OrderParamKey.amount.name(), price);
        return R.ok().put(Constant.result_data, returnMap);*/
        return null;
    }

    private Map<String, String> getAcpRequestMap(OrderReqParams orderReqParams, String channelNo, String merchantNo, String headerParams) {
        LogByMDC.info(channelNo, "TT代付仓库请求Authorization：{}", headerParams);

        DecimalFormat df = new DecimalFormat("#.00");
        String amount = df.format(new BigDecimal(orderReqParams.getAmount()));
        String orderNo = orderReqParams.getOrderNo();

        Map<String, String> params = new LinkedHashMap<>();
        params.put("BankName", orderReqParams.getBankCode());//银行代号
        params.put("AccountNumber", orderReqParams.getBankAccountNo());//银行卡号
        params.put("AccountName", orderReqParams.getBankAccountName());//开户名
        params.put("TransactionAmount", amount);//BankBranchName TransactionCode Remark
        params.put("BankBranchName", "分行");
        params.put("TransactionCode", System.currentTimeMillis() + "");
        params.put("Remark", "出款");
        params.put("Callback", getAgentCallBackUrl(channelNo, merchantNo, orderNo));
        params.put("Authorization", headerParams);
        return params;
    }

    private Map<String, String> getPayRequestMap(String headerParams, OrderReqParams orderReqParams) {
        LogByMDC.info(channelNo, "TT支付请求：{}, 请求头：{}", JSON.toJSONString(orderReqParams), headerParams);
        Map<String, String> params = new LinkedHashMap<>();
        params.put("AccountNumber", orderReqParams.getBankAccountNo());
        /*params.put("TransactionAmount", amount);
        params.put("TransactionBankName", orderNo);
        params.put("TransactionBankBranchName", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        params.put("TransactionAccountNumber", getCallbackUrl(channelNo, merchNo, orderNo));
        params.put("TransactionAccountName", payType);
        params.put("TransactionCode", System.currentTimeMillis() + "");
        params.put("Callback", System.currentTimeMillis() + "");*/
        return params;
    }


    @Override
    public R orderAcp(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "TT代付仓库请求：{}", jObj.toJSONString());
        OrderReqParams orderReqParams = JsonToBean(jObj, OrderReqParams.class);
        JSONObject channelObj = JSON.parseObject(channel.getPayload());
        String headerParams = channelObj.getString("headerParams");
        String md5Key = channelObj.getString("md5Key");
        String channelNo = channel.getChannelNo();
        String merchantNo = merchant.getMerchantNo();

        Map<String, String> requestMap = getAcpRequestMap(orderReqParams, channelNo, merchantNo, headerParams);
        String result = postRequest(requestMap, merchantChannel);
        verifySign(result, requestMap, md5Key);//验签
        saveAcpOrder(jObj, channel.getChannelNo(), merchantChannel.getUpMerchantNo());

        Map<String, String> resultMap = new HashMap<>();
        resultMap.put(OrderParamKey.orderNo.name(), orderReqParams.getOrderNo());
        resultMap.put(OrderParamKey.merchNo.name(), orderReqParams.getMerchNo());
        resultMap.put(OrderParamKey.channelNo.name(), channel.getChannelNo());
        resultMap.put(OrderParamKey.amount.name(), orderReqParams.getAmount());

        return R.ok().put(Constant.result_data, resultMap);
    }

    private String postRequest(Map<String, String> requestMap, MerchantChannelEntity merchantChannel) {
        LogByMDC.info(channelNo, "TT代付仓库请求开始：{}", JSON.toJSONString(requestMap));
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String urlStr = String.format(acpUrl, upMerchantNo);
        String result = restTemplate.postForObject(urlStr, HttpsParams.buildFormEntity(requestMap), String.class);
        LogByMDC.info(channelNo, "TT代付仓库请求响应：{}", result);
        return result;
    }

    private String verifySign(String result, Map<String, String> requestMap, String md5Key) {
        Map<String, String> map = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        LogByMDC.info(channelNo, "TT代付仓库请求响应开始验签：{}", map);
        String status = map.get("status");
        if ("true".equals(status)) {
            String data = map.get("data");
            JSONObject jsonObject = JSONObject.parseObject(data);

            String serialNumber = jsonObject.getString("SerialNumber");
            LogByMDC.info(channelNo, "TT代付仓库请求响应流水号：{}, ", serialNumber);
            return serialNumber;
            //String sign = jsonObject.remove("Sign").toString();
            //String buildVerifyParams = SignatureUtils.buildParams(requestMap) + "&Key=" + md5Key;
            //LogByMDC.info(channelNo, "TT代付仓库请求响应参与验签参数：{}", buildVerifyParams);
            //String verifySign = Md5Util.MD5(buildVerifyParams);
            //LogByMDC.info(channelNo, "TT代付仓库请求响应MD5签名：{}", verifySign);
            //Assert.isTrue(verifySign.equals(sign), "TT代付仓库请求响应验签失败");
        } else if ("false".equals(status)) {
            String content = map.get("content");
            String errorMsg = unicodeToString(content);
            LogByMDC.error(channelNo, "TT代付仓库请求响应支付未成功：{}", errorMsg);
        }
        return "";
    }

    public static String unicodeToString(String str) {
        Pattern pattern = Pattern.compile("(\\\\u(\\p{XDigit}{4}))");
        Matcher matcher = pattern.matcher(str);
        char ch;
        while (matcher.find()) {
            ch = (char) Integer.parseInt(matcher.group(2), 16);
            str = str.replace(matcher.group(1), ch + "");
        }
        return str;
    }


    @Override
    public String acpCallback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderAcpEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "TT代付仓库代付订单回调内容：{}", params);
        //通知下游
        try {
            String serialNumber = params.get("SerialNumber");
            order.setBusinessNo(serialNumber);
            String transactionAmount = params.get("TransactionAmount");
            order.setRealAmount(new BigDecimal(transactionAmount));
            Integer status = Integer.valueOf(params.get("Status"));
            if (!"4".equals(status)) {
                //通知下游失败2(待处理) 3(交易进行中) 4(完成交易) 5(交易取消)
                CallBackEnum statusByCode = CallBackEnum.getStatusByCode(status);
                String msg = statusByCode == null ? "未知状态：" + status : statusByCode.getName();
                order.setMsg(msg);
                notifyTask.put(order, order.getEncryptType());
                LogByMDC.error(channelNo, "TT代付仓库代付订单：{}，代付未成功，向下通知失败", order.getOrderNo());
                return "SUCCESS";
            }
            order.setOrderState(OrderState.succ.id());
            orderAcpService.update(order);
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.error(channelNo, "TT代付仓库代付订单回调：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "TT代付仓库代付订单回调：{}，下发通知失败", order.getOrderNo());
        }
        return "SUCCESS";
    }
}
