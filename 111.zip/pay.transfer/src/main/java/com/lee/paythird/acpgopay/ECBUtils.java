package com.lee.paythird.acpgopay;

import com.lee.common.exception.RException;
import com.lee.common.utils.Md5Util;
import org.apache.commons.codec.binary.Base64;

import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.DESKeySpec;
import javax.crypto.spec.DESedeKeySpec;
import java.security.Key;
import java.security.SecureRandom;

public class ECBUtils {

    //算法名称
    public static final String KEY_ALGORITHM = "DESede";
    //算法名称/加密模式/填充方式
    public static final String CIPHER_ALGORITHM = "DESede/ECB/NoPadding"; //DES/ECB/NoPadding

    private static SecretKey keyGenerator(String keyStr) throws Exception {
        DESKeySpec desKey = new DESKeySpec(keyStr.getBytes());
        //创建一个密匙工厂，然后用它把DESKeySpec转换成
        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(KEY_ALGORITHM);
        SecretKey securekey = keyFactory.generateSecret(desKey);
        return securekey;
    }

    public static String encrypt(String data, String key) {
        try {
            String s = Md5Util.MD5(key);
            String substring = s.substring(0, 24);

            DESedeKeySpec dks = new DESedeKeySpec(substring.getBytes());

            SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(KEY_ALGORITHM);
            Key secretKey = keyFactory.generateSecret(dks);
            Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
            SecureRandom secureRandom = new SecureRandom();
            cipher.init(Cipher.ENCRYPT_MODE, secretKey,secureRandom);

            byte[] datas = data.getBytes();
            int length = datas.length;
            byte[] bytes = new byte[length + (8 - length % 8)];
            for (int i = 0; i < length; i++) {
                if (i < length) {
                    bytes[i] = datas[i];
                }
            }
            return Base64.encodeBase64String(cipher.doFinal(bytes));
        } catch (Exception e) {
            throw new RException("加密出错" + e);
        }
    }

    public static String decrypt(String data, String key) throws Exception {
        String s = Md5Util.MD5(key);
        String substring = s.substring(0, 24);
        DESedeKeySpec dks = new DESedeKeySpec(substring.getBytes());

        SecretKeyFactory keyFactory = SecretKeyFactory.getInstance(KEY_ALGORITHM);
        Key secretKey = keyFactory.generateSecret(dks);

        Cipher cipher = Cipher.getInstance(CIPHER_ALGORITHM);
        SecureRandom secureRandom = new SecureRandom();
        cipher.init(Cipher.DECRYPT_MODE, secretKey,secureRandom);
        // 解密字节-执行解密操作
        byte[] bytes = cipher.doFinal(Base64.decodeBase64(data));
        return new String(bytes);
    }

}
