package com.lee.paythird.yimi;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.Md5Utils;
import com.lee.common.utils.R;
import com.lee.pay.api.OrderReqParams;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.daxiong.signature.StringUtil;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Service(YiMi.channelNo)
public class YiMi extends AbstractPay<OrderReqParams> {

    static final String channelNo = "yimi";

    private static final String payUrl = "http://qq.5555qp.net/api/api_add_order";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public YiMi() {
        payTypeMap.put(OutChannel.alipay.name(), "903");
        payTypeMap.put(OutChannel.alih5.name(), "904");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "一米支付请求：{}", jObj.toJSONString());
        OrderReqParams reqParams = JsonToBean(jObj, OrderReqParams.class);
        Map<String, String> params = getParamsMap(merchantChannel, reqParams);

        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        LogByMDC.info(channelNo, "一米支付响应 订单：{}，response：{}", reqParams.getOrderNo(), result);
        boolean jsonObject = isJsonObject(result);
        if (jsonObject) {
            Map<String, String> resultMap = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
            });
            String code = resultMap.get("code");
            if (!StringUtil.isEmpty(code)) {
                throw new RException("一米支付上游请求返回:" + resultMap.get("mes"));
            }
            String status = resultMap.get("status");
            if (!StringUtil.isEmpty(status)) {
                throw new RException("一米支付上游请求返回:" + resultMap.get("msg"));
            }
        }
        Pattern pattern = Pattern.compile("href=\"(.+?)\"");
        Matcher matcher = pattern.matcher(result);
        String qrCode = null;
        if(matcher.find()){
            qrCode = matcher.group(1);
        }
        saveOrder(jObj, channelNo, merchantChannel.getUpMerchantNo());

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), reqParams.getOrderNo());
        returnMap.put(OrderParamKey.outChannel.name(), reqParams.getOutChannel());
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), reqParams.getAmount());
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }


    private static boolean isJsonObject(String content) {
        if (StringUtils.isBlank(content))
            return false;
        try {
            JSONObject jsonStr = JSONObject.parseObject(content);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private Map<String, String> getParamsMap(MerchantChannelEntity merchantChannel, OrderReqParams reqParams) {
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upPublicKey = merchantChannel.getUpPublicKey();
        String payType = payTypeMap.get(reqParams.getOutChannel());
        Assert.notNull(payType, "不支持的支付方式:" + reqParams.getOutChannel());
        String merchNo = reqParams.getMerchNo();
        String orderNo = reqParams.getOrderNo();
        String amount = reqParams.getAmount();

        Map<String, String> params = new TreeMap<>();
        params.put("pay_memberid", upMerchantNo);
        params.put("pay_orderid", orderNo);
        params.put("pay_bankcode", payType);
        params.put("pay_amount", amount);
        params.put("pay_callbackurl", reqParams.getReturnUrl());
        params.put("pay_notifyurl", getCallbackUrl(channelNo, merchNo, orderNo));

        String sign = Md5Utils.MD5(SignatureUtils.buildParams(params, true) + "&key=" + upPublicKey);
        assert sign != null;
        params.put("pay_md5sign", sign.toUpperCase());
        return params;
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "一米支付回调内容：{}", params);
        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "一米支付回调订单：{}，重复回调", order.getOrderNo());
            return "OK";
        }
        //String upMerchantKey = merchantChannel.getUpPublicKey();
        //验签
        //boolean signVerify = verifySignParams(params, upMerchantKey);
        /*if (!signVerify) {
            LogByMDC.error(channelNo, "一米支付回调订单：{}，回调验签失败", order.getOrderNo());
            return "FAIL";
        }*/
        String trade_no = params.get("orderid");
        String trade_status = params.get("returncode");
        String amount = params.get("amount");

        if (!"00".equals(trade_status)) {
            LogByMDC.error(channelNo, "一米支付回调订单：{}，支付未成功，不再向下通知", order.getOrderNo());
            return "OK";
        }

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(trade_no);
        orderService.update(order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "一米支付回调订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            LogByMDC.error(channelNo, "一米支付回调订单：{}，下发通知失败{}", order.getOrderNo(), e.getMessage());
            throw new RException("通知下游报错:" + e.getMessage());
        }
        return "OK";
    }

   /* private boolean verifySignParams(Map<String, String> params, String upMerchantKey) {
        String orderid = params.get("orderid");
        String sign = params.remove("sign");
        LogByMDC.info(channelNo, "一米支付回调验签订单:{}，参与验签参数:{}", orderid, JSON.toJSONString(params));
        String newSign = Md5Utils.MD5(SignatureUtils.buildParams(params, true) + "key=" + upMerchantKey);
        return newSign.equals(sign);
    }*/


}
