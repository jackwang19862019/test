package com.lee.paythird.xinfa;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.MatchUtils;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.xinfa.utils.ToolKit;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 鑫发
 */
@Service(XinFa.channelNo)
public class XinFa extends AbstractPay {

    public static final String merchNo_ = "XF201901021415";

    public static final String channelNo = "xinfa";

    public static final String md5Key = "78FC45CA0FE344E52E1CF971AF897C63";

    private final String payUrl = "http://netway.xfzfpay.com:90/api/pay";

    private final String rsaPrivateKey = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBANtVUYM0Ux721ciqO0geOIhz9ixM" +
            "DCaJMEmag3HipqUXP9hXsq0s8BTJZ5zYG/xu5FQvuDJKhXcN3upqxaMOXPCst4AwM4m3Gf7pnrIb" +
            "Xo22XfVPVGkUx6ddDYM10Kn1mFLoNaQBY2ytZbOunTqXyfZw9KfusYH/EEkaNWABcBaXAgMBAAEC" +
            "gYEAxP52Pa+LUG5GSPqMUBPEltoAKn0LFLl3A0Sh9nGpVvHwx/DMbDnGUAUs6HQ5fppivTI28AR6" +
            "pxlwM38+j1rhISc+irKztPUE6DznYMHfB6JBeLD6ovsGqFlY/PKLcFPm5jwmvD6DuY5WuhVdOoaT" +
            "DxvqUgo6PSF4R1JEsRILHpECQQD0x2YUV9Qv1zw8LGdi5esqTvAgNJF10BhMl984EQ/9MqBvD9jv" +
            "0E2qDiueEnRPQXTA/kfhL1/PlPgB9C+WPshjAkEA5WNNe/1+rHSR+fwMavhfLonPaL6zH9NMXZla" +
            "xVaVO4r6P0PM+hJt6A3YpTd0Mr7qeL99Msv57lNB8tfYxXZ9PQJATyEOrNDftT99J26rVVtCNIEk" +
            "OyUDSPSmhkwqSvOpGY7+MikLVisekDTYgNcyZlSgq6sIDZHFBVQBAJCxuX4+RQJBAOB79fBJfBY5" +
            "XkJOr7hfqIZax2eyeInEtw9CbNqCiTjkIVKYf5ibQIPASSwmwMiInd3dSCDWDZl2USveoH1eH+EC" +
            "QQDogMT38G44ER8+My97n/60U1DCz0vSz2k5DV3223HGqIVFvHaawQpQB9mIS6sJbO4/cG+k7upW" +
            "UN2Qdylm3Ow5";

    private final String rsaPayPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCVui+usDZzQwwvxLyIzpZrFCiYW5fkblD6iIlaNeWg8zNyRZowc+81YCbAlZbLqdMVehGq3P6GFvOZn2qXUi+8teBW9PhtulM+/QnsvdWGxdRkMuD7VPZiT1MrQXJm1Uky1pyrYlVc2zDXpwTP2vRRthLbHLc2SsC1h8bQ7q8dwQIDAQAB";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public XinFa() {
        payTypeMap.put(OutChannel.aliredbox.name(), "ZFB_HB");
        payTypeMap.put(OutChannel.alih5.name(), "ZFB_HB_H5");
        payTypeMap.put(OutChannel.unionwap.name(), "UNION_WAP");
        payTypeMap.put(OutChannel.unionquickpay.name(), "UNION_QUICKPAY");
        payTypeMap.put(OutChannel.alipay.name(), "ZFB");
        payTypeMap.put(OutChannel.aliwap.name(), "ZFB_WAP");
        payTypeMap.put(OutChannel.wechatpay.name(), "WX");
        payTypeMap.put(OutChannel.wechatwap.name(), "WX_WAP");
        payTypeMap.put(OutChannel.wechath5.name(), "WX_H5");
        payTypeMap.put(OutChannel.qqpay.name(), "QQ");
        payTypeMap.put(OutChannel.qqwap.name(), "QQ_WAP");
        payTypeMap.put(OutChannel.jdpay.name(), "JD");
        payTypeMap.put(OutChannel.jdwap.name(), "JD_WAP");
        payTypeMap.put(OutChannel.unionpay.name(), "UNION_WALLET");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String upMerchantNo = merchantChannel.getUpMerchantNo();

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        Map<String, String> params = new HashMap<>();
        params.put("version", "V3.3.0.0");//版本号
        params.put("merchNo", upMerchantNo);//商户号
        params.put("randomNum", MatchUtils.generateShortUuid());//随机数
        params.put("payType", payType);//支付类型
        params.put("orderNo", orderNo);//订单号
        //订单金额，单位:分
        params.put("amount", String.valueOf(new BigDecimal(amount).multiply(new BigDecimal("100")).intValue()));
        params.put("goodsName", title);//商品名称
        params.put("notifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));//异步通知地址
        params.put("notifyViewUrl", returnUrl);//回显地址
        params.put("charsetCode", "UTF-8");//回显地址
        params.put("sign", SignatureUtils.md5MapSortSign(params, md5Key).toUpperCase());

        LogByMDC.info(channelNo, "签名sign：{}", SignatureUtils.md5MapSortSign(params, md5Key).toUpperCase());

        String resultJsonStr = "";
        try {
            LogByMDC.info(channelNo, "开始公钥加密：{}", JSON.toJSONString(params));
            byte[] dataStr = ToolKit.encryptByPublicKey(ToolKit.mapToJson(params).getBytes(ToolKit.CHARSET), rsaPayPublicKey);
            String param = new BASE64Encoder().encode(dataStr);
            String reqParam = "data=" + URLEncoder.encode(param, ToolKit.CHARSET) + "&merchNo=" +  merchNo_;
            resultJsonStr = ToolKit.request(payUrl, reqParam);
            LogByMDC.info(channelNo, "请求返回{}", resultJsonStr);
        } catch (UnsupportedEncodingException e) {
            e.printStackTrace();
            LogByMDC.info(channelNo, "订单请求第三方失败{}", orderNo);
        }

        JSONObject resultJsonObj = JSONObject.parseObject(resultJsonStr);
        String code = resultJsonObj.getString("stateCode");
        if (!"00".equals(code)) {
            String err = resultJsonObj.getString("msg");
            String errStr = null;
            try {
                errStr = new String(err.getBytes("iso-8859-1"), "utf-8");
            } catch (UnsupportedEncodingException e) {
                throw new RException("同步返回数据解码失败");
            }
            return R.error("上游返回：" + errStr);
        }

        if (!checkSignForXinFa(resultJsonObj)) {
            throw new RException("同步返回数据验签失败");
        }
        String qrCode = resultJsonObj.getString("qrcodeUrl");

        saveOrder(jObj, channelNo, upMerchantNo);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "回调内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.info(channelNo, "订单：{}，重复回调", order.getOrderNo());
            return "SUCCESS";
        }

        String orderNo = order.getOrderNo();
        //开始解密异步返回的数据
        String pay_result = params.get("data");
        LogByMDC.info(channelNo, "订单：{}，解密数据前data{}", orderNo, pay_result);
        try{
            byte[] result = ToolKit.decryptByPrivateKey(new BASE64Decoder().decodeBuffer(pay_result), rsaPrivateKey);
            String resultData = new String(result, ToolKit.CHARSET);
            JSONObject jsonObject = JSON.parseObject(resultData);
            LogByMDC.info(channelNo, "订单：{}，解密数据后data{}", orderNo, resultData);
            //这个也是第三方支付单号，上游没有返回，只能拿这个
            String sys_no = jsonObject.get("orderNo").toString();
            //实际支付金额，单位:分
            String amount_pay = jsonObject.get("amount").toString();
            if (!checkSignForXinFa(jsonObject)) {
                LogByMDC.error(channelNo, "订单：{}，异步返回数据验签失败", orderNo);
                throw new RException("异步返回数据验签失败{}");
            }

            order.setOrderState(OrderState.succ.id());
            order.setRealAmount(new BigDecimal(amount_pay).multiply(new BigDecimal("0.01")));
            order.setBusinessNo(sys_no);
            orderService.update(order);
        }catch (Exception e){
            LogByMDC.error(channelNo, "订单：{}，解密/更新数据失败", order.getOrderNo());
            throw new RException("解密/更新数据失败");
        }
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "鑫发支付 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "鑫发订单：{}，下发通知失败", order.getOrderNo());
        }
        return "SUCCESS";
    }

    private boolean checkSignForXinFa(JSONObject resultJsonObj) {
        String sign = resultJsonObj.getString("sign");
        resultJsonObj.remove("sign");
        Map map = new TreeMap<>(resultJsonObj);
        String targetString = ToolKit.MD5(JSON.toJSONString(map) + md5Key, ToolKit.CHARSET);
        return sign.equals(targetString);
    }
}
