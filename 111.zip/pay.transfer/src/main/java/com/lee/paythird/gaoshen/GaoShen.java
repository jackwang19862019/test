package com.lee.paythird.gaoshen;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.ydw360.utils.ToolKit;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;
import org.springframework.util.Assert;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

/**
 * 高盛
 */
@Service(GaoShen.channelNo)
public class GaoShen extends AbstractPay {

    public static final String channelNo = "gaoshen";

    private static final String payUrl = "http://gway.yt888f.com:7060/api/qrCodePay.action";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public GaoShen() {
        payTypeMap.put(OutChannel.alipay.name(), "ZFB");
        payTypeMap.put(OutChannel.wechatpay.name(), "WX");
        payTypeMap.put(OutChannel.qqpay.name(), "QQ");
        payTypeMap.put(OutChannel.baidupay.name(), "BAI_DU");
        payTypeMap.put(OutChannel.jdpay.name(), "JD");
        payTypeMap.put(OutChannel.unionsm.name(), "UNIONPAY_QRCODE");
        payTypeMap.put(OutChannel.wechatwap.name(), "WX_WAP");

        payTypeMap.put(OutChannel.aliwap.name(), "ZFB_WAP");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "高盛支付 支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> metaSignMap = new TreeMap<>();
        metaSignMap.put("appId", upMerchantNo);
        metaSignMap.put("payType", payType);
        metaSignMap.put("nonceStr", ToolKit.randomStr(4));// 4位随机数
        metaSignMap.put("outTradeNo", orderNo);
        metaSignMap.put("requestIp", reqIp);
        metaSignMap.put("totalAmount", new BigDecimal(amount).multiply(new BigDecimal("100")).intValue() + "");// 单位:分
        metaSignMap.put("goodsInfo", product);
        metaSignMap.put("notifyUrl", getCallbackUrl(channel.getChannelNo(), merchNo, orderNo));// 回调地址
        metaSignMap.put("returnUrl", returnUrl);// 回显地址
        String metaSignJsonStr = JSON.toJSONString(metaSignMap);
        String sign = MD5(metaSignJsonStr + upMerchantKey, "UTF-8");
        metaSignMap.put("sign", sign);
        String reqParam = "reqData=" + JSON.toJSONString(metaSignMap);
        LogByMDC.info(channelNo, "高盛支付 订单：{}，request：{}", orderNo, JSON.toJSONString(reqParam));
        String resultJsonStr = request(payUrl, reqParam);
        Assert.isTrue(!StringUtils.isEmpty(resultJsonStr), "高盛支付维护中...:" + resultJsonStr);
        LogByMDC.info(channelNo, "高盛支付 订单：{}，response：{}", orderNo, resultJsonStr);
        //验签
        Map<String, String> map = (Map) JSONObject.parseObject(resultJsonStr);
        String resultCode = map.get("resultCode");
        if (!"00".equals(resultCode)) {
            String err = map.get("resultMsg");
            return R.error("高盛支付 上游返回：" + err);
        }
        if (!checkSignForGaoshen(map, upMerchantKey)) {
            throw new RException("高盛支付 同步返回数据验签失败");
        }

        String qrCode = map.get("qrCode");

        saveOrder(jObj, channelNo, upMerchantNo);
        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, qrCode);
        return R.ok().put(Constant.result_data, returnMap);
    }

    private boolean checkSignForGaoshen(Map<String, String> map, String md5Key) {
        String sign = map.get("sign");
        map.remove("sign");
        //再次排序
        map = new TreeMap<>(map);
        String str = JSON.toJSONString(map);
        String targetString = MD5(str + md5Key, "UTF-8");
        return sign.equals(targetString);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, " 高盛支付 回调内容：{}", params);

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.error(channelNo, "高盛支付 订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        String orderNo = order.getOrderNo();
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        String reqData = params.get("reqData");
        JSONObject jsonObject = JSONObject.parseObject(reqData);
        Map<String, String> map = JSONObject.toJavaObject(jsonObject, Map.class);
        if (!checkSignForGaoshen(map, upMerchantKey)) {
            LogByMDC.error(channelNo, "高盛支付 订单：{}，验证回调签名错误", orderNo);
            return "fail";
        }

        String payFlag = map.get("resultCode");
        if (!"00".equals(payFlag)) {
            LogByMDC.error(channelNo, "高盛支付 订单：{}，支付未成功，不再向下通知", orderNo);
            return "success";
        }

        String amount = map.get("totalAmount");
        String systemNo = map.get("outTradeNo");

        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount).multiply(new BigDecimal("0.01")));
        order.setBusinessNo(systemNo);
        orderService.update(order);

        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.error(channelNo, "高盛支付 发起通知：{}，通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "高盛支付 订单：{}，下发通知失败", order.getOrderNo());
        }

        return "success";
    }


    /**
     * 生成随机字符
     *
     * @param num
     * @return
     */
    public static String randomStr(int num) {
        char[] randomMetaData = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
                'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
                'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4',
                '5', '6', '7', '8', '9'};
        Random random = new Random();
        String tNonceStr = "";
        for (int i = 0; i < num; i++) {
            tNonceStr += (randomMetaData[random.nextInt(randomMetaData.length - 1)]);
        }
        return tNonceStr;
    }

    static final char HEX_DIGITS[] = {'0', '1', '2', '3', '4', '5', '6', '7',
            '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    public final static String MD5(String s, String encoding) {
        try {
            byte[] btInput = s.getBytes(encoding);
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            mdInst.update(btInput);
            byte[] md = mdInst.digest();
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = HEX_DIGITS[byte0 >>> 4 & 0xf];
                str[k++] = HEX_DIGITS[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String request(String url, String params) {
        try {
            URL urlObj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlObj
                    .openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(1000 * 5);
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length",
                    String.valueOf(params.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(params.toString().getBytes("UTF-8"));
            outStream.flush();
            outStream.close();
            return getResponseBodyAsString(conn.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuffer data = new StringBuffer();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, "UTF-8"));
            }
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
