package com.lee.paythird.kuaiyitong;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.constenum.PayConstants;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TreeMap;

/**
 * 快易通
 */
@Service(KuaiYiTong.channelNo)
public class KuaiYiTong extends AbstractPay {

    public static final String channelNo = "kuaiyitong";

    private final Map<String, String> payTypeMap = new HashMap<>();

    public KuaiYiTong() {
        payTypeMap.put(OutChannel.alipay.name(), "D0_ALIPAY_SCAN");
        payTypeMap.put(OutChannel.aliwap.name(), "D0_ALIPAY_H5");

        payTypeMap.put(OutChannel.wechatpay.name(), "D0_WX_SCAN");
        payTypeMap.put(OutChannel.wechath5.name(), "D0_WX_H5");

        payTypeMap.put(OutChannel.qqpay.name(), "D0_QQ_SCAN");
        payTypeMap.put(OutChannel.qqwap.name(), "D0_QQ_H5");

        payTypeMap.put(OutChannel.jdpay.name(), "D0_JD_SCAN");

        payTypeMap.put(OutChannel.unionsm.name(), "D0_UNION_SCAN");
        payTypeMap.put(OutChannel.unionh5.name(), "D0_UNION_H5");

        payTypeMap.put(OutChannel.onlinepay.name(), "D0_B2C");
    }


    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "快易通支付 开始支付：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("快易通支付 不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        Map<String, String> dataMap = buildDataMap(upMerchantNo, amount, orderNo, payType, bankCode,
                reqIp, product, returnUrl, memo, upMerchantKey, merchNo);
        LogByMDC.info(channelNo, "快易通支付 支付参数：{}", JSON.toJSONString(dataMap));
        String payUrl = "";
        if (StringUtils.isEmpty(bankCode)) {
            payUrl = "https://income.nnmmc.com/cashier/scanAPI";
        } else {
            payUrl = "https://income.nnmmc.com/cashier/b2cAPI";
        }
        LogByMDC.info(channelNo, "快易通支付 支付地址：{}", payUrl);
        String resultStr = sendRequest(payUrl, dataMap);
        String url = doBusinessReturnUrl(resultStr);
        //保存订单到我方数据库
        saveOrder(jObj, channelNo, upMerchantNo);
        //组装返回map
        Map map = buildResultMap(orderNo, outChannel, merchant, amount, url);
        return R.ok().put(Constant.result_data, map);
    }

    private Map buildResultMap(String orderNo, String outChannel, MerchantEntity merchant, String amount, String url) {
        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(OrderParamKey.amount.name(), amount);
        returnMap.put(PayConstants.web_code_url, url);
        LogByMDC.info(channelNo, "快易通支付 返回给下游：{}", JSON.toJSONString(returnMap));
        return returnMap;
    }

    private String doBusinessReturnUrl(String resultStr) {
        JSONObject jsonObject = JSONObject.parseObject(resultStr);
        String returnCode = jsonObject.getString("returnCode");
        if (!"0".equals(returnCode)) {
            String message = jsonObject.getString("message");
            LogByMDC.error(channelNo, "快易通支付 支付返回：{}", message);
            throw new RException("快易通支付失败:" + message);
        }
        //保存订单
        String content = jsonObject.getString("content");
        LogByMDC.info(channelNo, "快易通支付 上游返回支付地址：{}", content);
        return content;
    }

    private String sendRequest(String payUrl, Map<String, String> dataMap) {
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(dataMap), String.class);
        LogByMDC.info(channelNo, "快易通支付 支付返回：{}", result);
        return result;
    }

    private Map<String, String> buildDataMap(String upMerchantNo, String amount,
                                             String orderNo, String payType,
                                             String bankCode, String reqIp,
                                             String product, String returnUrl,
                                             String memo, String upMerchantKey,
                                             String merchNo) {
        Map<String, String> dataMap = new TreeMap<>();
        dataMap.put("merchantCode", upMerchantNo);
        dataMap.put("amount", amount);
        dataMap.put("orderNumber", orderNo);
        dataMap.put("payCode", payType);

        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        Date now = new Date();
        dataMap.put("submitTime", sdf.format(now));

        dataMap.put("commodityName", product);
        dataMap.put("submitIp", reqIp);
        dataMap.put("syncRedirectUrl", returnUrl);
        dataMap.put("asyncNotifyUrl", getCallbackUrl(channelNo, merchNo, orderNo));
        if (!StringUtils.isEmpty(bankCode)) {
            dataMap.put("bankCode", bankCode);
        }
        dataMap.put("remark", memo);

        String sign = SignatureUtils.sign(dataMap, upMerchantKey);
        dataMap.put("sign", sign);
        return dataMap;
    }


    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        LogByMDC.info(channelNo, "快易通支付 回调内容：{}", JSON.toJSONString(params));

        if (order.getOrderState() == OrderState.succ.id()) {
            LogByMDC.info(channelNo, "快易通支付 订单：{}，重复回调", order.getOrderNo());
            return "success";
        }

        String orderNo = order.getOrderNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();
        //验签
        String sign = params.remove("sign");
        String signNew = SignatureUtils.sign(params, upMerchantKey);
        if (!sign.equals(signNew)) {
            LogByMDC.error(channelNo, "快易通支付 订单：{}，验签失败", orderNo);
            throw new RException("快易通验签失败");
        }
        //变更订单信息
        updateOrder(params, order);
        //通知下游
        try {
            notifyTask.put(order, order.getEncryptType());
            LogByMDC.info(channelNo, "快易通支付 订单：{}，下发通知成功", order.getOrderNo());
        } catch (Exception e) {
            e.printStackTrace();
            LogByMDC.error(channelNo, "快易通订单：{}，下发通知失败", order.getOrderNo());
        }
        return "success";
    }

    private void updateOrder(Map<String, String> params, OrderEntity order) {
        String orderNo = order.getOrderNo();
        String amount = params.get("amount");
        String payStatus = params.get("payStatus");
        String trxNo = params.get("trxNo");
        if (!"orderPaid".equals(payStatus)) {
            LogByMDC.info(channelNo, "订单：{}，支付支付未成功，不再向下通知", orderNo);
            return;
        }
        order.setOrderState(OrderState.succ.id());
        order.setRealAmount(new BigDecimal(amount));
        order.setBusinessNo(trxNo);
        orderService.update(order);
    }
}
