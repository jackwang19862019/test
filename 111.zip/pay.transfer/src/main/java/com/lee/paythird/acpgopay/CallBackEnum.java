package com.lee.paythird.acpgopay;

import java.util.HashMap;
import java.util.Map;

public enum CallBackEnum {
    wait(2, "待处理"),
    doing(3, "交易进行中"),
    finish(4, "完成交易"),
    cancel(5, "交易取消"),
    ;


    private Integer code;
    private String name;

    CallBackEnum(int code, String name) {
        this.code = code;
        this.name = name;
    }

    public int getCode() {
        return code;
    }

    public String getName() {
        return name;
    }

    private static Map<Integer, CallBackEnum> map = new HashMap<>();

    public static CallBackEnum getStatusByCode(int code) {
        if (map == null || map.isEmpty()) {
            for (CallBackEnum status : CallBackEnum.values()) {
                map.put(status.getCode(), status);
            }
        }
        return map.get(code);
    }


    public static String getName(int code) {
        CallBackEnum type = getStatusByCode(code);
        return type == null ? "" : type.getName();
    }

    public int getCode(CallBackEnum sex) {
        return sex.getCode();
    }
}
