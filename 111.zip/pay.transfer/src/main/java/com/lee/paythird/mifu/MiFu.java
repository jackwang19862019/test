package com.lee.paythird.mifu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Constant;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.pay.constenum.*;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.paythird.AbstractPay;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.stereotype.Service;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Service(MiFu.channelNo)
public class MiFu extends AbstractPay {

    public static final String channelNo = "mifu";

    private final Map<String, String> payTypeMap = new HashMap<>();

    /**
     * 获取用户token
     * appid 请求应用的平台appid
     * userId 开发商请求的用户id，是用户的唯一识别码，开发商后台唯一，原则上需要填写，不填写可能会造成支付流程复杂度提升，财务报表统计数据缺失
     * appsecret 应用在后台生成的appsecret秘钥参数
     */
    private final String tokenUrl = "https://api.cryptocurpays.com/api/v1/{appid}/token/{userId}?appsecret={appsecret}";

    /**
     * 获取支付地址
     * appid 请求应用的平台appid
     * userId 开发商请求的用户id，是用户的唯一识别码，开发商后台唯一，原则上需要填写，不填写可能会造成支付流程复杂度提升，财务报表统计数据缺失
     * token tokenUrl获取到的token
     */
    private final String payUrl = "https://api.cryptocurpays.com/api/v1/{appid}/otcurl/{userId}?token={token}&userName=nick";



    public MiFu() {
        payTypeMap.put(OutChannel.unionpay.name(), "0");
        payTypeMap.put(OutChannel.alipay.name(), "1");
        payTypeMap.put(OutChannel.wechatpay.name(), "2");
    }

    @Override
    public R order(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, JSONObject jObj) {
        LogByMDC.info(channelNo, "支付请求：{}", jObj.toJSONString());
        String merchNo = jObj.getString(OrderParamKey.merchNo.name());
        String orderNo = jObj.getString(OrderParamKey.orderNo.name());
        String amount = jObj.getString(OrderParamKey.amount.name());
        String currency = jObj.getString(OrderParamKey.currency.name());
        String outChannel = jObj.getString(OrderParamKey.outChannel.name());
        String bankCode = jObj.getString(OrderParamKey.bankCode.name());
        String title = jObj.getString(OrderParamKey.title.name());
        String product = jObj.getString(OrderParamKey.product.name());
        String memo = jObj.getString(OrderParamKey.memo.name());
        String returnUrl = jObj.getString(OrderParamKey.returnUrl.name());
        String notifyUrl = jObj.getString(OrderParamKey.notifyUrl.name());
        String reqTime = jObj.getString(OrderParamKey.reqTime.name());
        String userId = jObj.getString(OrderParamKey.userId.name());
        String reqIp = jObj.getString(OrderParamKey.reqIp.name());

        String payType = payTypeMap.get(outChannel);
        if (StringUtils.isBlank(payType)) {
            return R.error("不支持的支付类型");
        }

        String upMerchantNo = merchantChannel.getUpMerchantNo();
        String upMerchantKey = merchantChannel.getUpPublicKey();

        String result = restTemplate.getForObject(tokenUrl, String.class, upMerchantNo, userId, upMerchantKey);
        LogByMDC.info(channelNo, "订单：{}，获取token, response：{}", orderNo, result);

        JSONObject jsonObject = JSON.parseObject(result);
        if (jsonObject.getInteger("type") != 0) {
            LogByMDC.error(channelNo, result);
            return R.error("上游返回：" + result);
        }

        jsonObject = jsonObject.getJSONObject("data");
        String token = jsonObject.getString("token");

        result = restTemplate.getForObject(payUrl, String.class, upMerchantNo, userId, token);
        LogByMDC.info(channelNo, "订单：{}，获取支付地址, response：{}", orderNo, result);

        jsonObject = JSON.parseObject(result);
        if (jsonObject.getInteger("type") != 0) {
            LogByMDC.error(channelNo, result);
            return R.error("上游返回：" + result);
        }

        String url = jsonObject.getString("data");

        OrderEntity order = JSONObject.toJavaObject(jObj, OrderEntity.class);
        order.setOrderState(OrderState.init.id());
        order.setCrtDate(new Date());
        order.setNoticeState(NoticeState.init.id());
        order.setPayCompany(channelNo);
        order.setPayMerch(upMerchantNo);
        order = orderService.save(order);
        Long orderId = order.getOrderId();

        Map<String, String> params = new HashMap<>();
        //意向引导的购买金额
        params.put("matchone", amount);
        //意向购买的加密货币种类,默认需要填写ccn
        params.put("matchtype", "ccn");
        //[1,0](意向购买支付渠道 0 银行卡 1 支付宝 2 微信)
        params.put("payways", payType);
        //Imh0dHBzOi8vd3d3LmJhaWR1LmNvbT9tPTEyMyZuPTk4NzIi(为保证回跳链接附带参数的完整性，url地址请进行base64编码，此地址实际是https://www.baidu.com，用户下单完成后的跳回的商家界面地址，可选，如果不填，otc购币充值平台将跳过回跳逻辑。地址采用标准网站url地址格式，回跳时，除backopenurl完整地址，不附带其他形式的参数)
        params.put("backopenurl", returnUrl);

        params.put("orderid", String.valueOf(orderId));

        url = url + "&" + SignatureUtils.buildParams(params);
        LogByMDC.info(channelNo, "订单：{}，请求地址：{}", orderNo, url);

        Map<String, String> returnMap = new HashMap<>();
        returnMap.put(OrderParamKey.orderNo.name(), orderNo);
        returnMap.put(OrderParamKey.outChannel.name(), outChannel);
        returnMap.put(OrderParamKey.merchNo.name(), merchant.getMerchantNo());
        returnMap.put(OrderParamKey.channelNo.name(), channelNo);
        returnMap.put(PayConstants.web_code_url, url);
        returnMap.put(OrderParamKey.amount.name(), amount);
        return R.ok().put(Constant.result_data, returnMap);
    }

    @Override
    public String callback(ChannelEntity channel, MerchantEntity merchant, MerchantChannelEntity merchantChannel, OrderEntity order, Map<String, String> params) {
        return null;
    }
}
