package com.lee.pay.service.impl;

import com.lee.pay.dao.MerchantChannelDao;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.service.MerchantChannelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class MerchantChannelServiceImpl implements MerchantChannelService {

    @Autowired
    private MerchantChannelDao merchantChannelDao;

    @Override
    public MerchantChannelEntity selectByMerchantNoAndChannelNo(String merchantNo, String channelNo) {
        return merchantChannelDao.findByMerchantNoAndChannelNo(merchantNo, channelNo);
    }

    @Override
    public void updateMerchant(String channelNo, String newChannelNo) {
        List<MerchantChannelEntity> one = merchantChannelDao.findByChannelNo(channelNo);
        one.stream().forEach(e->e.setChannelNo(newChannelNo));
        merchantChannelDao.save(one);
    }
}
