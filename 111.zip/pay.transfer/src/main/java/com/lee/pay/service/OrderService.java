package com.lee.pay.service;

import com.lee.pay.entity.OrderEntity;

public interface OrderService {

    OrderEntity selectByMerchNoAndOrderNo(String merchNo, String orderNo);

    OrderEntity save(OrderEntity order);

    OrderEntity update(OrderEntity order);

    OrderEntity selectById(Long id);
}
