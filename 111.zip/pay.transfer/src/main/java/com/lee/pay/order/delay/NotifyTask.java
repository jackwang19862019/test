package com.lee.pay.order.delay;

import com.alibaba.fastjson.JSON;
import com.lee.common.utils.*;
import com.lee.pay.constenum.NoticeState;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderAcpEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.pay.service.ConfigService;
import com.lee.pay.service.MerchantService;
import com.lee.pay.service.OrderAcpService;
import com.lee.pay.service.OrderService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.HashMap;
import java.util.Map;
import java.util.concurrent.DelayQueue;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

@Component
public class NotifyTask {

    private final Logger logger = LoggerFactory.getLogger(NotifyTask.class);

    //每次推迟时间基数 单位 秒
    private final long TIME_UNIT = 10;
    //每次通知失败后下次通知等待时间 与基数的倍数
    private final int TIME_TIMES = 3;
    //最大通知次数
    private final int TIMES_MAX = 6;
    //通知成功标识
    private final String RES_SUCCESS = "ok";
    //当前实例
    private NotifyTask instance;

    //延迟队列
    private DelayQueue<DelayItem<OrderInfo>> queue = new DelayQueue<>();
    //守护线程
    private Thread taskThread;
    //通知线程池
    ExecutorService cachedThreadPool = Executors.newCachedThreadPool();
    //spring HTTP发送模板

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderAcpService orderAcpService;

    @Autowired
    private ConfigService configService;

    @Autowired
    private MerchantService merchantService;

    private NotifyTask() {
        taskThread = new Thread(() -> execute());
        taskThread.setName("NotifyTask Thread");
        taskThread.start();
    }

    private void execute() {
        while (true) {
            try {
                DelayItem<OrderInfo> di = queue.take();
                OrderInfo o = di.getItem();
                if (o != null) {
                    cachedThreadPool.execute(() -> {
                        int times = o.getTimes();
                        if (o.getAcp()) {
                            OrderAcpEntity order = o.getOrderAcp();
                            String notifyUrl = o.getNotifyUrl();
                            logger.info("订单号：{}，第{}次通知，内容：{}，通知地址：{}，原文内容：{}",
                                    order.getOrderNo(),
                                    times,
                                    o.getParams(),
                                    notifyUrl,
                                    o.getOriginParams());
                            String result = null;
                            int statusCode = 404;
                            try {
                                ResponseEntity<String> entity = restTemplate.postForEntity(o.getNotifyUrl(), o.getParams(), String.class);
                                statusCode = entity.getStatusCodeValue();
                                result = entity.getBody();
                            } catch (RestClientException e) {
                                logger.error(e.getMessage(), e);
                            }
                            if (!RES_SUCCESS.equalsIgnoreCase(result)) {
                                logger.error("订单号：{},第{}次通知失败,HTTP状态码：{},返回内容：{}",
                                        order.getOrderNo(),
                                        times,
                                        statusCode,
                                        result);
                                if (times < TIMES_MAX) {
                                    o.setTimes(o.getTimes() + 1);
                                    put(o);
                                } else {
                                    order.setNoticeState(NoticeState.fail.id());
                                    orderAcpService.update(order);
                                    logger.error("订单号：{},通知失败,NOTIFY END", order.getOrderNo());
                                }
                            } else {
                                order.setNoticeState(NoticeState.succ.id());
                                orderAcpService.update(order);
                                logger.info("订单号：{},通知完成", order.getOrderNo());
                            }
                        } else {
                            OrderEntity order = o.getOrder();
                            String notifyUrl = o.getNotifyUrl();
                            logger.info("订单号：{}，第{}次通知，内容：{}，通知地址：{}，原文内容：{}",
                                    order.getOrderNo(),
                                    times,
                                    o.getParams(),
                                    notifyUrl,
                                    o.getOriginParams());
                            String result = null;
                            int statusCode = 404;
                            try {
                                ResponseEntity<String> entity = restTemplate.postForEntity(o.getNotifyUrl(), o.getParams(), String.class);
                                statusCode = entity.getStatusCodeValue();
                                result = entity.getBody();
                            } catch (RestClientException e) {
                                logger.error(e.getMessage(), e);
                            }
                            if (!RES_SUCCESS.equalsIgnoreCase(result)) {
                                logger.error("订单号：{},第{}次通知失败,HTTP状态码：{},返回内容：{}",
                                        order.getOrderNo(),
                                        times,
                                        statusCode,
                                        result);
                                if (times < TIMES_MAX) {
                                    o.setTimes(o.getTimes() + 1);
                                    put(o);
                                } else {
                                    order.setNoticeState(NoticeState.fail.id());
                                    orderService.update(order);
                                    logger.error("订单号：{},通知失败,NOTIFY END", order.getOrderNo());
                                }
                            } else {
                                order.setNoticeState(NoticeState.succ.id());
                                orderService.update(order);
                                logger.info("订单号：{},通知完成", order.getOrderNo());
                            }
                        }

                    });
                }

            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
    }

    /**
     * 加入通知队列
     *
     * @param o
     */
    public void put(OrderInfo o) {
        int times = o.getTimes() - 1 == 0 ? 0 : (int) Math.pow(TIME_TIMES, o.getTimes() - 1);
        long nanoTime = TIME_UNIT + TimeUnit.NANOSECONDS.convert(times * TIME_UNIT, TimeUnit.SECONDS);
        queue.put(new DelayItem<>(o, nanoTime));
    }

    public void put(OrderEntity order, String encryptType) throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put(OrderParamKey.merchNo.name(), order.getMerchNo());
        map.put(OrderParamKey.orderNo.name(), order.getOrderNo());
        map.put(OrderParamKey.businessNo.name(), order.getBusinessNo());
        map.put(OrderParamKey.orderState.name(), order.getOrderState() + "");
        map.put(OrderParamKey.amount.name(), order.getRealAmount().toString());

        String privateKey = configService.selectByKey(Constant.PLATFORM_PRIVATE_KEY);
        MerchantEntity merchant = merchantService.selectByMerchantNo(order.getMerchNo());
        String mPublicKey = merchant.getPublicKey();

        String sign, type;
        byte[] context;
        if(EncryptType.isMD5(encryptType)) {
            context = JSON.toJSONBytes(map);
            sign = Md5Util.sign(new String(context,"UTF-8"), mPublicKey, "UTF-8");
            type = "MD5";

        }else {
            context = RSAUtils.encryptByPublicKey(JSON.toJSONBytes(map), mPublicKey);
            sign = RSAUtils.sign(context, privateKey);
            type = "RSA";
        }
        Map<String, String> params = new HashMap<>();
        params.put("sign", sign);
        params.put("context", Base64Utils.encode(context));
        params.put("encryptType", type);
        OrderInfo oInfo = new OrderInfo(order, params, JSON.toJSONString(map), order.getNotifyUrl());
        put(oInfo);
    }

    public void put(OrderAcpEntity order, String encryptType) throws Exception {
        Map<String, String> map = new HashMap<>();
        map.put(OrderParamKey.merchNo.name(), order.getMerchNo());
        map.put(OrderParamKey.orderNo.name(), order.getOrderNo());
        map.put(OrderParamKey.businessNo.name(), order.getBusinessNo());
        map.put(OrderParamKey.orderState.name(), order.getOrderState() + "");
        map.put(OrderParamKey.amount.name(), order.getRealAmount().toString());

        String privateKey = configService.selectByKey(Constant.PLATFORM_PRIVATE_KEY);
        MerchantEntity merchant = merchantService.selectByMerchantNo(order.getMerchNo());
        String mPublicKey = merchant.getPublicKey();

        String sign, type;
        byte[] context;
        if(EncryptType.isMD5(encryptType)) {
            context = JSON.toJSONBytes(map);
            sign = Md5Util.sign(new String(context,"UTF-8"), mPublicKey, "UTF-8");
            type = "MD5";

        }else {
            context = RSAUtils.encryptByPublicKey(JSON.toJSONBytes(map), mPublicKey);
            sign = RSAUtils.sign(context, privateKey);
            type = "RSA";
        }
        Map<String, String> params = new HashMap<>();
        params.put("sign", sign);
        params.put("context", Base64Utils.encode(context));
        params.put("encryptType", type);
        OrderInfo oInfo = new OrderInfo(order, params, JSON.toJSONString(map), order.getNotifyUrl());
        put(oInfo);
    }
}
