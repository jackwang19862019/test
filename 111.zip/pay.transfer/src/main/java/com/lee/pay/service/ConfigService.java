package com.lee.pay.service;

public interface ConfigService {

    String selectByKey(String key);
}
