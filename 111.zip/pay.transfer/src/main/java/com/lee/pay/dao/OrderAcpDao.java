package com.lee.pay.dao;

import com.lee.pay.entity.OrderAcpEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderAcpDao extends JpaRepository<OrderAcpEntity, Long> {

    OrderAcpEntity findByMerchNoAndOrderNo(String merchNo, String orderNo);
}
