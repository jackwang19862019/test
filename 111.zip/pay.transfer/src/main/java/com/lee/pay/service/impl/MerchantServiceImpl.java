package com.lee.pay.service.impl;

import com.lee.pay.dao.MerchantDao;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.service.MerchantService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class MerchantServiceImpl implements MerchantService {

    @Autowired
    private MerchantDao merchantDao;

    @Override
    public MerchantEntity selectByMerchantNo(String merchantNo) {
        return merchantDao.findByMerchantNo(merchantNo);
    }
}
