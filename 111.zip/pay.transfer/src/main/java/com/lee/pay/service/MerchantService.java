package com.lee.pay.service;

import com.lee.pay.entity.MerchantEntity;

public interface MerchantService {

    MerchantEntity selectByMerchantNo(String merchantNo);
}
