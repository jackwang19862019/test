package com.lee.pay.interceptor;

import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.Arrays;


@Component
public class IpInterceptor extends HandlerInterceptorAdapter {

	private Logger logger = LoggerFactory.getLogger(IpInterceptor.class);
	

	@Override
	public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler)
			throws Exception {
//		WhiteIp annotation;
//		if(handler instanceof HandlerMethod) {
//			annotation = ((HandlerMethod) handler).getMethodAnnotation(WhiteIp.class);
//			if (annotation == null)
//				annotation = ((HandlerMethod) handler).getBeanType().getAnnotation(WhiteIp.class);
//			if (annotation != null) {
//				String ipStr = configService.getValueByKey("whiteiplist");
//				ipStr = StringUtils.isBlank(ipStr) ? "127.0.0.1" : ipStr;
//				String[] ips = ipStr.split(",");
//
//				String clientIp = IPUtils.getIpAddr(request);
//
//				if (Arrays.asList(ips).indexOf(clientIp) == -1) {
//					logger.error("非法访问IP：{}", clientIp);
//					response.setStatus(404);
//					return false;
//				}
//			}
//		}
		return super.preHandle(request, response, handler);
	}



}
