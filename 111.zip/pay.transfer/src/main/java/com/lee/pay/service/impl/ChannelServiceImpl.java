package com.lee.pay.service.impl;

import com.lee.pay.dao.ChannelDao;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.service.ChannelService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChannelServiceImpl implements ChannelService {

    @Autowired
    private ChannelDao channelDao;

    @Override
    public ChannelEntity selectByChannelNo(String channelNo) {
        return channelDao.findByChannelNo(channelNo);
    }
}
