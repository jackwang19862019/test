package com.lee.pay.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "pay_channel", indexes = {
        @Index(name = "un_channel_no", columnList = "channelNo", unique = true)
})
public class ChannelEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long channelId;

    @Column(columnDefinition = "varchar(64) NOT NULL COMMENT '通道标识'")
    private String channelNo;

    @Column(columnDefinition = "varchar(128) DEFAULT NULL COMMENT '通道名称'")
    private String channelName;

    @Column(columnDefinition = "varchar(1024) DEFAULT NULL COMMENT '支付通道负载参数'")
    private String payload;

    @Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：0停用，1启用'")
    private Boolean status;

    @Column(updatable = false, columnDefinition = "datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'")
    private Date createDate;

    @Column(updatable = false, columnDefinition = "varchar(64) DEFAULT NULL COMMENT '创建者'")
    private String createUser;

    @Column(insertable = false, columnDefinition = "datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'")
    private String updateDate;

    @Column(insertable = false, columnDefinition = "varchar(64) DEFAULT NULL COMMENT '更新者'")
    private String updateUser;





    private String script;
}
