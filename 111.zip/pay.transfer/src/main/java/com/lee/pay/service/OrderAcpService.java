package com.lee.pay.service;

import com.lee.pay.entity.OrderAcpEntity;

public interface OrderAcpService {

    OrderAcpEntity selectByOrderNoAndMerchantNo(String merchNo, String orderNo);

    OrderAcpEntity update(OrderAcpEntity orderAcp);

    OrderAcpEntity save(OrderAcpEntity order);

    OrderAcpEntity selectByMerchNoAndOrderNo(String merchantNo, String orderNo);
}
