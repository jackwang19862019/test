package com.lee.pay.service;

import com.lee.pay.entity.ChannelEntity;

public interface ChannelService {

    ChannelEntity selectByChannelNo(String channelNo);
}
