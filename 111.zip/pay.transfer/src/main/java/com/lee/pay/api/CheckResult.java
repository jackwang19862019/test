package com.lee.pay.api;

import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import lombok.Data;

@Data
public class CheckResult {

    private MerchantChannelEntity merchantChannel;

    private MerchantEntity merchant;

    private ChannelEntity channel;

    private OrderReqParams reqParams;
}
