package com.lee.pay.service;

import com.lee.pay.entity.MerchantChannelEntity;

public interface MerchantChannelService {

    MerchantChannelEntity selectByMerchantNoAndChannelNo(String merchantNo, String channelNo);

    void updateMerchant(String channelNo,String newChannelNo);
}
