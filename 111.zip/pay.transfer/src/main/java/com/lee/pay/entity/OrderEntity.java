package com.lee.pay.entity;


import lombok.Data;

import javax.persistence.*;
import java.math.BigDecimal;
import java.util.Date;

@Data
@Entity
@Table(name = "pay_order", indexes = {
        @Index(name = "un_order_merch", columnList = "orderNo, merchNo", unique = true)
})
public class OrderEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long orderId;

    @Column(columnDefinition = "varchar(32) NOT NULL COMMENT '下游订单号'")
    private String orderNo;

    @Column(columnDefinition = "varchar(20) NOT NULL COMMENT '下游商户号'")
    private String merchNo;

    @Column(columnDefinition = "varchar(10) DEFAULT NULL COMMENT '支付公司'")
    private String payCompany;

    @Column(columnDefinition = "varchar(100) DEFAULT NULL COMMENT '支付商户号'")
    private String payMerch;

    @Column(columnDefinition = "varchar(10) DEFAULT NULL COMMENT '支付方式|渠道编码'")
    private String outChannel;

    @Column(columnDefinition = "varchar(40) DEFAULT NULL COMMENT '第三方支付订单号'")
    private String businessNo;

    @Column(columnDefinition = "varchar(20) DEFAULT NULL")
    private String title;

    @Column(columnDefinition = "varchar(20) DEFAULT NULL COMMENT '产品名称'")
    private String product;

    @Column(columnDefinition = "decimal(14,2) DEFAULT NULL COMMENT '订单金额(元)'")
    private BigDecimal amount;

    @Column(columnDefinition = "varchar(4) DEFAULT 'CNY' COMMENT '币种'")
    private String currency;

    @Column(columnDefinition = "int(2) DEFAULT NULL COMMENT '订单状态'")
    private Integer orderState;

    @Column(columnDefinition = "varchar(100) DEFAULT NULL COMMENT '前台回调地址'")
    private String returnUrl;


    @Column(columnDefinition = "varchar(100) DEFAULT NULL COMMENT '异步通知地址'")
    private String notifyUrl;

    @Column(columnDefinition = "varchar(15) DEFAULT NULL COMMENT '请求时间'")
    private String reqTime;

    @Column(columnDefinition = "varchar(20) DEFAULT NULL COMMENT '商户用户标志(暂不用)'")
    private String userId;

    @Column(columnDefinition = "varchar(22) DEFAULT NULL COMMENT '银行卡号'")
    private String bankNo;

    @Column(columnDefinition = "varchar(20) DEFAULT NULL COMMENT '请求ip'")
    private String reqIp;

    @Column(columnDefinition = "varchar(50) DEFAULT NULL COMMENT '备注留言信息'")
    private String memo;

    @Column(columnDefinition = "int(2) DEFAULT '0' COMMENT '订单类型'")
    private Integer orderType;

    @Column(columnDefinition = "int(2) DEFAULT NULL COMMENT '用户类型'")
    private Integer userType;

    @Column(columnDefinition = "int(1) DEFAULT '0' COMMENT '通知状态 -1 通知失败  0 未通知  1已通知'")
    private Integer noticeState;

    @Column(columnDefinition = "datetime DEFAULT NULL COMMENT '创建时间'")
    private Date crtDate;

    @Column(columnDefinition = "decimal(14,2) DEFAULT '0.00' COMMENT '实际支付金额'")
    private BigDecimal realAmount;

    @Column(columnDefinition = "decimal(10,2) DEFAULT '0.00' COMMENT '成本金额'")
    private BigDecimal costAmount;

    @Column(columnDefinition = "decimal(10,2) DEFAULT '0.00' COMMENT '(暂不用)'")
    private BigDecimal qhAmount;

    @Column(columnDefinition = "decimal(10,2) DEFAULT '0.00' COMMENT '(暂不用)'")
    private BigDecimal agentAmount;

    @Column(columnDefinition = "decimal(10,2) DEFAULT '0.00' COMMENT '(暂不用)'")
    private BigDecimal subAgentAmount;

    @Column(columnDefinition = "varchar(50) DEFAULT NULL COMMENT '提示消息'")
    private String msg;

    @Column(columnDefinition = "int(2) DEFAULT '0' COMMENT '(暂不用)'")
    private Integer clearState;

    @Column(columnDefinition = "int(1) DEFAULT NULL COMMENT '(暂不用) 结算方式  D0  T1'")
    private Integer paymentMethod;

    @Column(columnDefinition = "decimal(14,2) DEFAULT '0.00' COMMENT '清算金额'")
    private BigDecimal clearAmount;

    private String encryptType;









}
