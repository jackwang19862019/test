package com.lee.pay.dao;

import com.lee.pay.entity.ChannelEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface ChannelDao extends JpaRepository<ChannelEntity, Long> {
    ChannelEntity findByChannelNo(String channelNo);
}
