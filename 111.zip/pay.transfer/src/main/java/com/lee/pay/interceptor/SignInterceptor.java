package com.lee.pay.interceptor;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONException;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Md5Util;
import com.lee.common.utils.ParamUtil;
import com.lee.common.utils.RSAUtils;
import com.lee.pay.annotation.WhiteIp;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.filters.BodyReaderHttpServletRequestWrapper;
import com.lee.pay.service.ConfigService;
import com.lee.pay.service.MerchantService;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.handler.HandlerInterceptorAdapter;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.Map;

@Component
public class SignInterceptor extends HandlerInterceptorAdapter {

    private final String SIGN_TYPE_KEY = "encryptType";

    private final String SIGN_KEY = "sign";

    private final String CONTEXT_KEY = "context";

    @Autowired
    private ConfigService configService;

    @Autowired
    private MerchantService merchantService;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        WhiteIp annotation;
        if(handler instanceof HandlerMethod) {
            annotation = ((HandlerMethod) handler).getMethodAnnotation(WhiteIp.class);
            if (annotation == null)
                annotation = ((HandlerMethod) handler).getBeanType().getAnnotation(WhiteIp.class);
            if (annotation != null) {
                try (BufferedInputStream bis = new BufferedInputStream(request.getInputStream());
                     ByteArrayOutputStream baos = new ByteArrayOutputStream()) {
                    byte[] buffer = new byte[1024];
                    int len;
                    while ((len = bis.read(buffer)) > 0) {
                        baos.write(buffer, 0, len);
                    }
                    String body = new String(baos.toByteArray());
                    Map<String, String> params = JSON.parseObject(body, new TypeReference<Map<String, String>>() {
                    });
                    String signType = params.get(SIGN_TYPE_KEY);
                    if (StringUtils.isBlank(signType))
                        throw new RException("加密方式不能为空");
                    String sign = params.get(SIGN_KEY);
                    if (StringUtils.isBlank(sign))
                        throw new RException("签名不能为空");
                    String context = params.get(CONTEXT_KEY);
                    if (StringUtils.isBlank(context))
                        throw new RException("业务内容不能为空");
                    String content = validate(signType, sign, context, ParamUtil.getIpAddr(request));
                    if (StringUtils.isBlank(content)) {
                        throw new RException("验签失败");
                    }
                    if (request instanceof BodyReaderHttpServletRequestWrapper) {
                        ((BodyReaderHttpServletRequestWrapper) request).setBody(content);
                    }
                } catch (JSONException e) {
                    throw new RException("请提交标准JSON格式");
                } catch (IOException e) {
                    throw e;
                }
            }
        }

        return super.preHandle(request, response, handler);
    }

    @Override
    public void postHandle(HttpServletRequest request, HttpServletResponse response, Object handler, ModelAndView modelAndView) throws Exception {
        super.postHandle(request, response, handler, modelAndView);
    }

    public static final String MD5 = "MD5";

    public static final String RSA = "RSA";


    private String validateRSA(String sign, String content) throws Exception {
        String privateKey = configService.selectByKey("platform.private.key");
        return new String(RSAUtils.decryptByPrivateKey(content.getBytes(), privateKey));
    }


    private String validate(String signType, String sign, String context, String clientIp) {
        String content = null;
        try {
            switch (signType) {
                case MD5:
                    content = context;
                    break;
                case RSA:
                    content = validateRSA(sign, context);
                    break;
                default:
                    throw new RException("不支持的加密方式");
            }

            JSONObject jObj = JSON.parseObject(content);
            String merchantNo = jObj.getString(OrderParamKey.merchNo.name());
            if (StringUtils.isBlank(merchantNo))
                throw new RException("商户号为空!");
            MerchantEntity merchant = merchantService.selectByMerchantNo(merchantNo);
            if (merchant == null)
                throw new RException("商户不存在");
            if (!merchant.getStatus())
                throw new RException("商户被禁用");
            if (!(!MD5.equals(signType) && !RSAUtils.verify(context.getBytes(), merchant.getPublicKey(), sign)) || !(MD5.equals(signType) && !Md5Util.verify(content, sign, merchant.getPublicKey(), "UTF-8")))
                throw new RException("验签失败");

            jObj.put(OrderParamKey.reqIp.name(), clientIp);
            content = jObj.toJSONString();
        } catch (RException e) {
            throw e;
        } catch (JSONException e) {
            throw new RException("请提交标准JSON格式");
        } catch (Exception e) {
            e.printStackTrace();
            throw new RException("RSA解密失败");
        }

        return content;
    }

}
