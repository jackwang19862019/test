package com.lee.pay.order.delay;

import com.lee.pay.entity.OrderAcpEntity;
import com.lee.pay.entity.OrderEntity;
import lombok.Data;

import java.util.Map;

@Data
public class OrderInfo {

    private OrderEntity order;

    private OrderAcpEntity orderAcp;

    private Boolean acp;

    private Map<String, String> params;

    private String originParams;

    private String notifyUrl;

    private int times;

    public OrderInfo(OrderEntity order, Map<String, String> params, String originParams, String notifyUrl) {
        this.order = order;
        this.params = params;
        this.originParams = originParams;
        this.notifyUrl = notifyUrl;
        this.times = 1;
        this.acp = false;
    }

    public OrderInfo(OrderEntity order, Map<String, String> params, String originParams, String notifyUrl, int times) {
        this.order = order;
        this.params = params;
        this.originParams = originParams;
        this.notifyUrl = notifyUrl;
        this.times = times;
        this.acp = false;
    }

    public OrderInfo(OrderAcpEntity orderAcp, Map<String, String> params, String originParams, String notifyUrl) {
        this.orderAcp = orderAcp;
        this.params = params;
        this.originParams = originParams;
        this.notifyUrl = notifyUrl;
        this.acp = true;
    }


    public OrderInfo(OrderAcpEntity orderAcp, Map<String, String> params, String originParams, String notifyUrl, int times) {
        this.orderAcp = orderAcp;
        this.params = params;
        this.originParams = originParams;
        this.notifyUrl = notifyUrl;
        this.times = times;
        this.acp = true;
    }

}
