package com.lee.pay.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.*;
import com.lee.pay.annotation.WhiteIp;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.constenum.OrderState;
import com.lee.pay.constenum.OutChannel;
import com.lee.pay.entity.*;
import com.lee.pay.order.delay.NotifyTask;
import com.lee.pay.service.*;
import com.lee.paythird.PayService;
import com.lee.paythird.PayServiceFactory;
import com.lee.paythird.daxiong.signature.StringUtil;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.util.Assert;
import org.springframework.util.ObjectUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

@RestController
public class Api {

    private Logger logger = LoggerFactory.getLogger(Api.class);


    @WhiteIp
    @PostMapping("order")
    public R order(HttpServletRequest request) {
        long start = System.currentTimeMillis();
        String str = DateUtil.parseTimeSecStrSSS(start);
        //这里的key就是在admin管理后台商户列表的商户私钥
        String privateKey = configService.selectByKey("platform.private.key");
        //检验下游入参
        CheckResult checkResult = checkRequestHelper.commDataCheck(request, privateKey, OrderEnum.ORDER);
        //获取下游上传参数
        MerchantEntity merchant = checkResult.getMerchant();
        ChannelEntity channel = checkResult.getChannel();
        OrderReqParams reqParams = checkResult.getReqParams();
        MerchantChannelEntity merchantChannel = checkResult.getMerchantChannel();
        String orderNo = reqParams.getOrderNo();
        logger.info("====================订单开始时间：{},订单号：{}", str, orderNo);
        //根据下游发起的支付请求中带的通道标识 获取对应的上游支付类
        PayService payService = payServiceFactory.getService(channel.getChannelNo(), channel.getScript());

        String outChannel = reqParams.getOutChannel();
        String merchNo = reqParams.getMerchNo();
        String channelNo = reqParams.getChannelNo();

        R result;
        if (OutChannel.acp.name().equals(outChannel)) {
            OrderAcpEntity orderAcpEntity = orderAcpService.selectByOrderNoAndMerchantNo(merchNo, orderNo);
            Assert.isTrue(orderAcpEntity == null, "代付订单重复");
            //代付参数校验
            checkAcpParams(reqParams);
            result = payService.orderAcp(channel, merchant, merchantChannel, JSONObject.parseObject(JSON.toJSONString(reqParams)));
        }
        else {
            OrderEntity orderEntity = orderService.selectByMerchNoAndOrderNo(merchNo, orderNo);
            Assert.isTrue(orderEntity == null, "支付订单重复");
            //随机ip
            doBusinessIp(reqParams);
            long startThird = System.currentTimeMillis();
            String startThirdStr = DateUtil.parseTimeSecStrSSS(startThird);
            logger.info("--------------------调用支付开始时间：{}, 通道：{},订单号：{}", startThirdStr, channelNo, orderNo);

            try {
                result = payService.order(channel, merchant, merchantChannel, JSONObject.parseObject(JSON.toJSONString(reqParams)));
            } catch (Exception e) {
                logger.info(e.getMessage(), e);
                throw new RException(channel.getChannelName(), e.getMessage(), e);
            }

            long endThird = System.currentTimeMillis();
            String endStrThird = DateUtil.parseTimeSecStrSSS(endThird);
            logger.info("--------------------调用支付结束时间：{}, 通道：{},订单号：{}", endStrThird, channelNo, orderNo);
            logger.info("--------------------调用支付累计耗时：{}, 通道：{},订单号：{}", (endThird - startThird) + "毫s", channelNo, orderNo);
        }
        if (R.ifSucc(result)) {
            R res = decryptAndSign((Map<String, String>) result.get(Constant.result_data), privateKey, merchant.getPublicKey(), EncryptType.isMD5(reqParams.getEncryptType()));
            long end = System.currentTimeMillis();
            String enStr = DateUtil.parseTimeSecStrSSS(end);
            logger.info("====================订单结束时间：{},订单号：{}", enStr, orderNo);
            logger.info("====================订单累计耗时：{},订单号：{}", (end - start) + "毫s", orderNo);
            return res;
        }else {
            return result;
        }

    }

    private void checkAcpParams(OrderReqParams reqParams) {
        String channelNo = reqParams.getChannelNo();
        String orderNo = reqParams.getOrderNo();
        String bankCode = reqParams.getBankCode();
        String bankAccountName = reqParams.getBankAccountName();
        String bankAccountNo = reqParams.getBankAccountNo();
        if (StringUtils.isAnyEmpty(bankCode, bankAccountName, bankAccountNo)) {
            logger.error(channelNo + "：代付参数缺失bankCode{},bankAccountName{},bankAccountNo{}, 订单号：{}", bankCode, bankAccountName, bankAccountNo, orderNo);
            throw new RException("代付参数缺失,请检查您的开户名，银行卡号，银行编号");
        }
    }

    private void doBusinessIp(OrderReqParams reqParams) {
        String reqIp = reqParams.getReqIp();
        if (StringUtils.isEmpty(reqIp) || "127.0.0.1".equals(reqIp)) {
            //随机给一个ip
            StringBuilder stringBuilder = new StringBuilder();
            stringBuilder.append("117.191.11.");
            //随机两位数
            Random rand = new Random();
            String matchNum = String.valueOf(rand.nextInt(90) + 10);
            stringBuilder.append(matchNum);
            reqParams.setReqIp(stringBuilder.toString());
        }
    }

    @WhiteIp
    @PostMapping("order/query")
    public R orderQuery(HttpServletRequest request) {
        logger.info("====================订单查询API");
        String privateKey = configService.selectByKey("platform.private.key");
        CheckResult checkResult = checkRequestHelper.commDataCheck(request, privateKey, OrderEnum.OTHER);
        OrderReqParams reqParams = checkResult.getReqParams();
        JSONObject jobj = JSONObject.parseObject(JSON.toJSONString(reqParams));
        MerchantEntity merchant = checkResult.getMerchant();
        String orderNo = jobj.getString(OrderParamKey.orderNo.name());
        if (StringUtils.isBlank(orderNo)) {
            throw new RException("订单号为空");
        }
        Map<String, String> resultMap = new HashMap<>();
        if (OutChannel.acp.name().equals(jobj.getString(OrderParamKey.outChannel.name()))) {
            //代付查询
            OrderAcpEntity orderAcp = orderAcpService.selectByOrderNoAndMerchantNo(merchant.getMerchantNo(), orderNo);
            if (orderAcp == null) {
                throw new RException("订单信息不存在");
            }
            ChannelEntity channel = channelService.selectByChannelNo(orderAcp.getPayCompany());
            if (orderAcp.getOrderState() != OrderState.succ.id()) {
                MerchantChannelEntity merchantChannel = merchantChannelService.selectByMerchantNoAndChannelNo(merchant.getMerchantNo(), orderAcp.getPayCompany());
                PayService payService = payServiceFactory.getService(channel.getChannelNo(), channel.getScript());
                orderAcp = payService.queryAcp(channel, merchant, merchantChannel, orderAcp);
            }
            resultMap.put(OrderParamKey.orderNo.name(), orderAcp.getOrderNo());
            resultMap.put(OrderParamKey.outChannel.name(), orderAcp.getOutChannel());
            resultMap.put(OrderParamKey.merchNo.name(), orderAcp.getMerchNo());
            resultMap.put(OrderParamKey.channelNo.name(), channel.getChannelNo());
            resultMap.put(OrderParamKey.orderState.name(), orderAcp.getOrderState() + "");
            if (orderAcp.getRealAmount() != null) {
                resultMap.put(OrderParamKey.amount.name(), orderAcp.getRealAmount().toString());
            } else {
                resultMap.put(OrderParamKey.amount.name(), orderAcp.getAmount().toString());
            }
        } else {
            OrderEntity order = orderService.selectByMerchNoAndOrderNo(merchant.getMerchantNo(), orderNo);
            if (order == null) {
                throw new RException("订单信息不存在");
            }
            ChannelEntity channel = channelService.selectByChannelNo(order.getPayCompany());
            if (order.getOrderState() != OrderState.succ.id()) {
                MerchantChannelEntity merchantChannel = merchantChannelService.selectByMerchantNoAndChannelNo(merchant.getMerchantNo(), order.getPayCompany());
                PayService payService = payServiceFactory.getService(channel.getChannelNo(), channel.getScript());
                order = payService.query(channel, merchant, merchantChannel, order);
            }

            resultMap.put(OrderParamKey.orderNo.name(), order.getOrderNo());
            resultMap.put(OrderParamKey.outChannel.name(), order.getOutChannel());
            resultMap.put(OrderParamKey.merchNo.name(), order.getMerchNo());
            resultMap.put(OrderParamKey.channelNo.name(), channel.getChannelNo());
            resultMap.put(OrderParamKey.orderState.name(), order.getOrderState() + "");
            if (order.getRealAmount() != null) {
                resultMap.put(OrderParamKey.amount.name(), order.getRealAmount().toString());
            } else {
                resultMap.put(OrderParamKey.amount.name(), order.getAmount().toString());
            }
        }
        return decryptAndSign(resultMap, privateKey, merchant.getPublicKey(), EncryptType.isMD5(jobj.getString("encryptType")));

    }

    @RequestMapping("callback/{channelNo}/{merchantNo}/{orderNo}")
    public String callback(@PathVariable String channelNo, @PathVariable String merchantNo, @PathVariable String orderNo,
                           HttpServletRequest request) {
        Map<String, String> params = HttpRequestUtils.commonHttpRequestParamConvert(request);
        logger.info("callback channelNo: {}, merchantNo: {}, orderNo: {}, params: {}",
                channelNo, merchantNo, orderNo, JSON.toJSONString(params));
        OrderEntity order = orderService.selectByMerchNoAndOrderNo(merchantNo, orderNo);
        if(ObjectUtils.isEmpty(order)){
            return "您回调的订单不存在,由于支付请求时，响应状态失败或支付请求超时未处理。您可以忽略此订单";
        }
        ChannelEntity channel = channelService.selectByChannelNo(channelNo);
        MerchantEntity merchant = merchantService.selectByMerchantNo(merchantNo);
        MerchantChannelEntity merchantChannel = merchantChannelService.selectByMerchantNoAndChannelNo(merchantNo, channelNo);
        PayService payService = payServiceFactory.getService(channel.getChannelNo(), channel.getScript());
        return payService.callback(channel, merchant, merchantChannel, order, params);
    }

    @RequestMapping("acp/callback/{channelNo}/{merchantNo}/{orderNo}")
    public String acpCallback(@PathVariable String channelNo, @PathVariable String merchantNo, @PathVariable String orderNo,
                              HttpServletRequest request) {
        Map<String, String> params = HttpRequestUtils.commonHttpRequestParamConvert(request);
        logger.info("callback channelNo: {}, merchantNo: {}, orderNo: {}, params: {}",
                channelNo, merchantNo, orderNo, JSON.toJSONString(params));
        OrderAcpEntity order = orderAcpService.selectByMerchNoAndOrderNo(merchantNo, orderNo);
        ChannelEntity channel = channelService.selectByChannelNo(channelNo);
        MerchantEntity merchant = merchantService.selectByMerchantNo(merchantNo);
        MerchantChannelEntity merchantChannel = merchantChannelService.selectByMerchantNoAndChannelNo(merchantNo, channelNo);
        PayService payService = payServiceFactory.getService(channel.getChannelNo(), channel.getScript());
        return payService.acpCallback(channel, merchant, merchantChannel, order, params);
    }


    private R decryptAndSign(Map<String, ?> data, String privateKey, String mPublicKey, boolean isMD5) {
        try {
            logger.info("返回明文数据:" + JSON.toJSONString(data));
            R r = R.ok();
            if (isMD5) {
                byte[] context = JSON.toJSONBytes(data);
                String sign = Md5Util.sign(new String(context, "UTF-8"), mPublicKey, "UTF-8");
                r.put("sign", sign).put("context", context);
            } else {
                byte[] context = RSAUtils.encryptByPublicKey(JSON.toJSONBytes(data), mPublicKey);
                String sign = RSAUtils.sign(context, privateKey);
                r.put("sign", sign).put("context", context);
            }
            logger.info("返回加密数据:" + JSON.toJSONString(r));
            return r;
        } catch (Exception e) {
            logger.error("返回数据 公钥加密，私钥签名 失败！");
        }
        return R.error("返回数据 公钥加密，私钥签名 失败！");
    }


    @PostMapping("send/callback")
    public R sendCallback(@RequestBody Map<String, String> params) throws Exception {
        String type = params.get("type");
        String orderNo = params.get("orderNo");
        String merchantNo = params.get("merchantNo");

        if ("acp".equals(type)) {
            OrderAcpEntity orderAcp = orderAcpService.selectByOrderNoAndMerchantNo(merchantNo, orderNo);
            if (orderAcp.getOrderState() != OrderState.succ.id()) {
                return R.error("当前订单尚未完成");
            }
            notifyTask.put(orderAcp, orderAcp.getEncryptType());
        } else {
            OrderEntity order = orderService.selectByMerchNoAndOrderNo(merchantNo, orderNo);
            if (order.getOrderState() != OrderState.succ.id()) {
                return R.error("当前订单尚未完成");
            }
            notifyTask.put(order, order.getEncryptType());
        }
        return R.ok();
    }

    @Autowired
    private PayServiceFactory payServiceFactory;

    @Autowired
    private MerchantService merchantService;

    @Autowired
    private ChannelService channelService;

    @Autowired
    private MerchantChannelService merchantChannelService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private OrderAcpService orderAcpService;

    @Autowired
    private CheckRequestHelper checkRequestHelper;


    @Autowired
    private ConfigService configService;

    @Autowired
    private NotifyTask notifyTask;
}
