package com.lee.pay.dao;

import com.lee.pay.entity.OrderEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface OrderDao extends JpaRepository<OrderEntity, Long> {

    OrderEntity findByMerchNoAndOrderNo(String merchNo, String orderNo);

}
