package com.lee.pay.api;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.exception.RException;
import com.lee.common.utils.*;
import com.lee.pay.constenum.OrderParamKey;
import com.lee.pay.entity.ChannelEntity;
import com.lee.pay.entity.MerchantChannelEntity;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.service.ChannelService;
import com.lee.pay.service.MerchantChannelService;
import com.lee.pay.service.MerchantService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.util.Assert;

import javax.servlet.http.HttpServletRequest;
import java.nio.charset.StandardCharsets;

@Component
public class CheckRequestHelper {

    private Logger logger = LoggerFactory.getLogger(CheckRequestHelper.class);

    private CheckResult checkResult = new CheckResult();

    private String merchNo;

    private String channelNo;


    CheckResult commDataCheck(HttpServletRequest request, String privateKey, OrderEnum order) {
        JSONObject jsonObject = RequestUtils.getJsonResultStream(request);
        Assert.isTrue(jsonObject != null && jsonObject.size() > 0, "请求参数为空");

        String sign = jsonObject.getString("sign");
        Assert.isTrue(ParamUtil.isNotEmpty(sign), "请检查签名参数");
        logger.info("请求签名:{}", sign);

        byte[] context = jsonObject.getBytes("context");
        Assert.isTrue(ParamUtil.isNotEmpty(context), "请检查加密内容");
        //检查加密方式
        String encryptType = jsonObject.getString("encryptType");
        Assert.isTrue(EncryptType.desc().containsKey(encryptType), "不支持的加密方式");
        //解密
        boolean isMD5 = EncryptType.isMD5(encryptType);
        String source = decryptContent(context, isMD5, privateKey);
        logger.info("解密结果:{}", source);
        JSONObject jo = JSON.parseObject(source);
        //校验商户与商户通道信息
        String merchNo = jo.getString(OrderParamKey.merchNo.name());
        String channelNo = jo.getString(OrderParamKey.channelNo.name());

        if (OrderEnum.ORDER.equals(order)){
            checkMerchant(merchNo).checkChannel(channelNo).checkMerchantChannel();
        }
        else {
            checkMerchant(merchNo);
        }
        MerchantEntity merchant = checkResult.getMerchant();
        Assert.isTrue((!isMD5 && RSAUtils.verify(context, merchant.getPublicKey(), sign))
                || (isMD5 && Md5Util.verify(source, sign, merchant.getPublicKey(), "UTF-8")), "验签失败");
        logger.info("验签成功！商户公钥{}", merchant.getPublicKey());
        jo.put("encryptType", encryptType);
        OrderReqParams reqParams = JsonToBean(jo);
        checkResult.setReqParams(reqParams);
        return this.checkResult;
    }

    private CheckRequestHelper checkMerchantChannel() {
        MerchantChannelEntity merchantChannel = merchantChannelService.selectByMerchantNoAndChannelNo(merchNo, channelNo);
        Assert.isTrue(merchantChannel != null, "上游通道信息不存在,商户号:" + merchNo + ",通道标识:" + channelNo);
        String upMerchantNo = merchantChannel.getUpMerchantNo();
        Assert.isTrue(StringUtils.isNotEmpty(upMerchantNo), "上游通道商户号不存在,查询得到的商户通道数据为:"+JSON.toJSONString(merchantChannel));
        checkResult.setMerchantChannel(merchantChannel);
        return this;
    }

    private static OrderReqParams JsonToBean(JSONObject jObj) {
        return JSONObject.toJavaObject(jObj, OrderReqParams.class);
    }

    private CheckRequestHelper checkChannel(String channelNo) {
        Assert.isTrue(!StringUtils.isEmpty(channelNo), "通道标识为空");
        ChannelEntity channel = channelService.selectByChannelNo(channelNo);
        Assert.isTrue(channel != null && channel.getStatus(), "您传入的通道:" + channelNo + ",不存在或该通道已被禁用");
        checkResult.setChannel(channel);
        this.channelNo = channelNo;
        return this;
    }

    private CheckRequestHelper checkMerchant(String merchNo) {
        Assert.isTrue(ParamUtil.isNotEmpty(merchNo), "商户号不能为空");
        MerchantEntity merchant = merchantService.selectByMerchantNo(merchNo);
        Assert.isTrue(merchant != null, "商户不存在" + merchNo);
        Assert.isTrue(merchant.getStatus(), "商户被禁用" + merchNo);
        checkResult.setMerchant(merchant);
        this.merchNo = merchNo;
        return this;
    }

    private String decryptContent(byte[] context, boolean isMD5, String privateKey) {
        try {
            if (isMD5) {
                return new String(context, StandardCharsets.UTF_8);
            } else {
                return new String(RSAUtils.decryptByPrivateKey(context, privateKey));
            }
        } catch (Exception e) {
            throw new RException("解密请求内容失败, isMd5:" + isMD5 + ",privateKey为:" + privateKey);
        }
    }

    @Autowired
    private MerchantService merchantService;

    @Autowired
    private ChannelService channelService;

    @Autowired
    private MerchantChannelService merchantChannelService;

}
