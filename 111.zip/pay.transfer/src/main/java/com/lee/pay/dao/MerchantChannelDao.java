package com.lee.pay.dao;

import com.lee.pay.entity.MerchantChannelEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface MerchantChannelDao extends JpaRepository<MerchantChannelEntity, Long> {
    MerchantChannelEntity findByMerchantNoAndChannelNo(String merchantNo, String channelNo);

    List<MerchantChannelEntity> findByChannelNo(String channelNo);
}
