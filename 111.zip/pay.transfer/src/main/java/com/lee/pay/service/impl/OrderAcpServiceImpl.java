package com.lee.pay.service.impl;

import com.lee.pay.dao.OrderAcpDao;
import com.lee.pay.entity.OrderAcpEntity;
import com.lee.pay.service.OrderAcpService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderAcpServiceImpl implements OrderAcpService {

    @Autowired
    private OrderAcpDao orderAcpDao;


    @Override
    public OrderAcpEntity selectByOrderNoAndMerchantNo(String merchNo, String orderNo) {
        return orderAcpDao.findByMerchNoAndOrderNo(merchNo, orderNo);
    }

    @Override
    public OrderAcpEntity update(OrderAcpEntity orderAcp) {
        return orderAcpDao.save(orderAcp);
    }

    @Override
    public OrderAcpEntity save(OrderAcpEntity order) {
        return orderAcpDao.save(order);
    }

    @Override
    public OrderAcpEntity selectByMerchNoAndOrderNo(String merchantNo, String orderNo) {
        return orderAcpDao.findByMerchNoAndOrderNo(merchantNo, orderNo);
    }
}
