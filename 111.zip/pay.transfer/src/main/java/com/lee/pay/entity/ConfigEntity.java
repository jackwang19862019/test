package com.lee.pay.entity;

import lombok.Data;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "sys_config")
public class ConfigEntity {

    @Id
    private Long id;

    private String paramKey;

    private String paramValue;

    private Integer status;

    private String remark;
}
