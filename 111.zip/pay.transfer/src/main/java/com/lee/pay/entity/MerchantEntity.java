package com.lee.pay.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "pay_merchant", indexes = {
        @Index(name = "un_merchant_no", columnList = "merchantNo", unique = true)
})
public class MerchantEntity {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long merchantId;

    @Column(nullable = false, columnDefinition = "varchar(128) NOT NULL COMMENT '商户号'")
    private String merchantNo;

    @Column(nullable = false, columnDefinition = "varchar(256) NOT NULL COMMENT '商户公钥'")
    private String publicKey;

    @Column(nullable = false, columnDefinition = "varchar(256) NOT NULL COMMENT '商户私钥'")
    private String privateKey;

    @Column(columnDefinition = "tinyint(1) NOT NULL DEFAULT '1' COMMENT '状态：0停用，1启用'")
    private Boolean status;

    @Column(updatable = false, columnDefinition = "datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'")
    private Date createDate;

    @Column(updatable = false, columnDefinition = "varchar(64) DEFAULT NULL COMMENT '创建者'")
    private String createUser;

    @Column(insertable = false, columnDefinition = "datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'")
    private String updateDate;

    @Column(insertable = false, columnDefinition = "varchar(64) DEFAULT NULL COMMENT '更新者'")
    private String updateUser;

}
