package com.lee.pay.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.Date;

@Data
@Entity
@Table(name = "pay_merchant_channel", indexes = {
        @Index(name = "un_merchant_channel", columnList = "merchantNo, channelNo", unique = true)
})
public class MerchantChannelEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long merchantChannelId;

    @Column(columnDefinition = "varchar(128) NOT NULL COMMENT '商户号'")
    private String merchantNo;

    @Column(columnDefinition = "varchar(64) NOT NULL COMMENT '通道标识'")
    private String channelNo;

    @Column(columnDefinition = "varchar(128) NOT NULL COMMENT '上游商户号'")
    private String upMerchantNo;

    @Column(columnDefinition = "varchar(128) DEFAULT NULL COMMENT '上游公钥'")
    private String upPublicKey;

    @Column(columnDefinition = "varchar(128) NOT NULL COMMENT '上游私钥'")
    private String upPrivateKey;

    @Column(columnDefinition = "varchar(1024) DEFAULT NULL COMMENT '上游商户号相关'")
    private String payload;

    @Column(updatable = false, columnDefinition = "datetime DEFAULT CURRENT_TIMESTAMP COMMENT '创建时间'")
    private Date createDate;

    @Column(updatable = false, columnDefinition = "varchar(64) DEFAULT NULL COMMENT '创建者'")
    private String createUser;

    @Column(insertable = false, columnDefinition = "datetime DEFAULT NULL ON UPDATE CURRENT_TIMESTAMP COMMENT '更新时间'")
    private String updateDate;

    @Column(insertable = false, columnDefinition = "varchar(64) DEFAULT NULL COMMENT '更新者'")
    private String updateUser;
}
