package com.lee.pay.service.impl;

import com.lee.pay.dao.OrderDao;
import com.lee.pay.entity.OrderEntity;
import com.lee.pay.service.OrderService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderDao orderDao;

    @Override
    public OrderEntity selectByMerchNoAndOrderNo(String merchNo, String orderNo) {
        return orderDao.findByMerchNoAndOrderNo(merchNo, orderNo);
    }

    @Override
    public OrderEntity save(OrderEntity order) {
        return orderDao.save(order);
    }

    @Override
    public OrderEntity update(OrderEntity order) {
        return orderDao.save(order);
    }

    @Override
    public OrderEntity selectById(Long id) {
        return orderDao.findOne(id);
    }
}
