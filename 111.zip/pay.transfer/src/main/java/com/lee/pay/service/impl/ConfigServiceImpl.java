package com.lee.pay.service.impl;

import com.lee.pay.dao.ConfigDao;
import com.lee.pay.entity.ConfigEntity;
import com.lee.pay.service.ConfigService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ConfigServiceImpl implements ConfigService {
    @Autowired
    private ConfigDao configDao;

    @Override
    public String selectByKey(String key) {
        ConfigEntity config = configDao.findByParamKey(key);
        if (config == null)
            return null;
        return config.getParamValue();
    }
}
