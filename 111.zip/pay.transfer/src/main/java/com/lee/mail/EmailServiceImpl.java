package com.lee.mail;

import com.lee.common.exception.RException;
import com.lee.common.exception.RExceptionHandler;
import com.lee.common.utils.SendMailUtil;
import org.apache.log4j.Logger;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.io.PrintWriter;
import java.io.StringWriter;

@Component
public class EmailServiceImpl implements EmailService {

    private Logger logger = Logger.getLogger(RExceptionHandler.class);

    @Async("taskExecutor")
    @Override
    public void sendEmail(Exception re) {
        logger.info("开始发送邮件**********************");
        StackTraceElement st = re.getStackTrace()[0];
        String html;
        if (re instanceof RException) {
            html = SendMailUtil.getHtml("正常手动抛错报警", ((RException) re).getchannelNo(),
                    st.getClassName(), st.getMethodName(), st.getLineNumber() + "", getStackTrace(re));
        }
        else if (re instanceof IllegalArgumentException){
            html = SendMailUtil.getHtmlApi("API手动抛错报警", re.getMessage(),
                    st.getClassName(), st.getMethodName(), st.getLineNumber() + "", getStackTrace(re));
        }
        else {
            //未知异常，没有注意捕获的时候
            html = SendMailUtil.getHtml("未知异常报警", st.getClassName(),
                    st.getMethodName(), st.getLineNumber() + "", getStackTrace(re));
        }
        try {
            SendMailUtil.sendEmail("3528381482@qq.com", html);
            SendMailUtil.sendEmail("2116154058@qq.com", html);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
        }
        logger.info("发送邮件成功**********************");
    }

    private static String getStackTrace(Throwable throwable) {
        StringWriter sw = new StringWriter();
        PrintWriter pw = new PrintWriter(sw);
        try {
            throwable.printStackTrace(pw);
            return sw.toString();
        } finally {
            pw.close();
        }
    }
}
