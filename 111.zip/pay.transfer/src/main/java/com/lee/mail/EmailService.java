package com.lee.mail;

public interface EmailService {

    void sendEmail(Exception e);
}
