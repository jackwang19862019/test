package com.lee.yidian;

import com.alibaba.fastjson.JSONObject;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Random;

public class YiDian {

    static final String payUrl = "http://yd.ydbill.net/YBT/pay";

    static final String key = "0nUtoUf0mvI5zFw";

    static final String shbs = "lbCrx";

    public static void main(String[] args) throws UnsupportedEncodingException {
        checkDds();
        payYidian();
    }

    private static void checkDds() {
        String s = "123456";
        String sign = MD5(s);
        System.out.println("比对MD5算法：" + sign.toUpperCase());

        String tes = "version=V1.0&merchantNum=123456&nonce_str=DNqFUYuXb5BSGKsg&merMark=A123&client_ip=127.0.0.1&payType=aliCode&orderNum=ABC10000&amount=1&body=ordered:S1000000&key=11111111111";
        String str = MD5(tes);
        System.out.println("比对MD5签名：" + str.toUpperCase());
    }

    private static void payYidian() throws UnsupportedEncodingException {
        RestTemplate restTemplate = new RestTemplate();
        Map map = new LinkedHashMap();
        map.put("version", "V1.0");
        map.put("merchantNum", "888073");
        map.put("nonce_str", randomStr(4));
        map.put("merMark", shbs);
        map.put("client_ip", "127.0.0.1");
        map.put("payType", "aliH5");
        map.put("orderNum", System.currentTimeMillis() + "");
        map.put("amount", "50000");
        map.put("body", "描述");
        String sign = SignatureUtils.sign(map, "&key=" + key, false);
        System.out.println("参与签名:" + map);

        map.put("signType", "MD5");
        map.put("notifyUrl", "http://aaa");
        map.put("returnUrl", "http://aaa");
        map.put("orderTime", "2019-01-22 08:23:12");
        map.put("sign", sign.toUpperCase());
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(map), String.class);
        System.out.println("第三方返回：" + result);
        JSONObject jsonObject = JSONObject.parseObject(result);
        String resp_errMsg = jsonObject.getString("resp_ErrMsg");

        String s1 = new String(resp_errMsg.getBytes(), "UTF-8");
        System.out.println(s1);

    }

    public static String randomStr(int num) {
        char[] randomMetaData = new char[]{'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
                'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
                'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4',
                '5', '6', '7', '8', '9'};
        Random random = new Random();
        String tNonceStr = "";
        for (int i = 0; i < num; i++) {
            tNonceStr += (randomMetaData[random.nextInt(randomMetaData.length - 1)]);
        }
        return tNonceStr;
    }

    static final char HEX_DIGITS[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    public final static String MD5(String data) {
        try {
            byte[] btInPut = data.getBytes("UTF-8");
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            mdInst.update(btInPut);
            byte[] md = mdInst.digest();
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = HEX_DIGITS[byte0 >>> 4 & 0xf];
                str[k++] = HEX_DIGITS[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
            return null;
        }
    }
}
