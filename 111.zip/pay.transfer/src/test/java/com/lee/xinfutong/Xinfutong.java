package com.lee.xinfutong;

import com.alibaba.fastjson.JSON;
import com.lee.lf.ToolKit;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.web.client.RestTemplate;

import java.security.MessageDigest;
import java.util.Map;
import java.util.TreeMap;

public class Xinfutong {

    static final String md5Key = "6h73cpj3zpu3f323xi5k5jgu5kixnhtnmer9ri6r7bwe6m9j2u2muls8qsc9k4mi";

    static final String merchNo = "100000000007927";

    static final String type = "SHA类型";

    public static void main(String[] args) {
        String orderNo = System.currentTimeMillis() + "";
        String paymethod = "directPay";
        String defaultbank = "ALIPAY";
        String isApp = "web";

        String payUrl = "https://ebank.xfuoo.com/payment/v1/order/" + merchNo + "-" + orderNo;

        Map params = new TreeMap();
        params.put("defaultbank", defaultbank);
        params.put("isApp", isApp);
        params.put("body", "商品描述");
        params.put("charset", "UTF-8");
        params.put("merchantId", merchNo);
        params.put("notifyUrl", "http://aa/bb");
        params.put("orderNo", orderNo);
        params.put("paymentType", "1");
        params.put("paymethod", paymethod);
        params.put("returnUrl", "http://aa/bb");
        params.put("service", "online_pay");
        params.put("title", "商品");
        params.put("totalFee", "500");

        String signParams = SignatureUtils.buildParams(params, false) + md5Key;
        System.out.println("签名参数：" + signParams);
        String sign = string2Sha1(signParams);
        params.put("signType", "SHA");
        params.put("sign", sign);

        String request = ToolKit.request(payUrl, JSON.toJSONString(params));


        System.out.println("返回："+request);
    }

    public static String string2Sha1(String str) {
        if (str == null || str.length() == 0) {
            return null;
        }
        char hexDigits[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9',
                'a', 'b', 'c', 'd', 'e', 'f'};
        try {
            MessageDigest mdTemp = MessageDigest.getInstance("SHA1");
            mdTemp.update(str.getBytes("UTF-8"));

            byte[] md = mdTemp.digest();
            int j = md.length;
            char buf[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                buf[k++] = hexDigits[byte0 >>> 4 & 0xf];
                buf[k++] = hexDigits[byte0 & 0xf];
            }
            return new String(buf);
        } catch (Exception e) {
            // TODO: handle exception
            return null;
        }
    }

}
