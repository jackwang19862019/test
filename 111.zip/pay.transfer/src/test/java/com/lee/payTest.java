package com.lee;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Base64Utils;
import com.lee.common.utils.Md5Util;
import org.springframework.web.client.RestTemplate;

import java.util.Base64;
import java.util.HashMap;
import java.util.Map;

public class payTest {

    //http://ip地址/channel/Common/mail_interface

    private static final String merchantNo = "123456";

    private static final String merchantKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQDEJc5beaGoIRJKkc1JjKBnFKhVnHjV3xL2KHkAyCplgqYb0LMpwBwYaUcq38IPqDuDf3vusEByj8fyKUU16z++By2NtufenuOAAg4DZggSUQG08bBmqNLSvYZqj8MTzS3HBPyBrjln+i7R7oVzb6aLGbh3P4Elumui0SC7n8AnOQIDAQAB";

    public static void main(String[] args) throws Exception {
        RestTemplate rest = new RestTemplate();


        Map<String, String> params = new HashMap<>();
        params.put("channelNo", "chenyitong");
        params.put("outChannel", "wechatpay");

        params.put("amount", "500");

        params.put("merchNo", merchantNo);
        params.put("orderNo", System.currentTimeMillis() + "");
        params.put("product", "666");
        params.put("memo", "111111");
        params.put("returnUrl", "http://www.google.com");
        params.put("notifyUrl", "http://www.google.com");
        params.put("userId", "1");
        params.put("reqIp", "35.221.195.22");

        byte[] context = JSON.toJSONString(params).getBytes("utf-8");
        String sign = Md5Util.sign(new String(context, "UTF-8"), merchantKey, "UTF-8");

        params.clear();
        params.put("sign", sign);
        params.put("context", Base64Utils.encode(context));
        params.put("encryptType", "MD5");

        System.out.println(new String(Base64.getDecoder().decode(params.get("context"))));

        String result = rest.postForObject("http://localhost:10086/pay/order", params, String.class);

        System.out.println(result);

        JSONObject jObj = JSON.parseObject(result);
        if (!"0".equals(jObj.getString("code"))) {
            return;
        }

        context = jObj.getBytes("context");

        JSONObject jsonObject = JSON.parseObject(new String(context, "UTF-8"));

        System.out.println(jsonObject.getString("pay_form"));

        System.out.println(jsonObject.getString("qrcode_url"));

        System.out.println(jsonObject.toJSONString());
    }
}
