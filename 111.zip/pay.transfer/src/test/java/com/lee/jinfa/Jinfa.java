package com.lee.jinfa;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.LogByMDC;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.util.LinkedHashMap;
import java.util.Map;

public class Jinfa {

    static final String payWxWap = "http://interface.yjfpay.com:8081/pay.do";

    static final String payAliWap = "http://interface.yjfpay.com:8082/pay.do";

    static final String payWap = "http://interface.yjfpay.com:8080/pay.do";

    static final String key = "15AE89377A584FB04680EFC8CDC7850876294CE39820CD58";

    public static void main(String[] args) throws UnsupportedEncodingException {
        Map<String, String> params = new LinkedHashMap<>();
        params.put("version", "1.0");
        params.put("mer_id", "02013732137");
        params.put("order_id", System.currentTimeMillis() + "");
        params.put("price", "50000");
        params.put("notify_url", "http://aaa/bbb");
        params.put("pay_type", "quick");
        params.put("randomid", System.currentTimeMillis() + "");
        System.out.println("签名参数前：" + JSON.toJSONString(params));

        String signParams = SignatureUtils.buildParams(params, false) + "&key=" + key;
        System.out.println("签名参数后：" + signParams);

        String sign = SignatureUtils.getMD5(signParams);
        params.put("return_url", "http://aaa/bbb");
        params.put("sign", sign);

        RestTemplate restTemplate = new RestTemplate();
        String result = restTemplate.postForObject(payWap, HttpsParams.buildFormEntity(params), String.class);
        System.out.println("result1 = " + result);

        Map<String, String> map = JSON.parseObject(result, new TypeReference<Map<String, String>>() {
        });
        String code = map.get("code");
        if (!"00".equals(code)) {
            String message = map.get("message");
            //编码
            String errorMsg = unicode2String(message);
            throw new RException("上游返回：" + errorMsg);
        }
        String data = map.get("data");
        System.out.println("data = " + data);

        Map<String, String> dataMap = JSON.parseObject(data, new TypeReference<Map<String, String>>() {
        });

        String signdata = dataMap.get("sign");
        System.out.println("sign = " + signdata);

        String pay_order = dataMap.get("pay_order");
        String order_id = dataMap.get("order_id");
        String price = dataMap.get("price");
        String pay_type = dataMap.get("pay_type");
        String qrcode_url = dataMap.get("qrcode_url");
        String signParam = "pay_order="+pay_order+"&order_id="+order_id+"&price="+price+"&pay_type="+pay_type+"&qrcode_url="+qrcode_url+"&code=00&key="+key;
        String md5Sign = SignatureUtils.getMD5(signParam);
        if (!md5Sign.equals(signdata)){
            throw new RException("金发支付验签失败");
        }
        System.out.println("验签成功");
    }


    /**
     * unicode 转字符串
     */
    public static String unicode2String(String unicode) {

        StringBuffer string = new StringBuffer();

        String[] hex = unicode.split("\\\\u");

        for (int i = 1; i < hex.length; i++) {

            // 转换出每一个代码点
            int data = Integer.parseInt(hex[i], 16);

            // 追加成string
            string.append((char) data);
        }

        return string.toString();
    }
}
