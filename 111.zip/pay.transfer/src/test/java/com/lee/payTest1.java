package com.lee;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.exception.RException;
import com.lee.common.utils.Base64Utils;
import com.lee.common.utils.Md5Util;
import com.lee.common.utils.RSAUtils;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.xinfa.utils.ToolKit;
import org.springframework.web.client.RestTemplate;
import sun.misc.BASE64Encoder;

import java.net.URLEncoder;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.TreeMap;

public class payTest1 {

    public static final String merchNo_ = "XF201808160001";

    public static final String channelNo = "xinfa";

    public static final String md5Key = "9416F3C0E62E167DA02DC4D91AB2B21E";

    private static final String payUrl = "http://netway.xfzfpay.com:90/api/pay";

    private static final String rsaPayPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCrsYFumeMyrbPH0pe/9qQGG+yS3ofp7ooHdtqrDLumzm+x4va+9aQFIW6P12zBvmZvrPCIzFJZW9054Ucy04fEf5k42ldT4kbLSk4EInHOmcWTa6XvYHSUwDLOt79rxVSjNQbouOR3jqe4oBIVo5dSvpVs65ovYDB3A2ZdAZMC8QIDAQAB";

    public static void main(String[] args) throws Exception {
        RestTemplate rest = new RestTemplate();

        Map<String, String> params = new HashMap<>();
        params.put("version", "V3.3.0.0");//版本号
        params.put("merchNo", merchNo_);//商户号
        params.put("randomNum", "123456");//支付类型
        params.put("payType", "ZFB");//支付类型
        params.put("orderNo", System.currentTimeMillis()+"");//订单号
        //订单金额，单位:分
        params.put("amount", "40000");
        params.put("goodsName", "测试");//商品名称
        params.put("notifyUrl", "http://www.google.com");//异步通知地址
        params.put("notifyViewUrl", "http://www.google.com");//回显地址
        params.put("charsetCode", "UTF-8");//回显地址

        System.out.println("签名之前map："+JSON.toJSONString(params));
        params.put("sign", SignatureUtils.md5MapSortSign(params, md5Key).toUpperCase());

        System.out.println("加密前map："+JSON.toJSONString(params));
        byte[] dataStr = ToolKit.encryptByPublicKey(ToolKit.mapToJson(params).getBytes(ToolKit.CHARSET), rsaPayPublicKey);

        System.out.println("BASE64Encoder encode之前："+new String(dataStr));
        String param = new BASE64Encoder().encode(dataStr);

        String reqParam = "data=" + URLEncoder.encode(param, ToolKit.CHARSET) + "&merchNo=" +  params.get("merchNo");
        System.out.println("请求报文是："+reqParam);

        String resultJsonStr = ToolKit.request(payUrl, reqParam);

        System.out.println("返回值："+resultJsonStr);
        JSONObject resultJsonObj = JSONObject.parseObject(resultJsonStr);
        String stateCode = resultJsonObj.getString("stateCode");

        String resultSign = resultJsonObj.getString("sign");
        resultJsonObj.remove("sign");
        Map map = new TreeMap<>(resultJsonObj);
        String targetString = ToolKit.MD5(JSON.toJSONString(map) + md5Key, ToolKit.CHARSET);
        System.out.println(resultSign.equals(targetString));

    }

    private static boolean checkSignForXinFa(Map<String, String> params) {
        String sign = params.get("sign");
        params.remove("sign");
        String resultStr = JSON.toJSONString(params);
        return Md5Util.verifySign(resultStr, md5Key, sign);
    }
}
