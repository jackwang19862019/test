package com.lee;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.MatchUtils;

import java.io.BufferedInputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

public class payTest2 {

    public static final String merchNo_ = "HR190709163436492";

    public static final String channelNo = "hengrun";

    public static final String md5Key = "479880D5A767435B488E43D7E0D66E90";

    private static final String payUrl = "http://api.kuaile8899.com:8088";

    public static void main(String[] args) throws Exception {

        Map<String, String> params = new HashMap<>();
        params.put("appID", merchNo_);//商户号
        params.put("tradeCode", "60005");//见接口文档3.2  产品类型
        params.put("randomNo", MatchUtils.generateShortUuid());//随机数
        params.put("outTradeNo", System.currentTimeMillis() + "");//订单号 保证为一性
        params.put("totalAmount", "10000");//订单金额（分）
        params.put("productTitle", "vico");//商品标题
        params.put("notifyUrl", "http://www.xxx.com/xxxx");//交易异步回调地址ַ
        params.put("tradeIP", "136.2.11.115");//交易请求IP

        String signDataStr = getSignDataStr(params, md5Key);//拼装签名串
        System.out.println("签名前参数:" + signDataStr);
        String sign = MD5(signDataStr, "UTF-8");
        System.out.println("签名sign:" + sign);
        params.put("sign", sign);
        JSONObject jsonObject = JSONObject.parseObject(JSON.toJSONString(params));
        String reqParam = "ApplyParams=" + jsonObject;
        System.out.println("请求uri:" + payUrl);
        System.out.println("请求参数:" + reqParam);
        String resultJsonStr = requestPost(payUrl + "/pay/apply.shtml", reqParam, 30000);
        System.out.println("请求返回结果：" + resultJsonStr);
        // 验证提交状态
        JSONObject resultJsonObj = JSONObject.parseObject(resultJsonStr);
        String stateCode = resultJsonObj.getString("stateCode");
        if (!"0000".equals(stateCode)) {//0000表示成功，其他均为失败
            System.out.println("失败");
        }

        String resultSign = (String) resultJsonObj.remove("sign");
        Map<String, String> resultMap = JSONObject.toJavaObject(resultJsonObj, Map.class);
        String targetSign = MD5(getSignDataStr(resultMap, md5Key), "UTF-8");
        if (resultSign.equals(targetSign)) {
            System.out.println("验签成功");
        } else {
            System.out.println("验签失败");
        }
        System.out.println("返回数据：" + JSON.toJSONString(resultMap));

    }

    /**
     * Http请求
     *
     * @param url     请求地址
     * @param timeOut 请求连接超时时间
     * @return
     */
    public static String requestPost(String url, String str, int timeOut) {
        HttpURLConnection conn = null;
        try {
            URL urlObj = new URL(url);
            conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(timeOut);
// 设置文件类型:
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length", String.valueOf(str.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(str.toString().getBytes("utf-8"));
            outStream.flush();
            outStream.close();
            if (conn.getResponseCode() == 200) {
                try {
                    BufferedInputStream buf = new BufferedInputStream(conn.getInputStream());
                    byte[] buffer = new byte[1024];
                    StringBuffer data = new StringBuffer();
                    int readDataLen;
                    while ((readDataLen = buf.read(buffer)) != -1) {
                        data.append(new String(buffer, 0, readDataLen, "UTF-8"));
                    }
                    return data.toString();
                } catch (Exception e) {
                    return null;
                }
            } else {
                return null;
            }
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * MD5 加密方法
     *
     * @param s
     * @param encoding
     * @return
     */
    static final char HEX_DIGITS[] = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'A', 'B', 'C', 'D', 'E', 'F'};

    public final static String MD5(String data, String encoding) {
        try {
            byte[] btInPut = data.getBytes(encoding);
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            mdInst.update(btInPut);
            byte[] md = mdInst.digest();
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = HEX_DIGITS[byte0 >>> 4 & 0xf];
                str[k++] = HEX_DIGITS[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
            return null;
        }
    }


    /**
     * 获取签名字符串
     * 签名字符串拼装规则   对键排序  对值竖线拼接  value1|value2|value3|....|md5Key
     *
     * @param reqDataMap
     * @param md5Key
     * @return
     */
    public static String getSignDataStr(Map<String, String> reqDataMap, String md5Key) {
        if (reqDataMap != null) {
            //键值排序
            Object[] keys = reqDataMap.keySet().toArray();
            Arrays.sort(keys);
            //拼装字符串
            StringBuffer params = new StringBuffer();
            for (int i = 0; i < keys.length; i++) {
                params.append(reqDataMap.get(keys[i]));
                params.append("|");
            }
            params.append(md5Key);
            return params.toString();
        }
        return null;
    }


}
