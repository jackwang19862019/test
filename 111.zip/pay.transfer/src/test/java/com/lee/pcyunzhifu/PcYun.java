package com.lee.pcyunzhifu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.http.HttpResponse;
import org.apache.http.HttpStatus;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.util.EntityUtils;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

public class PcYun {

    static final String md5Key = "XgfGM3QCxscy3Gxm4dqyd4zYnXCBDMJe";
    static final String payUrl = "http://gateway.188pc.cn/Pay";


    public static void main(String[] args) throws UnsupportedEncodingException {
        RestTemplate restTemplate = new RestTemplate();
        Map<String, String> dataMap = new TreeMap<>();
        dataMap.put("pid", "10004888888730");
        dataMap.put("type", "alipay");
        long orderNo = System.currentTimeMillis();
        System.out.println("订单号：" + orderNo);
        dataMap.put("out_trade_no", orderNo + "");

        dataMap.put("notify_url", "http://aaa/bb");
        dataMap.put("return_url", "http://aaa/bb");
        dataMap.put("name", "测试");
        dataMap.put("money", "500");

        String sign = SignatureUtils.sign(dataMap, md5Key);
        dataMap.put("sign", sign);
        dataMap.put("sign_type", "MD5");
        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(dataMap), String.class);
        System.out.println(JSON.toJSONString(result));
        JSONObject jsonObject = JSONObject.parseObject(result);
        //{"code":500,"errmsg":"\u7b7e\u540d\u6821\u9a8c\u5931\u8d25","sign":null}
        String errmsg = jsonObject.getString("errmsg");

        System.out.println(errmsg);

        String str = new String("\u521b\u5efa\u6210\u529f");
        System.out.println(str);
    }

    /**
     * post请求表单
     *
     * @param url
     * @param paramsMap
     * @return
     */
    public static JSONObject doPostFrom(String url, Map<String, String> paramsMap) {
        CloseableHttpClient httpclient = HttpClients.createDefault();

        HttpPost post = new HttpPost(url);

        List<BasicNameValuePair> pairList = new ArrayList<>();
        for (String key : paramsMap.keySet()) {
            pairList.add(new BasicNameValuePair(key, paramsMap.get(key)));
            System.out.println("键值对：" + key + ":" + paramsMap.get(key));
        }


        JSONObject response = null;
        try {
            UrlEncodedFormEntity urlEncodedFormEntity = new UrlEncodedFormEntity(pairList, "UTF-8");
            post.setEntity(urlEncodedFormEntity);
            HttpResponse res = httpclient.execute(post);
            if (res.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                String result = EntityUtils.toString(res.getEntity());//
                response = JSON.parseObject(result);

                System.out.println(response);

            } else {

            }
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        return response;
    }


}
