package com.lee;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.lee.common.utils.Base64Utils;
import com.lee.common.utils.Md5Util;
import com.lee.common.utils.RSAUtils;
import com.lee.pay.entity.MerchantEntity;
import com.lee.pay.entity.OrderEntity;
import com.lee.pay.order.delay.NotifyTask;
import com.lee.pay.service.MerchantService;
import com.lee.pay.service.OrderService;
import com.lee.paythird.ydw360.utils.ToolKit;
import org.apache.commons.codec.digest.DigestUtils;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.context.embedded.LocalServerPort;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.test.context.junit4.SpringRunner;
import org.springframework.web.client.RestTemplate;

import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.*;

import static com.lee.common.utils.AesUtil.key;

@RunWith(SpringRunner.class)
@SpringBootTest(classes = Application.class, webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class SignTest {

    @LocalServerPort
    private int port;

    @Autowired
    private RestTemplate restTemplate;

    @Autowired
    private MerchantService merchantService;

    @Autowired
    private OrderService orderService;

    @Autowired
    private NotifyTask notifyTask;


    @Test
    public void testMD5Sign() throws Exception {
        String pPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC/fLSiN5T9EzSSTLjQD6B/a7trphh5E5wpX7JSuprX4qdvxLY6r8vocXTPq5IMy3Z7oxKD0BsbkUZ4f6kXecz4odzf89VoIWOCdDsFhtfB9QAbjqjy0OB2as4OfrjY59Ohu4uQseha5BHY+gUjRnY8QUiUbshQuGyxuWdCOTwLFwIDAQAB";
        String pPrivateKey = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAL98tKI3lP0TNJJMuNAPoH9ru2umGHkTnClfslK6mtfip2/Etjqvy+hxdM+rkgzLdnujEoPQGxuRRnh/qRd5zPih3N/z1WghY4J0OwWG18H1ABuOqPLQ4HZqzg5+uNjn06G7i5Cx6FrkEdj6BSNGdjxBSJRuyFC4bLG5Z0I5PAsXAgMBAAECgYBiP8AGw3IEb8g3kHn69ymod0RQtYY1CWTErb83R1uPjVHPvSSq8+wxtZTzwNpNClAem8syKqLeACoiRY4i53HM9H7GOWdciTJC38Zfq3MwVUnydfpnj4swFQ7Zvu46cq9HXkzW7B6frb3TjFC9cwEuiZ1KKjfiP7Dg2KIVXcKOcQJBAO/+eaT2VTmNEdG17pOLIrQZVIfrvtppjCb25SflU4N7QmeKXQ7XqcK82jgZ1RHuwm1F5lnwcZcmuoeVbJd4yK0CQQDMQgzl1+r+QovYD7Lx/5/QMbVB/kij9nA1gWKyxzUsPQKiMLLQp/9QhanyI4HyNrv3F9yKZ73Rav3tqNxJd0dTAkEAsOBfbPn0E+dpg6LPg8RevleQ2mAgGD8EAU+j0oSMyXGVnlP2g9Lklda0CfbX91B90SVcQVsZjKoJfZXeI8DsPQJBAKfuEd6R40DBg2nSlmOBr2mixIwKPLyY6u4CfxvOzfed/WFNOmZ0CGOyUOOjr71spKLkukwMOLJJDZXsQ5ge+cMCQEPw33FJXVD10+bPIFmHBroDXvszxngcbd5wuPZkKB2IWpaw6SApJ5FuaTmUN2pYrWGImBp2ONHWAar+q44lO7g=";

        MerchantEntity merchant = merchantService.selectByMerchantNo("123456");
        Map<String, String> params = new HashMap<>();
        params.put("channelNo", "xinfubao");
        params.put("merchNo", merchant.getMerchantNo());
        params.put("orderNo", System.currentTimeMillis() + "");
        params.put("amount", "500");
        params.put("outChannel", "wechatpay");
        params.put("product", "666");
        params.put("memo", "111111");
        params.put("returnUrl", "http://www.google.com");
        params.put("notifyUrl", "http://www.google.com");
        params.put("userId", "1");
        params.put("reqIp", "35.221.195.22");

        byte[] context = JSON.toJSONString(params).getBytes("utf-8");
        String sign = Md5Util.sign(new String(context, "UTF-8"), merchant.getPublicKey(), "UTF-8");

//        byte[] context = RSAUtils.encryptByPublicKey(JSON.toJSONBytes(params), pPublicKey);
        String mPrivateKey = merchant.getPrivateKey();
//        String sign = RSAUtils.sign(context, mPrivateKey);

        params.clear();
        params.put("sign", sign);
        params.put("context", Base64Utils.encode(context));
        params.put("encryptType", "MD5");

        System.out.println(new String(Base64.getDecoder().decode(params.get("context"))));

        String result = restTemplate.postForObject("http://localhost:" + port + "/pay/order", params, String.class);
//        String result = restTemplate.postForObject("http://47.91.219.11:10086/pay/order", params, String.class);
//        String result = restTemplate.postForObject("http://localhost:10086/pay/order", params, String.class);

        System.out.println(result);

        JSONObject jObj = JSON.parseObject(result);
        if (!"0".equals(jObj.getString("code"))) {
            return;
        }


        sign = jObj.getString("sign");
        context = jObj.getBytes("context");

        JSONObject jsonObject = JSON.parseObject(new String(context, "UTF-8"));

        System.out.println(jsonObject.getString("pay_form"));

        System.out.println(jsonObject.getString("qrcode_url"));

        System.out.println(jsonObject.toJSONString());
    }








    @Test
    public void testSign() throws Exception {
        String pPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC/fLSiN5T9EzSSTLjQD6B/a7trphh5E5wpX7JSuprX4qdvxLY6r8vocXTPq5IMy3Z7oxKD0BsbkUZ4f6kXecz4odzf89VoIWOCdDsFhtfB9QAbjqjy0OB2as4OfrjY59Ohu4uQseha5BHY+gUjRnY8QUiUbshQuGyxuWdCOTwLFwIDAQAB";
        String pPrivateKey = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAL98tKI3lP0TNJJMuNAPoH9ru2umGHkTnClfslK6mtfip2/Etjqvy+hxdM+rkgzLdnujEoPQGxuRRnh/qRd5zPih3N/z1WghY4J0OwWG18H1ABuOqPLQ4HZqzg5+uNjn06G7i5Cx6FrkEdj6BSNGdjxBSJRuyFC4bLG5Z0I5PAsXAgMBAAECgYBiP8AGw3IEb8g3kHn69ymod0RQtYY1CWTErb83R1uPjVHPvSSq8+wxtZTzwNpNClAem8syKqLeACoiRY4i53HM9H7GOWdciTJC38Zfq3MwVUnydfpnj4swFQ7Zvu46cq9HXkzW7B6frb3TjFC9cwEuiZ1KKjfiP7Dg2KIVXcKOcQJBAO/+eaT2VTmNEdG17pOLIrQZVIfrvtppjCb25SflU4N7QmeKXQ7XqcK82jgZ1RHuwm1F5lnwcZcmuoeVbJd4yK0CQQDMQgzl1+r+QovYD7Lx/5/QMbVB/kij9nA1gWKyxzUsPQKiMLLQp/9QhanyI4HyNrv3F9yKZ73Rav3tqNxJd0dTAkEAsOBfbPn0E+dpg6LPg8RevleQ2mAgGD8EAU+j0oSMyXGVnlP2g9Lklda0CfbX91B90SVcQVsZjKoJfZXeI8DsPQJBAKfuEd6R40DBg2nSlmOBr2mixIwKPLyY6u4CfxvOzfed/WFNOmZ0CGOyUOOjr71spKLkukwMOLJJDZXsQ5ge+cMCQEPw33FJXVD10+bPIFmHBroDXvszxngcbd5wuPZkKB2IWpaw6SApJ5FuaTmUN2pYrWGImBp2ONHWAar+q44lO7g=";

        MerchantEntity merchant = merchantService.selectByMerchantNo("123456");
        Map<String, String> params = new HashMap<>();
        params.put("channelNo", "dingding");
        params.put("merchNo", merchant.getMerchantNo());
        params.put("orderNo", System.currentTimeMillis() + "");
        params.put("amount", "60");
        params.put("outChannel", "alipay");
        params.put("product", "666");
        params.put("memo", "111111");
        params.put("returnUrl", "http://www.google.com");
        params.put("notifyUrl", "http://www.google.com");


        byte[] context = RSAUtils.encryptByPublicKey(JSON.toJSONBytes(params), pPublicKey);
        String mPrivateKey = merchant.getPrivateKey();
        String sign = RSAUtils.sign(context, mPrivateKey);

        params.clear();
        params.put("sign", sign);
        params.put("context", Base64Utils.encode(context));
        params.put("encryptType", "RSA");

        String result = restTemplate.postForObject("http://localhost:" + port + "/pay/order", params, String.class);
//        String result = restTemplate.postForObject("http://35.220.195.82:10086/pay/order", params, String.class);

        System.out.println(result);

        JSONObject jObj = JSON.parseObject(result);
        if (!"0".equals(jObj.getString("code"))) {
            return;
        }


        sign = jObj.getString("sign");
        context = jObj.getBytes("context");

        if (RSAUtils.verify(context, pPublicKey, sign)) {
            result = new String(RSAUtils.decryptByPrivateKey(context, mPrivateKey));
            JSONObject jsonObject = JSON.parseObject(result);
            System.out.println(jsonObject.getString("qrcode_url"));
        }

    }


    @Test
    public void testQuery() throws Exception {
        String pPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC/fLSiN5T9EzSSTLjQD6B/a7trphh5E5wpX7JSuprX4qdvxLY6r8vocXTPq5IMy3Z7oxKD0BsbkUZ4f6kXecz4odzf89VoIWOCdDsFhtfB9QAbjqjy0OB2as4OfrjY59Ohu4uQseha5BHY+gUjRnY8QUiUbshQuGyxuWdCOTwLFwIDAQAB";
        String pPrivateKey = "MIICdwIBADANBgkqhkiG9w0BAQEFAASCAmEwggJdAgEAAoGBAL98tKI3lP0TNJJMuNAPoH9ru2umGHkTnClfslK6mtfip2/Etjqvy+hxdM+rkgzLdnujEoPQGxuRRnh/qRd5zPih3N/z1WghY4J0OwWG18H1ABuOqPLQ4HZqzg5+uNjn06G7i5Cx6FrkEdj6BSNGdjxBSJRuyFC4bLG5Z0I5PAsXAgMBAAECgYBiP8AGw3IEb8g3kHn69ymod0RQtYY1CWTErb83R1uPjVHPvSSq8+wxtZTzwNpNClAem8syKqLeACoiRY4i53HM9H7GOWdciTJC38Zfq3MwVUnydfpnj4swFQ7Zvu46cq9HXkzW7B6frb3TjFC9cwEuiZ1KKjfiP7Dg2KIVXcKOcQJBAO/+eaT2VTmNEdG17pOLIrQZVIfrvtppjCb25SflU4N7QmeKXQ7XqcK82jgZ1RHuwm1F5lnwcZcmuoeVbJd4yK0CQQDMQgzl1+r+QovYD7Lx/5/QMbVB/kij9nA1gWKyxzUsPQKiMLLQp/9QhanyI4HyNrv3F9yKZ73Rav3tqNxJd0dTAkEAsOBfbPn0E+dpg6LPg8RevleQ2mAgGD8EAU+j0oSMyXGVnlP2g9Lklda0CfbX91B90SVcQVsZjKoJfZXeI8DsPQJBAKfuEd6R40DBg2nSlmOBr2mixIwKPLyY6u4CfxvOzfed/WFNOmZ0CGOyUOOjr71spKLkukwMOLJJDZXsQ5ge+cMCQEPw33FJXVD10+bPIFmHBroDXvszxngcbd5wuPZkKB2IWpaw6SApJ5FuaTmUN2pYrWGImBp2ONHWAar+q44lO7g=";

        MerchantEntity merchant = merchantService.selectByMerchantNo("123456");
        Map<String, String> params = new HashMap<>();
        params.put("merchNo", merchant.getMerchantNo());
        params.put("orderNo", "1563778435997");

        byte[] context = RSAUtils.encryptByPublicKey(JSON.toJSONBytes(params), pPublicKey);
        String mPrivateKey = merchant.getPrivateKey();
        String sign = RSAUtils.sign(context, mPrivateKey);

        params.clear();
        params.put("sign", sign);
        params.put("context", Base64Utils.encode(context));
        params.put("encryptType", "RSA");

        String result = restTemplate.postForObject("http://localhost:" + port + "/pay/order/query", params, String.class);

        System.out.println(result);

        JSONObject jObj = JSON.parseObject(result);
        if (!"0".equals(jObj.getString("code"))) {
            return;
        }


        sign = jObj.getString("sign");
        context = jObj.getBytes("context");

        if (RSAUtils.verify(context, pPublicKey, sign)) {
            if (RSAUtils.verify(context, pPublicKey, sign)) {
                System.out.println(new String(RSAUtils.decryptByPrivateKey(context, mPrivateKey)));
            }
        }
    }


    @Test
    public void callback() {
        //{"price"="200", "appid"="58sy00001", "sign"="652FED58E678C77434A5BD64C6C502D2598D1D9E", "trade_no"="1562679502016", "time"="2019-07-09 22:00:40", "version"="1.0", "gateway"="13", "status"="500"}
        String str = "{\"transaction_id\":\"20190728215625579910\",\"amount\":\"200.0000\",\"datetime\":\"20190728215702\",\"orderid\":\"1018140309561416\",\"returncode\":\"00\",\"sign\":\"02A795CBDA475690147FFA9C84F01CC8\",\"attach\":\"\",\"memberid\":\"10033\"}";
        Map<String, String> params = JSON.parseObject(str, Map.class);
        String result = restTemplate.postForObject("http://47.91.219.11:10086/pay/callback/daocheng/123456/1018140309561416", params, String.class);
//        String result = restTemplate.postForObject("http://localhost:" + port + "/pay/callback/yinshangfu/123456/1018839008065528", params, String.class);
        System.out.println(result);
    }


}
