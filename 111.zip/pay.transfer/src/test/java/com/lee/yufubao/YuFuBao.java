package com.lee.yufubao;

import com.alibaba.fastjson.JSON;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.web.client.RestTemplate;

import java.util.Map;
import java.util.TreeMap;

public class YuFuBao {

    static final String payUrl = "https://pay.yiihuo.com";

    static final String merchNo = "00A19082819325509500";

    static final String key = "c2f59a4795234995bc523fa5df7c2bc7";

    public static void main(String[] args) {
        yufubaoPayWy();
        //kuaiyitongPayWy();
    }

    /**
     * 扫码
     */
    private static void yufubaoPaySm() {
        RestTemplate restTemplate = new RestTemplate();//请求工具
        Map params = new TreeMap();//ASCII排序Map
        params.put("merNo", "00A19082819325509500");
        params.put("money", "1000");
        params.put("orderId", System.currentTimeMillis() + "");
        params.put("payId", "D0_ALIPAY_SCAN");
        params.put("orderTime", "20190802122312");
        params.put("items", "产品名称");
        params.put("ip", "127.0.0.1");
        params.put("syncRedirectUrl", "http://www.ccc");
        params.put("asyncNotifyUrl", "http://www.ccc");
        params.put("remark", "备注");

        String sign = SignatureUtils.sign(params, key);//签名
        params.put("sign", sign);
        String result = restTemplate.postForObject(payUrl+"/pay/scan", HttpsParams.buildFormEntity(params), String.class);
        System.out.println("第三方返回：" + result);

    }

    private static void yufubaoPayWy() {
        RestTemplate restTemplate = new RestTemplate();
        Map params = new TreeMap();
        params.put("merchantCode", merchNo);
        params.put("amount", "5000");
        params.put("orderNumber", System.currentTimeMillis() + "");
        params.put("payCode", "D0_B2C");
        params.put("submitTime", "20190802122312");
        params.put("commodityName", "产品名称");
        params.put("submitIp", "88.172.168.22");
        params.put("syncRedirectUrl", "http://www.ccc");
        params.put("asyncNotifyUrl", "http://www.ccc");

        params.put("bankCode", "CCB");
        params.put("remark", "备注");

        String sign = SignatureUtils.sign(params, key);
        params.put("sign", sign);
        System.out.println("请求入参："+ JSON.toJSON(params));
        String result = restTemplate.postForObject(payUrl+"/cashier/b2cAPI", HttpsParams.buildFormEntity(params), String.class);
        System.out.println("第三方返回：" + result);
    }

}
