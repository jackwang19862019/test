package com.lee;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Md5Util;
import com.lee.paythird.xinyangyang.Md5;
import com.lee.paythird.xinyangyang.RSAEncrypt;
import com.lee.paythird.xinyangyang.RSASignature;

import java.security.KeyManagementException;
import java.security.KeyStoreException;
import java.security.NoSuchAlgorithmException;

public class Test {

    static String rsaPrivateKey = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBALBGrVpRfsGlHNB0L6g7e2EgScIAS3ZYplv0LAnCcM3iWbZ2LnzwTaaOab5OTAwf93LRPI3lb7Qrg/sakzc1XyeKaK4v2kcOuvuxNLhmb3JljX0ZO4n1bsfuz/Y9uSI4ClPnoSKSetdj4k3idY/xQ4zH7AkajyOMG5r1DeLlumm3AgMBAAECgYEAqsMc5bSyxWZs3mbfT+qnX/SGXyAn+jJwnf2Qt7ebzWarn70m1bN4lZO6TjfNJaXF8X1OWutbZb8N8K/S0xWp4ak5DqXgy4GKY+ewNfcWnF/hlmOoAgWYvmesKJ7aypetns95EzW4SLz9W1vLD5IONEysUPgmOCfDk3+wNtIYpNkCQQDb7KcX3KQvyYjieLVar4N5uimbsoTCcd+B+O/kFw9iT/KLz2ykxDFd99D31nbCy+0q1ToPHJSqnzhD0E/tRukLAkEAzTEWaKKqXZhCgQoH2OEytOGYbhPnH6l1gZ/RLgzT1gWEQQZdsbLMwrFYMpOZyryddfstPOUktLAYTppgPRZlhQJAMMn4a7/EIOHZ3zweJ4cmaLvW/TaGY0i15/Sc64H+JLZNvZx/orHvrcQLdN/8KszoyYbSQYX6qTt3VPwCr0X67wJBAI1xYPkP6FBMPMumlnIyCjoVqHV40sFIlu+bsx4DSaMmelw4fy2XCv7KMPnsNP9DtWc2laB8dCj5mkfUsrJpVeECQQCUU/SA7WYefuQonCgOpBHArbeXXAPiK3cBng3uQnJS8/1nGCaXbjGX8ggdbwrmrh7qZDrevcm5IF0IVrwekZ2A";

    static String params = "Muz9Nl8WwxOzwN3a+0mjX9ScbC2uSsfbjyiLeFXUiCCT8vm1rur+TLFTS1dsCDbkPbSnE1xOWumEJSuAcy0w3EyJNN65TIxX8nrI9MoeL0PL9oUGI9dv4k7o84eJnaNptat/jgr8Pen0KQ0TC0DEd+b6KMGT4X8Bd7E/DWfJESwpt9EJNgmzrxYNGJNCOaMGJoGyx3sgzxnVrdWCiL92ZFSutpMvLHsGueLTfYZ+1oh4VfBmTwFKEYAKiQiKcxyTupBU612uch+b8ptT9gMslmtz5d3jfWjMtM0sHBJKdS+rjTtyJb1MoIoP284brRD+IDc1zB/LEhbEawjlzuIX1lXVAaYVbM0YntHeMZ9POfOQzDOxf/juOaQHujOVG6Ey4zZRjY7urIMJ/nTaKQTSL0A72hjb7SLjTf4AZKj8zHailLkptAskUdoyGukPvrdn6U4YH0TU5t1hOVJuNDrAxmsqFuSVxuNXxV2zYTOpJu+lFMvJoU59Elfq8fUyd5qIWtjiayF3SlbxGogGW70dFvJakbba80NB2NmvfCNWGpGjzxyu4PV/mD+3751CMgB2g+jMmRxLTKl5ngAKzcyZsjjcgQT7WPO9PLc9eYbvmA14GMtPA+6BG0F6DKCe4cskJFqFIO4sbXAW6ZizR80IRq1PglKEYFuZQwqUshunfj4=";

    static String md5Key = "g9uhqqdb751di00pheqdu9x4zow9os2n";

    static String sign = "cpZugYqk068UdApSWygZ04dy4V1p7n5OtphHw3gF1pUIGiGo4pNE3ra0CqIFz08tfl3q6yChsR+uykWPbY6ghTOrmMC1ZDsfoVFwXc/vsIt+llNR0OtorcWYAD3pLIwvjoWNh8keGh/rIfplAg0MQmi3r32EHOCGqXFuE8y+3P0=";

    static String rsaPublicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCwRq1aUX7BpRzQdC+oO3thIEnCAEt2WKZb9CwJwnDN4lm2di588E2mjmm+TkwMH/dy0TyN5W+0K4P7GpM3NV8nimiuL9pHDrr7sTS4Zm9yZY19GTuJ9W7H7s/2PbkiOApT56EiknrXY+JN4nWP8UOMx+wJGo8jjBua9Q3i5bpptwIDAQAB";

    public static void main(String[] args) throws KeyStoreException, NoSuchAlgorithmException, KeyManagementException {
        String ret_d = RSAEncrypt.decrypt(rsaPrivateKey, params);
        System.out.println("解密后的数据："+ret_d);

        JSONObject obj = JSONObject.parseObject(ret_d);
        String memberid = obj.getString("memberid");
        String orderid = obj.getString("orderid");
        String amount = obj.getString("amount");
        String datetime = obj.getString("datetime");
        String returncode = obj.getString("returncode");
        String transaction_id = obj.getString("transaction_id");
        String SignTemp = "amount=" + amount + "&datetime=" + datetime + "&memberid=" + memberid + "&orderid=" + orderid + "&returncode=" + returncode + "&transaction_id=" + transaction_id + "&key=" + md5Key;
        System.out.println("参与签名数据：" + SignTemp);
        String md5sign = Md5.md5(SignTemp);//MD5加密
        System.out.println("MD5签名：" + md5sign);

        boolean res_veitify = RSASignature.doCheck(md5sign, sign, rsaPublicKey);
        System.out.println("签名是否正确" + res_veitify);
    }
}
