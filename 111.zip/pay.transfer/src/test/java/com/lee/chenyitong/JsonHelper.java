package com.lee.chenyitong;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.parser.Feature;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.alibaba.fastjson.serializer.SimplePropertyPreFilter;

public class JsonHelper {

	public static String objToGetString(Object obj, String... fields) {
		StringBuilder sb = new StringBuilder();
		String jsonStr = objToJsonString(obj,fields);
		JSONObject fastJson = JSONObject.parseObject(jsonStr, Feature.OrderedField);
		fastJson.forEach((k, v) -> sb.append(k).append("=").append(String.valueOf(v)).append("&"));
		return sb.toString().substring(0, sb.length()-1);
	}

	public static String objToJsonString(Object obj, String... fields) {
		SimplePropertyPreFilter filter = new SimplePropertyPreFilter();
		if (fields != null && fields.length > 0) {
			for (String field : fields) {
				filter.getExcludes().add(field);
			}
		}
		String jsonStr = JSON.toJSONString(obj, filter, SerializerFeature.WriteNullStringAsEmpty,
				SerializerFeature.WriteNullNumberAsZero, SerializerFeature.WriteNullBooleanAsFalse,
				SerializerFeature.PrettyFormat, SerializerFeature.SortField);
		return jsonStr;
	}
}
