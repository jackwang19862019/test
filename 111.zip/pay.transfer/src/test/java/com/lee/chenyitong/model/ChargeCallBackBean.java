package com.lee.chenyitong.model;

import com.lee.chenyitong.util.DesUtilChenYiTong;

public class ChargeCallBackBean implements java.io.Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 7134364484685209446L;
	private String mchtid;
	private String orderno;
	private String reqdata;

	public String getMchtid() {
		return mchtid;
	}
	public void setMchtid(String mchtid) {
		this.mchtid = mchtid;
	}
	public String getOrderno() {
		return orderno;
	}
	public void setOrderno(String orderno) {
		this.orderno = orderno;
	}
	public String getReqdata() {
		return reqdata;
	}
	public void setReqdata(String reqdata) {
		this.reqdata = reqdata;
	}

	public static class ChargeDetail implements java.io.Serializable{
		/**
		 *
		 */
		private static final long serialVersionUID = 3652950583001723672L;
		private String mchtid;
		private String orderno;
		private String state;
		private String amount;
		private String sign;

		public void decryptModel(String desKey) {
			this.amount = DesUtilChenYiTong.decrypt3DES(this.amount, desKey);
		}


		public String getMchtid() {
			return mchtid;
		}
		public void setMchtid(String mchtid) {
			this.mchtid = mchtid;
		}
		public String getOrderno() {
			return orderno;
		}
		public void setOrderno(String orderno) {
			this.orderno = orderno;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public String getAmount() {
			return amount;
		}
		public void setAmount(String amount) {
			this.amount = amount;
		}
		public String getSign() {
			return sign;
		}
		public void setSign(String sign) {
			this.sign = sign;
		}


	}
}
