package com.lee.chenyitong.model;

import com.alibaba.fastjson.annotation.JSONField;

public class OrderBean {

	/**
	 * 支付下单请求
	 *
	 * @author Leo
	 *
	 */
	public static class OrderRequestBean implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -6837431688884301630L;
		private String mchtid;
		private String reqdata;

		public String getMchtid() {
			return mchtid;
		}

		public void setMchtid(String mchtid) {
			this.mchtid = mchtid;
		}

		public String getReqdata() {
			return reqdata;
		}

		public void setReqdata(String reqdata) {
			this.reqdata = reqdata;
		}

	}

	public static class OrderRsaModel implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -1075345913279157600L;
		@JSONField(name = "p1_mchtid",ordinal = 0)
		private String p1Mchtid;
		@JSONField(name = "p2_paytype",ordinal = 1)
		private String p2Paytype = "FASTPAY";
		@JSONField(name = "p3_paymoney",ordinal = 2)
		private String p3Paymoney;
		@JSONField(name = "p4_orderno",ordinal = 3)
		private String p4Orderno;
		@JSONField(name = "p5_callbackurl",ordinal = 4)
		private String p5Callbackurl;
		@JSONField(name = "p6_notifyurl",ordinal = 5)
		private String p6Notifyurl;
		@JSONField(name = "p7_version",ordinal = 6)
		private String p7Version = "v2.9";
		@JSONField(name = "p8_signtype",ordinal = 7)
		private int p8Signtype = 2;
		@JSONField(name = "p9_attach",ordinal = 8)
		private String p9Attach;
		@JSONField(name = "p10_appname",ordinal = 9)
		private String p10Appname;
		@JSONField(name = "p11_isshow",ordinal = 10)
		private int p11Isshow = 0;
		@JSONField(name = "p12_orderip",ordinal = 11)
		private String p12Orderip = "192.168.10.1";
		@JSONField(name = "p13_memberid",ordinal = 12)
		private String p13Memberid;
		@JSONField(ordinal = 13)
		private String sign;

		public String getP1Mchtid() {
			return p1Mchtid;
		}

		public void setP1Mchtid(String p1Mchtid) {
			this.p1Mchtid = p1Mchtid;
		}

		public String getP2Paytype() {
			return p2Paytype;
		}

		public void setP2Paytype(String p2Paytype) {
			this.p2Paytype = p2Paytype;
		}

		public String getP3Paymoney() {
			return p3Paymoney;
		}

		public void setP3Paymoney(String p3Paymoney) {
			this.p3Paymoney = p3Paymoney;
		}

		public String getP4Orderno() {
			return p4Orderno;
		}

		public void setP4Orderno(String p4Orderno) {
			this.p4Orderno = p4Orderno;
		}

		public String getP5Callbackurl() {
			return p5Callbackurl;
		}

		public void setP5Callbackurl(String p5Callbackurl) {
			this.p5Callbackurl = p5Callbackurl;
		}

		public String getP6Notifyurl() {
			return p6Notifyurl;
		}

		public void setP6Notifyurl(String p6Notifyurl) {
			this.p6Notifyurl = p6Notifyurl;
		}

		public String getP7Version() {
			return p7Version;
		}

		public void setP7Version(String p7Version) {
			this.p7Version = p7Version;
		}

		public int getP8Signtype() {
			return p8Signtype;
		}

		public void setP8Signtype(int p8Signtype) {
			this.p8Signtype = p8Signtype;
		}

		public String getP9Attach() {
			return p9Attach;
		}

		public void setP9Attach(String p9Attach) {
			this.p9Attach = p9Attach;
		}

		public String getP10Appname() {
			return p10Appname;
		}

		public void setP10Appname(String p10Appname) {
			this.p10Appname = p10Appname;
		}

		public int getP11Isshow() {
			return p11Isshow;
		}

		public void setP11Isshow(int p11Isshow) {
			this.p11Isshow = p11Isshow;
		}

		public String getP12Orderip() {
			return p12Orderip;
		}

		public void setP12Orderip(String p12Orderip) {
			this.p12Orderip = p12Orderip;
		}

		public String getP13Memberid() {
			return p13Memberid;
		}

		public void setP13Memberid(String p13Memberid) {
			this.p13Memberid = p13Memberid;
		}

		public String getSign() {
			return sign;
		}

		public void setSign(String sign) {
			this.sign = sign;
		}
	}

	public static class OrderResponseBean implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = 8567372614079789763L;
		private int rspCode;
		private String rspMsg;
		private String data;

		public int getRspCode() {
			return rspCode;
		}

		public void setRspCode(int rspCode) {
			this.rspCode = rspCode;
		}

		public String getRspMsg() {
			return rspMsg;
		}

		public void setRspMsg(String rspMsg) {
			this.rspMsg = rspMsg;
		}

		public String getData() {
			return data;
		}

		public void setData(String data) {
			this.data = data;
		}

	}

	public static class OrderResponseData implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -5474322587237820996L;
		@JSONField(name = "r1_mchtid",ordinal = 0)
		private String r1Mchtid;
		@JSONField(name = "r2_systemorderno",ordinal = 1)
		private String r2Systemorderno;
		@JSONField(name = "r3_orderno",ordinal = 2)
		private String r3Orderno;
		@JSONField(name = "r4_amount",ordinal = 3)
		private String r4Amount;
		@JSONField(name = "r5_version",ordinal = 4)
		private String r5Version;
		@JSONField(name = "r6_qrcode",ordinal = 5)
		private String r6Qrcode;
		@JSONField(name = "r7_paytype",ordinal = 6)
		private String r7Paytype;
		@JSONField(ordinal = 7)
		private String sign;

		public String getR1Mchtid() {
			return r1Mchtid;
		}

		public void setR1Mchtid(String r1Mchtid) {
			this.r1Mchtid = r1Mchtid;
		}

		public String getR2Systemorderno() {
			return r2Systemorderno;
		}

		public void setR2Systemorderno(String r2Systemorderno) {
			this.r2Systemorderno = r2Systemorderno;
		}

		public String getR3Orderno() {
			return r3Orderno;
		}

		public void setR3Orderno(String r3Orderno) {
			this.r3Orderno = r3Orderno;
		}

		public String getR4Amount() {
			return r4Amount;
		}

		public void setR4Amount(String r4Amount) {
			this.r4Amount = r4Amount;
		}

		public String getR5Version() {
			return r5Version;
		}

		public void setR5Version(String r5Version) {
			this.r5Version = r5Version;
		}

		public String getR6Qrcode() {
			return r6Qrcode;
		}

		public void setR6Qrcode(String r6Qrcode) {
			this.r6Qrcode = r6Qrcode;
		}

		public String getR7Paytype() {
			return r7Paytype;
		}

		public void setR7Paytype(String r7Paytype) {
			this.r7Paytype = r7Paytype;
		}

		public String getSign() {
			return sign;
		}

		public void setSign(String sign) {
			this.sign = sign;
		}
	}

	public static class OrderQueryRsaModel implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -1075345913279157600L;
		@JSONField(name = "p1_mchtid",ordinal = 0)
		private String p1Mchtid;
		@JSONField(name = "p2_signtype",ordinal = 1)
		private int p2Paytype = 2;
		@JSONField(name = "p3_orderno",ordinal = 2)
		private String p3Orderno;
		@JSONField(name = "p4_version",ordinal = 3)
		private String p4Version = "v2.9";
		@JSONField(ordinal = 4)
		private String sign;

		public String getP1Mchtid() {
			return p1Mchtid;
		}

		public void setP1Mchtid(String p1Mchtid) {
			this.p1Mchtid = p1Mchtid;
		}


		public int getP2Paytype() {
			return p2Paytype;
		}

		public void setP2Paytype(int p2Paytype) {
			this.p2Paytype = p2Paytype;
		}

		public String getP3Orderno() {
			return p3Orderno;
		}

		public void setP3Orderno(String p3Orderno) {
			this.p3Orderno = p3Orderno;
		}

		public String getP4Version() {
			return p4Version;
		}

		public void setP4Version(String p4Version) {
			this.p4Version = p4Version;
		}

		public String getSign() {
			return sign;
		}

		public void setSign(String sign) {
			this.sign = sign;
		}
	}

	public static class OrderQueryResponseData implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -5474322587237820996L;
		@JSONField(name = "r1_mchtid",ordinal = 0)
		private int r1Mchtid;
		@JSONField(name = "r2_systemorderno",ordinal = 1)
		private String r2Systemorderno;
		@JSONField(name = "r3_orderno",ordinal = 2)
		private String r3Orderno;
		@JSONField(name = "r4_amount",ordinal = 3)
		private String r4Amount;
		@JSONField(name = "r5_orderstate",ordinal = 4)
		private String r5_orderstate;
		@JSONField(name = "r6_version",ordinal = 5)
		private String r6Version;
		@JSONField(ordinal = 6)
		private String sign;

		public int getR1Mchtid() {
			return r1Mchtid;
		}


		public String getR2Systemorderno() {
			return r2Systemorderno;
		}


		public void setR2Systemorderno(String r2Systemorderno) {
			this.r2Systemorderno = r2Systemorderno;
		}


		public String getR3Orderno() {
			return r3Orderno;
		}


		public void setR3Orderno(String r3Orderno) {
			this.r3Orderno = r3Orderno;
		}


		public String getR4Amount() {
			return r4Amount;
		}


		public void setR4Amount(String r4Amount) {
			this.r4Amount = r4Amount;
		}


		public String getR5_orderstate() {
			return r5_orderstate;
		}


		public void setR5_orderstate(String r5_orderstate) {
			this.r5_orderstate = r5_orderstate;
		}


		public String getR6Version() {
			return r6Version;
		}


		public void setR6Version(String r6Version) {
			this.r6Version = r6Version;
		}


		public void setR1Mchtid(int r1Mchtid) {
			this.r1Mchtid = r1Mchtid;
		}


		public String getSign() {
			return sign;
		}

		public void setSign(String sign) {
			this.sign = sign;
		}
	}
}
