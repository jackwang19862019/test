package com.lee.chenyitong.model;


import com.lee.chenyitong.util.DesUtilChenYiTong;

public class ChargeBean {
	/**
	 * 代付下单请求
	 *
	 * @author Leo
	 *
	 */
	public static class ChargeRequestBean implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -6837431688884301630L;
		private int mchtid;
		private String reqdata;

		public int getMchtid() {
			return mchtid;
		}

		public void setMchtid(int mchtid) {
			this.mchtid = mchtid;
		}

		public String getReqdata() {
			return reqdata;
		}

		public void setReqdata(String reqdata) {
			this.reqdata = reqdata;
		}

	}

	public static class ChargeRsaModel implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -1075345913279157600L;
		private int mchtid;
		private String version = "v2.1.0.0";
		private Long transtime;
		private String transid;
		private String sign;
		private String notifyurl;
		private String userip;

		public int getMchtid() {
			return mchtid;
		}

		public void setMchtid(int mchtid) {
			this.mchtid = mchtid;
		}

		public String getVersion() {
			return version;
		}

		public void setVersion(String version) {
			this.version = version;
		}

		public Long getTranstime() {
			return transtime;
		}

		public void setTranstime(Long transtime) {
			this.transtime = transtime;
		}

		public String getTransid() {
			return transid;
		}

		public void setTransid(String transid) {
			this.transid = transid;
		}

		public String getSign() {
			return sign;
		}

		public void setSign(String sign) {
			this.sign = sign;
		}

		public String getNotifyurl() {
			return notifyurl;
		}

		public void setNotifyurl(String notifyurl) {
			this.notifyurl = notifyurl;
		}

		public String getUserip() {
			return userip;
		}

		public void setUserip(String userip) {
			this.userip = userip;
		}

		private String amount;
		private String bankaccountname;
		private String bankaccountno;
		private String branchname;
		private String bankcode;

		public void encryptModel(String desKey) {
			this.amount = DesUtilChenYiTong.encrypt3DES(this.amount, desKey);
			this.bankaccountname = DesUtilChenYiTong.encrypt3DES(this.bankaccountname, desKey);
			this.bankaccountno = DesUtilChenYiTong.encrypt3DES(this.bankaccountno, desKey);
			this.branchname = DesUtilChenYiTong.encrypt3DES(this.branchname, desKey);
			this.bankcode = DesUtilChenYiTong.encrypt3DES(this.bankcode, desKey);
		}

		public String getAmount() {
			return amount;
		}

		public void setAmount(String amount) {
			this.amount = amount;
		}

		public String getBankaccountname() {
			return bankaccountname;
		}

		public void setBankaccountname(String bankaccountname) {
			this.bankaccountname = bankaccountname;
		}

		public String getBankaccountno() {
			return bankaccountno;
		}

		public void setBankaccountno(String bankaccountno) {
			this.bankaccountno = bankaccountno;
		}

		public String getBranchname() {
			return branchname;
		}

		public void setBranchname(String branchname) {
			this.branchname = branchname;
		}

		public String getBankcode() {
			return bankcode;
		}

		public void setBankcode(String bankcode) {
			this.bankcode = bankcode;
		}


	}

	public static class ChargeQueryRsaModel implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -1075345913279157600L;
		private int mchtid;
		private String version = "v2.1.0.0";
		private Long transtime;
		private String transid;
		private String sign;

		public int getMchtid() {
			return mchtid;
		}

		public void setMchtid(int mchtid) {
			this.mchtid = mchtid;
		}

		public String getVersion() {
			return version;
		}

		public void setVersion(String version) {
			this.version = version;
		}

		public Long getTranstime() {
			return transtime;
		}

		public void setTranstime(Long transtime) {
			this.transtime = transtime;
		}

		public String getTransid() {
			return transid;
		}

		public void setTransid(String transid) {
			this.transid = transid;
		}

		public String getSign() {
			return sign;
		}

		public void setSign(String sign) {
			this.sign = sign;
		}

	}

	public static class ChargeResponseBean implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = 8567372614079789763L;
		private int code;
		private String info;
		private ChargeResponseData data;

		public int getCode() {
			return code;
		}

		public void setCode(int code) {
			this.code = code;
		}

		public String getInfo() {
			return info;
		}

		public void setInfo(String info) {
			this.info = info;
		}

		public ChargeResponseData getData() {
			return data;
		}

		public void setData(ChargeResponseData data) {
			this.data = data;
		}

	}

	public static class ChargeResponseData implements java.io.Serializable {

		/**
		 *
		 */
		private static final long serialVersionUID = -5474322587237820996L;
		private int mchtid;
		private String orderno;
		private int state;
		private String amount;
		private String sign;

		public void decryptModel(String desKey) {
			this.amount = DesUtilChenYiTong.decrypt3DES(this.amount, desKey);
		}

		public int getMchtid() {
			return mchtid;
		}

		public void setMchtid(int mchtid) {
			this.mchtid = mchtid;
		}

		public String getOrderno() {
			return orderno;
		}

		public void setOrderno(String orderno) {
			this.orderno = orderno;
		}

		public int getState() {
			return state;
		}

		public void setState(int state) {
			this.state = state;
		}

		public String getAmount() {
			return amount;
		}

		public void setAmount(String amount) {
			this.amount = amount;
		}

		public String getSign() {
			return sign;
		}

		public void setSign(String sign) {
			this.sign = sign;
		}

	}

}
