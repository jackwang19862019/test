package com.lee.chenyitong;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.alibaba.fastjson.TypeReference;
import com.alibaba.fastjson.serializer.SerializerFeature;
import com.lee.chenyitong.model.OrderBean;
import com.lee.chenyitong.util.HttpHelperChenYiTong;
import com.lee.chenyitong.util.RSAUtilChenYiTong;
import com.lee.common.utils.RSAUtils;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.BuildFormUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.commons.codec.digest.DigestUtils;
import org.bouncycastle.jcajce.provider.asymmetric.rsa.RSAUtil;
import org.springframework.web.client.RestTemplate;

import java.net.URLEncoder;
import java.util.*;

public class Chenyitong {

    /*static final String merchNo = "50000000";

    static final String key = "f739754fb4cf6f066b638b4d24d85c66";

    static final String payUrl = "http://gate.chengyitpay.com/api/pay/v2";

    static final String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCp9Y/gMPWmgzTZ2VOcSwQPjbHkHvEkiK8vopts0ibd3LQkIC+p7hzcfEYXVPRCXlzgIOQygaraeUKoXAZAZoegOmWMU5F/OH1DeB+1nJhwZkyCPREHzG8/u6jVjqgazk2kgsGGsp9hX9/B6EqFQi1M8kROwdoZ5eWWokZ0ldzifQIDAQAB";

    static final String privateKey = "MIICdgIBADANBgkqhkiG9w0BAQEFAASCAmAwggJcAgEAAoGBAMA51vSc6bUTU2bIeS+1tBFhdMgLvw1WZpFAaotJh5hxiKj+7B+icOsN4re8hqqa+gKQeJ//CO9A6h5jytLdxa3FRHAsL6Mfey42Qj7gtGcMBK7KOsT5qZf7G59EDH+POMtT5MfpHBEKBaCNuVl7Z3ZLkdN1wOPtH6YVMpXJuHdNAgMBAAECgYACnicHwMVMAn3dxfgkhrBzliStfr900ormCn8I85DlqhIm3wXfLmqkQNWoE+ivlRm3hDkoUKRSAcvOayR9d6iz/Y/+SVnD0lmXlBwnJAhoNisPdimBSi+hvWgssATZItdu+i0z97grLSTxIU4ZKxRG303i8tVmdWS0B7UD87AEYQJBAO0+i/NdLiWwQYPJG4U09LAEdIP27ZN0pT+3u8PSxRdDyTCYXalqnYzFm1uGkcz0MBatEtxPJoZbpSIt95/whz0CQQDPbDD+uSqCWcnupGDUh0O6Jei/5HuOrErsLTg0fanr0X4pjqHqwEDF7cNwqa4+4ydZP1HRa6Hsq8nCYvDbVzFRAkAIwqqATgyKL7v7lc2CWbY/WarDxLZ5H3GKrMouLPZCKaqgNMAgpWMz84gNFScFHm84JyPvJq0RgQjT/kaKjWMxAkB+NaG2TGruN74kJAb7KnbuXES8BkWcMX/BJ16sqc3rvGPc23nwQhznkl26PrTUdRkrN9kL6Ub0oC66xcMyY2KRAkEA7LJ59DyCtyugLhn83ad+p9X2CKUCVODoEOUVpqCL7ex2zjGEn4kY4wUfWfqG/QB4SP2VnqOESLkSfPWmI+YCLQ==";
*/
    static final String merchNo = "50005874";

    static final String key = "228f5fe95c42868a79cd78d7e4e0185f";

    static final String payUrl = "http://gate.chengyitpay.com/api/pay/v2";

    static final String publicKey = "MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQC9ya3C68GBQ8KsbMWjKFwcKiyaK0GIns+UQsQmobuuUjiEDzTE/OAEi92vJ046aAQWvSmms5umWhfPwCsbrikBUof5l9BTYcjpG+diu3iXtBgMsF2e0ktmz5shuQXUFm1H+j6Zd2pKAL3Pha/5NIbeAtwJOGQDJ+xSsCWNW25UvwIDAQAB";

    static final String privateKey = "MIICeAIBADANBgkqhkiG9w0BAQEFAASCAmIwggJeAgEAAoGBANFf5WN0Nx2aHzYSP8mnq+JPmxbg2kNG9uXbVJwsEkz83pRlV9lwNw6Y8nUc1jWfv5DL7mNmCUxatjEFhYWHHBDpmByDZ0eYojgdfR+lTy2ebJTXivpEjv5WzbhlsBUbmoPUcohohHXjRw2xZIsjYJe+2i0iZNpN9bVtSj0ILvnZAgMBAAECgYA6J9xD3SZn+wS7VKNSJFgKYtktqCQH9uCiZOMiA93Lc5txdZrKozAvxkzmOa3INEiV9AcRpehkRHgBssptFeO10BwKe2EHDeQDhpuhoKzA3BupRl3Gqlp392wVMjMP8+EUrgJJDAJOytWpdBWRbiUgP1vK145oqGRmQtr6M8WCFwJBANvwLeQtZGQBBYxLYc4th8M6//ApBNjjxYBb6k9lbLIboX1BNP9CyctumWvXzG86r2s1QzTj+V00GUfleV9WQ7cCQQDztFBBz5zVluPuT8/93spxlBpvDpPMgaAiNaJDF+wwzmkvQrikJC1qpoTFe5EF+WRSi/Ssl1BEjR3lmXVaHE7vAkEAjsFEaDh2Utq+6SL8psCywCuJeC6HsOeWiAwg98vTU3/Pv+cVKSIGrP5qoq79SK0Es0dtCeV3M+HfDuWJdDIf3QJBANAWe5zmAB1kXLUE0y0LScLXWgbP5KVvXWM4dpdhWtyFssyW5P/KoDj7fEz/aGI4g0/0jvO7s98Eu61rbgeGOmMCQQCWCMZgoTdxVZtARi/1lSeOb3UWqitQSkQkQzXcDCN5wj7FOj5oG/1iY7lz9ibt5WrO9mCUReIef3QN1RMSGEwD";


    public static void main(String[] args) throws Exception {
        String orderId = System.currentTimeMillis()+"";
        //me(orderId);
        us(orderId);
        //testAAA();
    }

    private static void testAAA() throws Exception {

        String encryData = "{\"mchtid\":\"100000000\",\"version\":\"v2.1.0.0\",\"bankaccountname\":\"Pt9X1EaMjkM=\",\"bankaccountno\":\"VrATD/0qLS4fljlSYgp0G9kav6/NWcf9\",\"branchname\":\"yhUAK7N1GjLF4juatCZqNg==\",\"bankcode\":\"qVArgwM90rU=\",\"amount\":\"LLrO0pzjpIE=\",\"transid\":\"st390154650\",\"transtime\":\"1494511566322\",\"sign\":\"ee0f52b7b5bacc8f9379f8ecbb2d0678\",\"notifyurl\":\"http://localhost:55817/PaidItemCallBack.aspx\",\"userip\":\"127.0.0.1\"}";
        String afterEncryData = RSAUtilChenYiTong.encryptByPublicKey(encryData, publicKey);
        String wdEncryStr = "W7TxL7kBN6ySJ8+Cp8SmncMjVRZZw93L/8sFQeqvfTALDUXTcNh1VTo6U6UGE997y9x8VpshkrDsjEtM/ZR9+FNRvnC07EDQhzfbxwmk1BNM5CmbyK0+gGVXTnjoflvApZpcRxpYWJ2kcglvFxyZz4EXVqR0nodWwRWkV6Fvk8N16OuqumN7nhsHX5O8bm+FvbWjOLnWUTI4xWG3YPAIosOn/BTxdNDv76//dlizgQldJ+ZS9JrNws7Ph4SAJ2W/5/x4IoUWBgIV+57Rbp6QmQPqJpu8n1aumLdZFLgtN3RY1EeZsnvXsHYwEbQduFlprRthRVwqZZ1HMrl8PRrfEHkPKdeG35bDQEQThieVs0gO0bLAOWwoZwwYCJRJeOsHJO+cMqWT6ATM/K5C+VVuu/KA0dVGzZ1p6jrNn6i9Y9U3ESQHXyon/crbmFBza0sYXSJu5ra3gM2kZFFxXYtnul3t0z5UnjXg4eKLbmI6ub9/AeYtLd9gMTGjOHyglY1FOXLSJriSysNnl43lX/9LXEcvjZUzXRF6kblg0vqSdIWmH//1QEqvuSGwhnOPomJn1ltxgMWepqUzgKHIrfBCj1+pb2R9qyfV6NDoN4vPNmqKXVWPAU3lHbVdPZegVzajbIPoks0yNVK86BaCehIkZHuza0vsDZP0UrXHZ9JYk50=";
        System.out.println("RSA加密对比数据："+wdEncryStr.equals(afterEncryData));

        String str = RSAUtilChenYiTong.decryptByPrivateKey(wdEncryStr, privateKey);
        boolean equals = str.equals(encryData);
        System.out.println("RSA解密对比数据："+equals);

        //验签
        JSONObject jsonObject = JSONObject.parseObject(encryData);

    }

    private static void me(String orderId) throws Exception {

        RestTemplate restTemplate = new RestTemplate();
        Map<String, String> map = new LinkedHashMap<>();
        map.put("p1_mchtid", merchNo);
        map.put("p2_paytype", "UFWECHAT");//UNIONFASTPAY  UFALIPAY  UFWECHAT
        map.put("p3_paymoney", "3");
        map.put("p4_orderno", orderId);
        map.put("p5_callbackurl", "http://www.baidu.com/PayCallback.aspx");
        map.put("p6_notifyurl", "http://www.baidu.com/jump.aspx");
        map.put("p7_version", "v2.8");
        map.put("p8_signtype", "1");
        map.put("p9_attach", "测试");
        map.put("p10_appname", "appname");
        map.put("p11_isshow", "0");
        map.put("p12_orderip", "127.0.0.1");
        map.put("p13_memberid", "000");
        String str = SignatureUtils.buildParams(map,false);

        System.out.println("-------------------参与签名的字符：" + str);


        String sign = DigestUtils.md5Hex(str + key);


        System.out.println("-------------------签名sign：" + sign);
        map.put("sign", sign);
        System.out.println("-------------------参与加密字符串" + JSON.toJSONString(map));
        String rsaStr = JSON.toJSONString(map);

        String bytes = RSAUtils.encryptByPublicKey(rsaStr, publicKey);

        Map map1 = new LinkedHashMap();
        map1.put("mchtid", merchNo);
        map1.put("reqdata", URLEncoder.encode(bytes, "UTF-8"));

        String result = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(map1), String.class);
        //String s = BuildFormUtils.buildSubmitForm(payUrl, map1);

        System.out.println("第三方返回参数：" + result);
    }





    private static void us(String orderId) throws Exception {
        OrderBean.OrderRsaModel reqBean = new OrderBean.OrderRsaModel();
        reqBean.setP1Mchtid(merchNo);
        reqBean.setP2Paytype("UNIONFASTPAY");//
        reqBean.setP3Paymoney("500");
        reqBean.setP4Orderno(orderId);
        reqBean.setP5Callbackurl("http://www.baidu.com/PayCallback.aspx");
        reqBean.setP6Notifyurl("http://www.baidu.com/jump.aspx");
        reqBean.setP7Version("v2.9");
        reqBean.setP8Signtype(2);
        reqBean.setP9Attach("测试");
        reqBean.setP10Appname("appname");
        reqBean.setP11Isshow(0);
        reqBean.setP12Orderip("127.0.0.1");
        reqBean.setP13Memberid("000");

        final String s = JsonHelper.objToGetString(reqBean, "sign");
        final String sign = DigestUtils.md5Hex(s + key);
        reqBean.setSign(sign);
        OrderBean.OrderRequestBean requestBean = new OrderBean.OrderRequestBean();
        requestBean.setMchtid(reqBean.getP1Mchtid());
        requestBean.setReqdata(URLEncoder.encode(
                RSAUtilChenYiTong.encryptByPublicKey(JsonHelper.objToJsonString(reqBean), publicKey),
                "UTF-8"));
        final String result = HttpHelperChenYiTong.post(payUrl, (Map<String, String>) JSON.toJSON(requestBean));
        OrderBean.OrderResponseBean orderResponseBean = JSONObject.toJavaObject(JSONObject.parseObject(result),
                OrderBean.OrderResponseBean.class);
        if (orderResponseBean.getRspCode() == 1) {
            JSONObject jo = JSONObject.parseObject(result);
            String data = jo.getString("data");
            //验签
            Map<String, String> dataMap = JSON.parseObject(data, new TypeReference<TreeMap<String, String>>() {
            });
            //排序

            String signThird = dataMap.remove("sign");
            final String str = JsonHelper.objToGetString(dataMap, "sign");
            final String signStr = DigestUtils.md5Hex(str + key);
            System.out.println("验签结果："+signThird.equals(signStr));
        }
        System.out.println("返回结果："+JSON.toJSONString(orderResponseBean));
    }

}
