package com.lee.chenyitong.util;

import com.alibaba.fastjson.JSON;
import org.apache.commons.io.IOUtils;
import org.apache.http.Header;
import org.apache.http.HttpResponse;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.entity.UrlEncodedFormEntity;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.DefaultConnectionKeepAliveStrategy;
import org.apache.http.impl.nio.client.CloseableHttpAsyncClient;
import org.apache.http.impl.nio.client.HttpAsyncClientBuilder;
import org.apache.http.impl.nio.conn.PoolingNHttpClientConnectionManager;
import org.apache.http.impl.nio.reactor.DefaultConnectingIOReactor;
import org.apache.http.impl.nio.reactor.IOReactorConfig;
import org.apache.http.message.BasicNameValuePair;
import org.apache.http.nio.reactor.ConnectingIOReactor;
import org.apache.http.nio.reactor.IOReactorException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.IOException;
import java.util.List;
import java.util.Map;
import java.util.concurrent.Future;
import java.util.stream.Collectors;

/**
 * @ClassName: HttpHelper
 * @Description:
 * @author Leo
 */
public class HttpHelperChenYiTong {

	private static final Logger log = LoggerFactory.getLogger(HttpHelperChenYiTong.class);

	private static CloseableHttpAsyncClient httpClient;

	static {

		IOReactorConfig ioReactorConfig = IOReactorConfig.custom()
				.setIoThreadCount(Runtime.getRuntime().availableProcessors()).setSoKeepAlive(true).build();
		// 设置连接池大小
		ConnectingIOReactor ioReactor = null;
		try {
			ioReactor = new DefaultConnectingIOReactor(ioReactorConfig);
		} catch (IOReactorException e) {
			e.printStackTrace();
		}
		PoolingNHttpClientConnectionManager cm = new PoolingNHttpClientConnectionManager(ioReactor);
		cm.setMaxTotal(500);
		cm.setDefaultMaxPerRoute(100);
		RequestConfig.Builder requestConfigBuilder = RequestConfig.custom();
		// 客户端和服务器建立连接的timeout
		requestConfigBuilder.setConnectTimeout(30000);
		// 从连接池获取连接的timeout
		requestConfigBuilder.setConnectionRequestTimeout(30000);
		requestConfigBuilder.setCookieSpec("easy");
		requestConfigBuilder.setRedirectsEnabled(false);
		// 连接建立后，request没有回应的timeout
		requestConfigBuilder.setSocketTimeout(30000);
		HttpAsyncClientBuilder clientBuilder = HttpAsyncClientBuilder.create();
		clientBuilder.setDefaultRequestConfig(requestConfigBuilder.build());
		// 连接建立后，request没有回应的timeout
		clientBuilder.setKeepAliveStrategy(new DefaultConnectionKeepAliveStrategy());
		clientBuilder.setConnectionManager(cm);
		httpClient = clientBuilder.build();
		httpClient.start();
	}

	public static String getMethod(String url) {
		HttpGet httpGet = new HttpGet(url);
		HttpResponse response;
		try {
			final Future<HttpResponse> future = httpClient.execute(httpGet, null);
			response = future.get();
			return IOUtils.toString(response.getEntity().getContent(), "UTF-8");
		} catch (Exception ex) {
			log.error("http error:", ex);
		} finally {
			httpGet.releaseConnection();
		}
		return null;
	}

	public static String postMethod(String url, Map<String, Object> param) throws IOException {
		HttpPost httpost = new HttpPost(url);
		log.info("HTTP请求URL:" + url);
		log.info("HTTP请求参数:" + JSON.toJSONString(param));
		HttpResponse response;
		try {
			StringEntity entity = new StringEntity(JSON.toJSONString(param), ContentType.APPLICATION_JSON);
			httpost.setEntity(entity);
			final Future<HttpResponse> future = httpClient.execute(httpost, null);
			response = (HttpResponse) future.get();
			String result = IOUtils.toString(response.getEntity().getContent(), "UTF-8");
			log.info("HTTP返回结果:" + result);
			return result;
		} catch (Exception ex) {
			log.error("http error:", ex);
		} finally {
			httpost.releaseConnection();
		}
		return null;
	}

	public static String post(String url, Map<String, String> params) {
		HttpPost httpPost = new HttpPost(url);
		log.info("HTTP请求URL:" + url);
		log.info("HTTP请求参数:" + JSON.toJSONString(params));
		HttpResponse response;
		try {
			List<BasicNameValuePair> pairList = params.entrySet().stream()
					.map(e -> new BasicNameValuePair(e.getKey(), String.valueOf(e.getValue())))
					.collect(Collectors.toList());
			httpPost.setEntity(new UrlEncodedFormEntity(pairList, "UTF-8"));
			final Future<HttpResponse> future = httpClient.execute(httpPost, null);
			response = (HttpResponse) future.get();
			int code = response.getStatusLine().getStatusCode();
			if (code == 302) {
				Header header = response.getFirstHeader("location"); // 跳转的目标地址是在 HTTP-HEAD 中的
				log.info("重定向url地址:" + header.getValue());
				httpPost.setEntity(new UrlEncodedFormEntity(pairList, "UTF-8"));
				final Future<HttpResponse> future302 = httpClient.execute(httpPost, null);
				response = (HttpResponse) future302.get();
				code = response.getStatusLine().getStatusCode();
			}
			String result = IOUtils.toString(response.getEntity().getContent(), "UTF-8");
			log.info("HTTP返回结果:" + result);
			return result;
		} catch (Exception e) {
			log.error("http error:", e);
		} finally {
			httpPost.releaseConnection();
		}

		return null;
	}

}
