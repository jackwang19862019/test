package com.lee.chenyitong.util;

import org.bouncycastle.jce.provider.BouncyCastleProvider;

import javax.crypto.Cipher;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.SecretKeySpec;
import java.io.UnsupportedEncodingException;
import java.security.NoSuchAlgorithmException;
import java.security.Security;

/**
 * Des 加密解密。兼容.net
 * @author Leo
 *
 */
public class DesUtilChenYiTong {

	private static final String Algorithm = "DESede";
	private static Cipher cip;
	static {
		createCip();
	}

	public static String encrypt3DES(String value, String key) {
		try {
			createCip();
			cip.init(Cipher.ENCRYPT_MODE, generateKey(key));
			byte[] buf = cip.doFinal(value.getBytes("UTF-8"));
			return Base64UtilsChenYiTong.encodeToString(buf);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	public static String decrypt3DES(String value, String key) {
		try {
			createCip();
			cip.init(Cipher.DECRYPT_MODE, generateKey(key));
			byte[] buf = cip.doFinal(Base64UtilsChenYiTong.decodeFromString(value));
			return new String(buf, "utf-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	private static Cipher createCip() {
		if (cip != null)
			return cip;
		try {
			Security.addProvider(new BouncyCastleProvider());
			cip = Cipher.getInstance(Algorithm + "/ECB/PKCS7Padding");
		} catch (NoSuchAlgorithmException e) {
			e.printStackTrace();
		} catch (NoSuchPaddingException e) {
			e.printStackTrace();
		}
		return cip;
	}

	private static SecretKey generateKey(String secretKey) {
		SecretKey newKey = null;
		try {
			newKey = new SecretKeySpec(buildCLenKey(secretKey, 24), Algorithm);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return newKey;
	}

	private static byte[] buildCLenKey(String keyStr, int lgn) throws UnsupportedEncodingException {
		byte[] key = new byte[lgn]; // 声明一个24位的字节数组，默认里面都是0
		byte[] temp = keyStr.getBytes("UTF-8"); // 将字符串转成字节数组
		if (key.length > temp.length) {
			// 如果temp不够24位，则拷贝temp数组整个长度的内容到key数组中
			System.arraycopy(temp, 0, key, 0, temp.length);
		} else {
			// 如果temp大于24位，则拷贝temp数组24个长度的内容到key数组中
			System.arraycopy(temp, 0, key, 0, key.length);
		}
		return key;
	}
}
