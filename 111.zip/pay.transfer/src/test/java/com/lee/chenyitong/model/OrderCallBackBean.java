package com.lee.chenyitong.model;

public class OrderCallBackBean implements java.io.Serializable{

	/**
	 *
	 */
	private static final long serialVersionUID = 7134364484685209446L;
	private String partner;
	private String ordernumber;
	private String reqdata;
	public String getPartner() {
		return partner;
	}
	public void setPartner(String partner) {
		this.partner = partner;
	}
	public String getOrdernumber() {
		return ordernumber;
	}
	public void setOrdernumber(String ordernumber) {
		this.ordernumber = ordernumber;
	}
	public String getReqdata() {
		return reqdata;
	}
	public void setReqdata(String reqdata) {
		this.reqdata = reqdata;
	}

	public static class OrderDetail implements java.io.Serializable{
		/**
		 *
		 */
		private static final long serialVersionUID = 3652950583001723672L;
		private String partner;
		private String ordernumber;
		private String orderstatus;
		private String paymoney;
		private String sysnumber;
		private String attach;
		private String sign;
		public String getPartner() {
			return partner;
		}
		public void setPartner(String partner) {
			this.partner = partner;
		}
		public String getOrdernumber() {
			return ordernumber;
		}
		public void setOrdernumber(String ordernumber) {
			this.ordernumber = ordernumber;
		}
		public String getOrderstatus() {
			return orderstatus;
		}
		public void setOrderstatus(String orderstatus) {
			this.orderstatus = orderstatus;
		}
		public String getPaymoney() {
			return paymoney;
		}
		public void setPaymoney(String paymoney) {
			this.paymoney = paymoney;
		}
		public String getSysnumber() {
			return sysnumber;
		}
		public void setSysnumber(String sysnumber) {
			this.sysnumber = sysnumber;
		}
		public String getAttach() {
			return attach;
		}
		public void setAttach(String attach) {
			this.attach = attach;
		}
		public String getSign() {
			return sign;
		}
		public void setSign(String sign) {
			this.sign = sign;
		}


	}
}
