package com.lee;

import com.alibaba.fastjson.JSON;
import com.lee.common.utils.DateUtil;
import com.lee.common.utils.LogByMDC;
import com.lee.common.utils.R;
import com.lee.paythird.utils.HttpsParams;
import com.lee.paythird.xinfa.utils.ToolKit;
import com.lee.util.HttpClient;
import com.lee.util.HttpClientResult;
import org.apache.commons.codec.digest.DigestUtils;
import org.apache.http.NameValuePair;
import org.apache.http.client.config.RequestConfig;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.util.StringUtils;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.*;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class payTest3 {

    public static final String channelNo = "pangpangfu";

    private final static String payUrl = "http://api.pangpangfu.com/v1/pay";

    private DecimalFormat df = new DecimalFormat("#.00");

    public static void main(String[] args) {

        String aaa = "\u9a8c\u7b7e\u53c2\u6570\u9519\u8bef";
        String string = unicodeToString(aaa);
        System.out.println("==========================="+string);

/*
        RestTemplate restTemplate = new RestTemplate();
        DecimalFormat df = new DecimalFormat("#.00");

        Map<String, String> params = new TreeMap<>();
        //商户uid
        params.put("merchant", "666087");
        //必填。单位：元。精确小数点后2位
        params.put("amount", df.format(new BigDecimal(5)));
        //当前时间
        params.put("currentTime", DateUtil.getCurrentNumStr());
        //通知回调网址
        params.put("notifyUrl", "http://demo.pangpangfu.com/notifyUrl.php");
        //商户自定义订单号
        params.put("orderNo", System.currentTimeMillis() + "");
        //支付方式
        params.put("payType", "alipay");
        //跳转网址
        params.put("returnUrl", "http://demo.pangpangfu.com/returnUrl.php");

        String signParams = sign(params);
        System.out.println("参与加签signParams:" + signParams);
        String sign = DigestUtils.md5Hex(signParams + "#" + "2fef0b2f85fb4834a4daf7bcdfccec2e").toUpperCase();
        System.out.println("签名sign:" + sign);
        params.put("sign", sign);
        System.out.println("发送请求数据:" + JSON.toJSONString(params));

        List<NameValuePair> list = new ArrayList<>();
        params.forEach((k,v)->list.add(new BasicNameValuePair(k, v)));
        String resultJsonStr = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        //String resultJsonStr = HttpClient.postForm(payUrl, list);
        System.out.println("返回后数据："+unicodeToString(resultJsonStr));*/
    }

    private static String sign(Map<String, String> params) {
        StringBuffer sb = new StringBuffer();
        params.forEach((k, v) -> {
            sb.append(k + "=" + v + "&");
        });
        if (!StringUtils.isEmpty(sb)) {
            String str = sb.toString();
            str = str.substring(0, str.length() - 1);
            return str;
        }
        return null;
    }



    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuffer data = new StringBuffer();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, "UTF-8"));
            }
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String unicodeToString(String str) {
        Pattern pattern = Pattern.compile("(\\\\u(\\p{XDigit}{4}))");
        Matcher matcher = pattern.matcher(str);
        char ch;
        while (matcher.find()) {
            ch = (char) Integer.parseInt(matcher.group(2), 16);
            str = str.replace(matcher.group(1), ch+"" );
        }
        return str;
    }
}
