package com.lee.hongniu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.paythird.hongniu.RSAUtils;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.util.Base64;
import java.util.Map;
import java.util.TreeMap;

public class HongNiu {

    public static final String channelNo = "hongniu";

    //https://gateway.fantom.vip/api/v0.1/Deposit/Order
    private static final String payUrl = "https://gateway.fantom.vip/api/v0.1/Deposit/Order";

    private static final String publicKey = "MIIBIjANBgkqhkiG9w0BAQEFAAOCAQ8AMIIBCgKCAQEAlzkstCGepbr/6+5c0vgCTZsDwqDttOJqROlFJp7YUD7cVcmqW8ljkw4RnFuAMqGt1wBYh50F8kG4alz2HnHxSx99DQaYtQ6rGKjxd+QJPkQzyrE8XHOY1AqsZsyl/m4MBuLPz0ovo6pOBbnm1CtmJNTWPxC2n/ER+m0vXiY5TjtAbkQI0a88J6/0GskRI6mHK8782c2wpUA1bh2u0yXqbkRF7TvKiNc2099OzIgvszAnMVFi/X5Cyqg7Jiup0PenbVL2nonNlhga3V09oLepVvxhe81sbLsSbnBwMdb4UCqX9G2dQtfwhbs06R+yMC88YxDClPcg1Xqk1yW+ON+lZQIDAQAB";

    private static final String privateKey = "MIIEvQIBADANBgkqhkiG9w0BAQEFAASCBKcwggSjAgEAAoIBAQCbCD1gnzLfKKZLEBYgC9SFUz7kexeeDpkbOGlHl421rTcEhKNlzj27oA/6v9ZjVG6ArQk78QNazRtDkzUr4z6zQji+IYhA3cmeGft1+SUZy9+ceMPjSaH219r0QnJ5oBE5GEVpOs1PwRSE5KaYw7O1ZxnoKrDPx1Mi7H0TwGI4GX3NlT4FHpmNpnRYjinKMp/AJR7dVtY7gI4XYhdxifLiHHzbUraFaB7RBhQOji5rgM+ZMpYZT1xD0VFdkNwlktlFuNnMgcWtwPWGdRYnzh35ILZHmTsS1e+WPja24mp+UJ5cQpoFNOF+UV6ZXbEvJ7YaGzA6wYyF5boZPdtiDdfrAgMBAAECggEAN9uvKaoSjT87M153alJ43xTQW0hSiRtfZORdYnMjlurzIMidiufVbE3OlB0cpKteKTSvWA6Nk+DEywM2LDrzc2kPwsmYKy7+Ht3jsWz0RigjyF/mzHTSS3sYo9txHYtjyTuKftC1+t9pgjxUHkSc8mZUekcvb520waeNpVkyyl0qsay8oxIZMzizojcwGesUbVJFWiZYKsgajZiLszvNwfY9Qvgc8hIavG2lDPRKKY9bU8gWts2gFT3qQC41ZKXa3HHUQ6WGmdCIiHoTpKG/kI/PuMVQ6QDpq/HkfNYIp1GUodOs6cY9DquxIblkZBA9o0D0mAANxjpC8vlrgGrccQKBgQDxf9mgchuDBE7pL+Q1NjiUAK1S6Y72YI2DlI9bUFFxXLn+zuQh76z9ap1uk75qahKKHzrUollYD3Z2vjRoaiUCNKzKcB9MSRNrxJzTvtEg2lwaXGBX20iWyCZG/ETwFeXrNBnD8ngnxh2W9dT3eGGT1Fi/QxqtpGC7WSOtzuD3GQKBgQCkV0eQnCS56gnKPxB4EsFPA9ZvgJqmspVmRtCCWNfKBUVb37p7if/8oXra21Gc5CGlHleGJu+yc0dmJsFm2qDPrieJFXvO3SWi5gQk+ofrlg2D1WXci8gUKIbtSB+XpL9DkmcaCJlJVnKCxOjKZOGhkV9aDIlO73ujEn5ZI0P7owKBgCkoMc2fRMMKW+xvxgOvjuriRqenuD6S6+styVS1lnusYuJjHgwOjbvOjLAIq9303938Pol4daOFVxobhlD5Lf93PK9vdlYI6i9mnZeUoI1pyWKQtbajX3aa+7MDUThdcwanpXB4hTO6FtbgZIAcWvzXppxJ8mT/a6DiKyt2424ZAoGADwDE0MfgdnSORj9xonSb3znLdsx30eYVy4uFd5Diylem2FdZb/POQeMAE0DYd4lAJRHbDa06TsFFcGbzWw90hOEyTMqATgdUa0WydSnGBNTjEPkHXpYIQwbcIodmEvMAXwvbi73jOJXCyHtvgSKqkpRx7web9W/Ziq6iiEK27x8CgYEAraDEh0cwb/Sf5RKUwLj/75QbBc9HTnWPSGfL9vl0rjzQ5ySTeuzKRVscZMbuouICK0SatnlAwoDYw0QUErc8urD0FdWW3AjWPzUmzfELjsxfw5/6s3Q3nJi4B16PqMk4eIuAk+uh20RMAKovZv/Z3LJpa3blQv+kwouotKem1p4=";


    public static void main(String[] args) throws Exception {
        Map<String, String> params = new TreeMap<>();
        params.put("brandNo", "108300268693");
        params.put("orderNo", System.currentTimeMillis() + "");
        DecimalFormat df = new DecimalFormat("#.00");
        params.put("price", df.format(500));
        params.put("serviceType", "1102");
        params.put("userName", "test-pay-user001");
        params.put("clientIP", "117.191.11.74");
        params.put("signature", getSign(params));

        params.put("callbackUrl", "htpp://api/ooo");
        params.put("frontUrl", "htpp://api/ooo");
        params.put("signType", "RSA-S");
        String request = request(payUrl, JSON.toJSONString(params));

        System.out.println("请求返回参数：" + request);
        JSONObject jsonObject = JSONObject.parseObject(request);
        String resultCode = jsonObject.getString("code");
        if (!"0".equals(resultCode)) {
            String err = jsonObject.getString("message");
            System.out.println("err:" + err);
        }
        String data = jsonObject.getString("data");
        String qrCode = JSONObject.parseObject(data).getString("payUrl");
        System.out.println(qrCode);
    }

    public static String request(String url, String params) {
        try {
            System.out.println("请求报文:" + params);
            URL urlObj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(1000 * 5);
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestProperty("Content-Length", String.valueOf(params.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(params.toString().getBytes("UTF-8"));
            outStream.flush();
            outStream.close();
            return getResponseBodyAsString(conn.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuffer data = new StringBuffer();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, "UTF-8"));
            }
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String getSign(Map<String, String> params) throws Exception {
        System.out.println("参与加签的参数:" + JSON.toJSONString(params));
        String signStr = sign(params);
        System.out.println("转换后的参数：" + signStr);
        byte[] sign = RSAUtils.signMd5ByPriKey(signStr, privateKey);
        String signature = Base64.getEncoder().encodeToString(sign);
        return signature;
    }

    private static String sign(Map<String, String> params) {
        StringBuffer sb = new StringBuffer();
        params.forEach((k, v) -> {
            sb.append(k + "=" + v + "&");
        });
        if (!org.springframework.util.StringUtils.isEmpty(sb)) {
            String str = sb.toString();
            str = str.substring(0, str.length() - 1);
            return str;
        }
        return null;
    }
}
