package com.lee.bifubao;

import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Md5Util;
import com.lee.paythird.demo.utils.SignatureUtils;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.Map;
import java.util.TreeMap;

public class Bifubao {

    static final String payUrl = "http://qq.5555qp.net/api/api_add_order";

    static final String md5Key = "5ypl0y89gj69zms1cl25n2sb7crager1";

    public static void main(String[] args) {
        test1();
    }

    private static void test1() {
        Map<String, String> params = new TreeMap<>();
        params.put("pay_memberid", "10012");
        params.put("pay_orderid", "123456789");
        params.put("pay_bankcode", "903");
        params.put("pay_amount", "500");
        params.put("pay_notifyurl", "http://aaa");
        params.put("pay_callbackurl", "http://aaa");
        String signParams = SignatureUtils.buildParams(params, true) + "&key=" + md5Key;
        System.out.println("参与加签的参数 :" + signParams);
        String sign = Md5Util.MD5(signParams);
        params.put("pay_md5sign", sign.toUpperCase());
        System.out.println("签名：" + sign.toUpperCase());
        String signatureContent =
                        "pay_memberid=" + params.get("pay_memberid") +
                        "&pay_orderid=" + params.get("pay_orderid") +
                        "&pay_bankcode=" + params.get("pay_bankcode") +
                        "&pay_notifyurl=" + params.get("pay_notifyurl") +
                        "&pay_callbackurl=" + params.get("pay_callbackurl") +
                        "&pay_amount=" + params.get("pay_amount") +
                        "&pay_md5sign=" + sign.toUpperCase();
        System.out.println("请求入参：" + signatureContent);
        String result = request(payUrl, signatureContent);
        JSONObject jsonObject = JSONObject.parseObject(result);
        String mes = jsonObject.getString("mes");
        System.out.println("result1 = " + result);
        System.out.println("result2 = " + mes);
    }

    /**
     * 提交请求
     *
     * @param url
     * @param params
     * @return
     */
    public static String request(String url, String params) {
        try {
            URL urlObj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(1000 * 5);
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length", String.valueOf(params.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(params.getBytes(StandardCharsets.UTF_8));
            outStream.flush();
            outStream.close();
            return getResponseBodyAsString(conn.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuilder data = new StringBuilder();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, StandardCharsets.UTF_8));
            }
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
