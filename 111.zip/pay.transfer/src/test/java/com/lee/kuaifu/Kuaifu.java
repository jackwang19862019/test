package com.lee.kuaifu;

import com.alibaba.fastjson.JSON;
import com.lee.gs.util.HttpUtil;
import com.lee.lf.ToolKit;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.Map;

public class Kuaifu {

    static final String payUrl = "http://ban.paykuaifu.com/cgi-bin/netpayment/pay_gate.cgi";

    static final String merchantId = "266376110023320";

    static final String key = "ea20ac136cdbf1f7e4f23f101f52b195";

    public static void main(String[] args) {
        RestTemplate restTemplate = new RestTemplate();
        Map map = new LinkedHashMap();
        //签名数据
        map.put("apiName", "WAP_PAY_B2C");
        map.put("apiVersion", "1.0.0.0");
        map.put("platformID", merchantId);
        map.put("merchNo", merchantId);
        map.put("orderNo", System.currentTimeMillis() + "");
        map.put("tradeDate", "20190903");
        map.put("amt", "200.00");
        map.put("merchUrl", "http://www.merchant.com/handler.jsp");
        map.put("tradeSummary", "支付测试");
        String signParams = getSignParams(map) + key;
        System.out.println("参与签名参数：" + signParams);

        String sign = ToolKit.MD5(signParams, "UTF-8");
        map.put("signMsg", sign);
        map.put("choosePayType", "11");

        String request2 = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(map), String.class);
        System.out.println(request2);
    }

    private static String getSignParams(Map map) {
        StringBuilder sb = new StringBuilder();
        map.forEach((k, v) -> {
            sb.append("&" + k + "=" + v);
        });
        return sb.toString().substring(1, sb.length());
    }

    public static String request(String url, String params) {
        try {
            System.out.println("请求报文:" + params);
            URL urlObj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(1000 * 5);
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length", String.valueOf(params.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(params.toString().getBytes("UTF-8"));
            outStream.flush();
            outStream.close();
            return getResponseBodyAsString(conn.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuffer data = new StringBuffer();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, "UTF-8"));
            }
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
