package com.lee.baiqian;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.Md5Util;
import com.lee.common.utils.Md5Utils;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.Map;
import java.util.TreeMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Baiqian {

    private static final String merchNo_ = "1283765635";

    private static final String payUrl = "https://bq.baiqianpay.com/webezf/web/?app_act=openapi/bq_pay/pay";

    private static final String md5Key = "84491941B7D209D39D93DC01DD5598EF";


    public static void main(String[] args) throws Exception {
        Map<String, String> params = new TreeMap<>();
        DecimalFormat df = new DecimalFormat("#.00");
        params.put("X1_Amount", df.format(500));
        params.put("X2_BillNo", System.currentTimeMillis() + "");
        params.put("X3_MerNo", merchNo_);
        params.put("X4_ReturnURL", "htpp://api/ooo");
        String sign = getSign(params);
        params.put("X6_MD5info", sign);
        System.out.println("签名是：" + sign);
        params.put("X5_NotifyURL", "htpp://api/ooo");
        params.put("X7_PaymentType", "WXH5");
        params.put("X9_ClientIp", "CustomData");
        params.put("X8_MerRemark", "127.0.0.1");
        params.put("isApp", "app");
        String request = request(payUrl, sign(params));
        System.out.println("请求返回参数：" + request);
        JSONObject jsonObject = JSONObject.parseObject(request);
        String message = jsonObject.getString("msg");
        String s = unicodeToString(message);
        System.out.println("请求返回参数：" + s);

    }

    public static String unicodeToString(String str) {

        Pattern pattern = Pattern.compile("(\\\\u(\\p{XDigit}{4}))");

        Matcher matcher = pattern.matcher(str);

        char ch;

        while (matcher.find()) {

            ch = (char) Integer.parseInt(matcher.group(2), 16);

            str = str.replace(matcher.group(1), ch+"" );

        }

        return str;

    }

    public static String request(String url, String params) {
        try {
            System.out.println("请求报文:" + params);
            URL urlObj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(1000 * 5);
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length", String.valueOf(params.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(params.toString().getBytes("UTF-8"));
            outStream.flush();
            outStream.close();
            return getResponseBodyAsString(conn.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuffer data = new StringBuffer();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, "UTF-8"));
            }
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private static String getSign(Map<String, String> params) throws Exception {
        System.out.println("参与加签的参数:" + JSON.toJSONString(params));
        String signStr = sign(params);
        System.out.println("转换后的参数：" + signStr);
        String signature = Md5Utils.MD5(signStr+"&"+Md5Utils.MD5(md5Key).toUpperCase()).toUpperCase();
        return signature;
    }

    private static String sign(Map<String, String> params) {
        StringBuffer sb = new StringBuffer();
        params.forEach((k, v) -> {
            sb.append(k + "=" + v + "&");
        });
        if (!org.springframework.util.StringUtils.isEmpty(sb)) {
            String str = sb.toString();
            str = str.substring(0, str.length() - 1);
            return str;
        }
        return null;
    }
}
