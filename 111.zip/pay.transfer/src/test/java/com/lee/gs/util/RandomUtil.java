package com.lee.gs.util;

import java.util.Random;

public class RandomUtil {
	public static String randomStr(int num) {
		char[] randomMetaData = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o',
				'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J',
				'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2', '3', '4',
				'5', '6', '7', '8', '9' };
		Random random = new Random();
		String tNonceStr = "";
		for (int i = 0; i < num; i++) {
			tNonceStr += (randomMetaData[random.nextInt(randomMetaData.length - 1)]);
		}
		return tNonceStr;
	}

	public static void main(String[] args) {
		// for (int i = 0; i < 1000; i++) {
		// System.out.println(i + " :" + "P" +
		// DateUtil.getString(DateUtil.Y_M_D_H_M_S_2).substring(3, 14)
		// + RandomUtil.randomStr(3));
		// }
		int aa = 29;
		for (int j = 0; j < 15; j++) {
			int count0 = 0;
			int count1 = 0;
			int count2 = 0;
			int counthalf = 0;
			int countAA3 = 0;
			int countAA2 = 0;
			int countAA1 = 0;
			int countAA = 0;
			int countBIG = 0;
			for (int i = 0; i < 10000; i++) {
				int rand = RandomUtil.randomNumber(aa, aa/4);
				if (rand == 0) {
					count0++;
				} else if (rand == 1) {
					count1++;
				} else if (rand == 2) {
					count2++;
				} else if (rand == aa / 2) {
					counthalf++;
				} else if (rand == aa - 3) {
					countAA3++;
				} else if (rand == aa - 2) {
					countAA2++;
				} else if (rand == aa - 1) {
					countAA1++;
				} else if (rand == aa) {
					countAA++;
				} else if (rand > aa) {
					countBIG++;
				}
			}
			System.out.println(count0 + ",	" + count1 + ",	" + count2 + ",	" + counthalf + ",	" + countAA3 + ",	"
					+ countAA2 + ",	" + countAA1 + ",	" + countAA + ",	" + countBIG);
		}

	}

	// 随机大写字母
	public static char randomUpperChar() {
		Random random = new Random();
		return (char) (65 + random.nextInt(26));
	}

	// 随机小写写字�?
	public static char randomLowerChar() {
		Random random = new Random();
		return (char) (97 + random.nextInt(26));
	}

	// 随机数字
	public static char randomNumber() {
		Random random = new Random();
		return (char) (48 + random.nextInt(9));
	}

	// 随机组合�?
	public static String randomStr(int num, boolean upper, boolean lower, boolean number) {

		Random random = new Random();
		int charType = 0;
		char newChar;
		boolean hasUpper = false;
		boolean hasLower = false;
		StringBuffer randomStr = new StringBuffer();
		for (int i = 0; i < num; i++) {
			if (i == num - 1 && upper && !hasUpper && !hasLower) {
				newChar = randomUpperChar();
			} else {
				charType = random.nextInt(3);
				switch (charType) {
				case 0:
					if (upper) {
						newChar = randomUpperChar();
						hasUpper = true;
						break;
					}
				case 1:
					if (lower) {
						newChar = randomLowerChar();
						hasLower = true;
						break;
					}
				case 2:
					if (number) {
						newChar = randomNumber();
						break;
					}
				default:
					newChar = randomUpperChar();
					hasUpper = true;
				}
			}
			randomStr.append(newChar);
		}
		return randomStr.toString();
	}

	// 随机数字
	public static int randomNumber(int i) {
		Random random = new Random();
		return random.nextInt(i);
	}

	// 随机数字,按权重从小到�?
	public static int randomNumber(int maxNumber, int weight) {
		maxNumber--;
		if (maxNumber < 1)
			return 0;
		if (weight >= maxNumber) {
			// return weight = maxNumber;
		} else if (weight < 1) {
			return 0;
		}
		Random random = new Random();
		int rand = maxNumber - random.nextInt((weight + 1) * maxNumber) / weight;

		if (rand < 0) {
			rand = 0;
		}
		return rand;
	}
}
