package com.lee.gs.util;

import java.io.BufferedInputStream;
import java.io.BufferedReader;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLConnection;
import java.net.URLDecoder;
import java.net.URLEncoder;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;


import com.alibaba.fastjson.JSONObject;
import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.message.BasicHeader;
import org.apache.http.protocol.HTTP;
import org.apache.http.util.EntityUtils;


public class HttpUtil {
	private static final Log LOG = LogFactory.getLog(HttpUtil.class);
	private static CloseableHttpClient httpClient;

	public static String getResponseBodyAsString(InputStream in) {
		try {
			// ���php BOMͷ����
			BOMInputStream bomIn = new BOMInputStream(in, false,
					ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE,
					ByteOrderMark.UTF_16BE);
			String charset = "UTF-8";
			// ����⵽bom����ʹ��bom��Ӧ�ı���
			if (bomIn.hasBOM()) {
				charset = bomIn.getBOMCharsetName();
			}
			BufferedInputStream buf = new BufferedInputStream(bomIn);
			byte[] buffer = new byte[1024];
			StringBuffer data = new StringBuffer();
			int readDataLen;
			while ((readDataLen = buf.read(buffer)) != -1) {
				data.append(new String(buffer, 0, readDataLen, charset));
			}
			if (LOG.isDebugEnabled()) {
				LOG.debug(data.toString());
			}
			try {
				buf.close();
			} catch (Exception e) {
				LOG.error(e.getMessage(), e);
			}
			return data.toString();
		} catch (Exception e) {
			e.printStackTrace();
			LOG.error(e.getMessage(), e);
		}
		return null;
	}

	public static RequestResult result(String url, String params, int timeout) {
		HttpURLConnection conn = null;
		try {
			//LOG.debug("������:" + params);
			URL urlObj = new URL(url);
			conn = (HttpURLConnection) urlObj.openConnection();
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.setConnectTimeout(timeout);
			conn.setReadTimeout(timeout);
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("Content-Length",
					String.valueOf(params.length()));
			OutputStream outStream = conn.getOutputStream();
			outStream.write(params.toString().getBytes("utf-8"));
			outStream.flush();
			outStream.close();
			String resStr = null;
			if (conn.getResponseCode() == 200) {
				resStr = getResponseBodyAsString(conn.getInputStream());
				return new RequestResult(conn, resStr, null);
			} else {
				return new RequestResult(conn, null, "�����쳣:"
						+ String.valueOf(conn.getResponseCode()));
			}
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return new RequestResult(conn, null, e.getMessage());
		}
	}
	public static String resultGET(String url, String params) {
		return resultGET(url, params,5000).getResStr();
	}
	public static RequestResult resultGET(String url, String params, int timeout) {
		HttpURLConnection conn = null;
		try {
			LOG.debug("������:" + params);
			URL urlObj = new URL(url);
			conn = (HttpURLConnection) urlObj.openConnection();
			conn.setRequestMethod("GET");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.setConnectTimeout(timeout);
			conn.setRequestProperty("Content-Type",
					"application/x-www-form-urlencoded");
			conn.setRequestProperty("Content-Length",
					String.valueOf(params.length()));
			OutputStream outStream = conn.getOutputStream();
			outStream.write(params.toString().getBytes("utf-8"));
			outStream.flush();
			outStream.close();
			String resStr = null;
			if (conn.getResponseCode() == 200) {
				resStr = getResponseBodyAsString(conn.getInputStream());
				return new RequestResult(conn, resStr, null);
			} else {
				return new RequestResult(conn, null, "�����쳣:"
						+ String.valueOf(conn.getResponseCode()));
			}
		} catch (Exception e) {
			LOG.error(e.getMessage(), e);
			return new RequestResult(conn, null, e.getMessage());
		}
	}
	public static RequestResult result(String url, String params) {
		return result(url, params, 15*1000);
	}

	public static String request(String url, Map<String, String> mapParam) {
		return request(url, mapToParam(mapParam));
	}

	public static String request(String url, String params) {
		return result(url, params).getResStr();
	}
	public static String requestJson(String url, String params,int timeout) {
		return requestPostJson(url, params,timeout).getResStr();
	}

	public static String request(String url, Map<String, String> mapParam,
			int timeout) {
		return request(url, mapToParam(mapParam), timeout);
	}

	public static String request(String url, String params, int timeout) {
		return result(url, params, timeout).getResStr();
	}
	public static String mapToParam(Map<String, String> mapParam) {
		StringBuffer params = new StringBuffer();
		for (Map.Entry<String, String> p : mapParam.entrySet()) {
			params.append(p.getKey());
			params.append("=");
			params.append(p.getValue());
			params.append("&");
		}
		if (params.length() > 0) {
			params.deleteCharAt(params.length() - 1);
		}
		return params.toString();
	}
	public static RequestResult requestPostJson(String qUrl, String jsonStr,int timeout)
    {
		HttpURLConnection conn = null;
        try {
        	URL urlObj = new URL(qUrl);
			conn = (HttpURLConnection) urlObj.openConnection();
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.setConnectTimeout(timeout);
            // �����ļ�����:
            conn.setRequestProperty("Content-Type", "application/json");
			conn.setRequestProperty("Content-Length",String.valueOf(jsonStr.length()));
			OutputStream outStream = conn.getOutputStream();
			outStream.write(jsonStr.toString().getBytes("utf-8"));
			outStream.flush();
			outStream.close();
			String resStr = null;
			if (conn.getResponseCode() == 200) {
				resStr = getResponseBodyAsString(conn.getInputStream());
				return new RequestResult(conn, resStr, null);
			} else {
				return new RequestResult(conn, null, "�����쳣:"
						+ String.valueOf(conn.getResponseCode()));
			}
		 } catch (Exception e) {
				LOG.error(e.getMessage(), e);
				return new RequestResult(conn, null, e.getMessage());
		}
    }


	public static String reqPostStringCust(String callURL, String sendData, String contentType) {
		try {
			URL url = new URL(callURL);
			HttpURLConnection connection = (HttpURLConnection) url.openConnection();
			connection.setRequestMethod("POST");
			connection.setRequestProperty("Content-Type", contentType);
			connection.setRequestProperty("charset", "utf-8");

	        connection.setDoOutput(true);
	        connection.setDoInput(true);
	        connection.setConnectTimeout(1000*30);
	        connection.setReadTimeout(20000);


			connection.connect();
			DataOutputStream out = new DataOutputStream(connection
					.getOutputStream());
			out.writeBytes(sendData);

			out.flush();
			out.close();
			int rc = connection.getResponseCode();
			if (rc == 200) {
				String temp;
				InputStream in = null;
				in = connection.getInputStream();
				BufferedReader data = new BufferedReader(new InputStreamReader(
						in, "UTF8"));
				StringBuffer result = new StringBuffer();
				while ((temp = data.readLine()) != null) {
					result.append(temp);
					temp = null;
				}
				data.close();
				in.close();
				return result.toString();
			}
		} catch (Exception e) {
				System.out.println(e.getMessage());
		}
		return null;
	}

	public static String requestXml(String url, String params,int timeout) {
		return requestPostXml(url, params,timeout).getResStr();
	}

	public static RequestResult requestPostXml(String qUrl, String xmlStr,int timeout)
    {
		HttpURLConnection conn = null;
        try {
        	URL urlObj = new URL(qUrl);
			conn = (HttpURLConnection) urlObj.openConnection();
			conn.setRequestMethod("POST");
			conn.setDoOutput(true);
			conn.setDoInput(true);
			conn.setUseCaches(false);
			conn.setConnectTimeout(timeout);
            // �����ļ�����:
            conn.setRequestProperty("Content-Type", "text/xml;charset=ISO-8859-1");
			conn.setRequestProperty("Content-Length",String.valueOf(xmlStr.length()));
			OutputStream outStream = conn.getOutputStream();
			outStream.write(xmlStr.toString().getBytes("utf-8"));
			outStream.flush();
			outStream.close();
			String resStr = null;
			if (conn.getResponseCode() == 200) {
				resStr = getResponseBodyAsString(conn.getInputStream());
				return new RequestResult(conn, resStr, null);
			} else {
				return new RequestResult(conn, null, "�����쳣:"
						+ String.valueOf(conn.getResponseCode()));
			}
		 } catch (Exception e) {
				LOG.error(e.getMessage(), e);
				return new RequestResult(conn, null, e.getMessage());
		}
    }

	public static void main(String[] args) {
		RequestResult result = HttpUtil.result(
				"http://nw.a.com/api/return.html1", "");
		System.out.println(result.getResOrErr());
	}

	public static String sendPostContent(String url, String content) {
        PrintWriter out = null;
        BufferedReader in = null;
        String result = "";
        try {
            URL realUrl = new URL(url);
            // �򿪺�URL֮�������
            URLConnection conn = realUrl.openConnection();
            // ����ͨ�õ���������
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
           // conn.setRequestProperty("content-type","text/plain");
            conn.setRequestProperty("Content-Type", "text/plain;charset=utf-8");
            //conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            // ����POST�������������������
            conn.setDoOutput(true);
            conn.setDoInput(true);
            // ��ȡURLConnection�����Ӧ�������
            out = new PrintWriter(conn.getOutputStream());
            // �����������
            ///content = URLEncoder.encode(content,"utf-8");
            out.print(content);
            // flush������Ļ���
            out.flush();
            // ����BufferedReader����������ȡURL����Ӧ
            int code = ((HttpURLConnection) conn).getResponseCode();
            System.out.println("code:"+code);
            in = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
        } catch (Exception e) {
            System.out.println("���� POST ��������쳣��"+e);
            e.printStackTrace();
        }
        //ʹ��finally�����ر��������������
        finally{
            try{
                if(out!=null){
                    out.close();
                }
                if(in!=null){
                    in.close();
                }
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }
        return result;
    }


	 /**
	  *
	  * Ȫ���������÷���
	  */
	public static Map<String,String> sendPostContentForQzCmbc(String url, String content,String pv,String sdkv,String sk,String sign,String sign_type) {
		Map<String,String> outMap = new HashMap<String,String>();
		String resultCode = "-9999";
		String message = "[CODE001]��Դæ�����Ժ�...";
		PrintWriter out = null;
		OutputStream os = null;
        BufferedReader in = null;
        String result = "";
        HttpURLConnection httpUrlCon= null;
        try {
            URL realUrl = new URL(url);
            // �򿪺�URL֮�������
            URLConnection conn = realUrl.openConnection();
            // ����ͨ�õ���������
            conn.setRequestProperty("accept", "*/*");
            conn.setRequestProperty("connection", "Keep-Alive");
            conn.setRequestProperty("user-agent",
                    "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1;SV1)");
           // conn.setRequestProperty("content-type","text/plain");
            conn.setRequestProperty("Content-Type", "text/plain;charset=utf-8");
            //conn.setRequestProperty("Content-Type", "application/json;charset=UTF-8");
            conn.setRequestProperty(ProtocolMappings.PROTOCOL_VERSION, pv);
            conn.setRequestProperty(ProtocolMappings.PROTOCOL_SDK_VERSION, sdkv);
            conn.setRequestProperty(ProtocolMappings.PROTOCOL_SECRET_KEY, sk);
            conn.setRequestProperty(ProtocolMappings.PROTOCOL_SIGN, sign);
            conn.setRequestProperty(ProtocolMappings.PROTOCOL_SIGN_TYPE, sign_type);
            // ����POST�������������������
            conn.setDoOutput(true);
            conn.setDoInput(true);
            // ��ȡURLConnection�����Ӧ�������
            os = conn.getOutputStream();
			os.write(content.getBytes("utf-8"));
			os.flush();
//            out = new PrintWriter(conn.getOutputStream());
//            // �����������
////            /content = URLEncoder.encode(content,"utf-8");
//            out.print(content.getBytes("utf-8"));
            // flush������Ļ���
//            out.flush();
            // ����BufferedReader����������ȡURL����Ӧ
            httpUrlCon = (HttpURLConnection)conn;
            int code = httpUrlCon.getResponseCode();
            System.out.println("code:"+code);
            in = new BufferedReader(
                    new InputStreamReader(conn.getInputStream()));
            String line;
            while ((line = in.readLine()) != null) {
                result += line;
            }
            Map<String, List<String>> outMaps= httpUrlCon.getHeaderFields();
            if(outMaps.get("x-oapi-error-code")!=null)
            {
            	List<String> codeList = outMaps.get("x-oapi-error-code");
            	if(codeList!=null&&codeList.size()>0)
            	{
            		 resultCode = codeList.get(0);
            	}
            }
            if(outMaps.get("x-oapi-msg")!=null)
            {
            	List<String> msgList = outMaps.get("x-oapi-msg");
            	if(msgList!=null&&msgList.size()>0)
            	{
            		message = msgList.get(0);
            		message = URLDecoder.decode(message, "UTF-8");
            	}
            }
            else
            {
            	message = "�޷�����Ϣ";
            }
        } catch (Exception e) {
            System.out.println("���� POST ��������쳣��"+e);
            e.printStackTrace();
            resultCode = "-9901";
            message = "[CODE002]�����쳣�����Ժ�...";
        }
        //ʹ��finally�����ر��������������
        finally{
            try{
                if(out!=null){
                    out.close();
                }
                if(os!=null){
                    os.close();
                }
                if(in!=null){
                    in.close();
                }
            }
            catch(IOException ex){
                ex.printStackTrace();
            }
        }
        outMap.put("RESULTCODE",resultCode);
        outMap.put("MESSAGE",message);
        outMap.put("BODY",result);
        return outMap;
    }



	public static String mapToJson(Map<String, String> map) {
		Iterator<Map.Entry<String, String>> it = map.entrySet().iterator();
		StringBuffer json = new StringBuffer();
		json.append("{");
		while (it.hasNext()) {
			Map.Entry<String, String> entry = it.next();
			String key = entry.getKey();
			String value = entry.getValue();
			json.append("\"").append(key).append("\"");
			json.append(":");
			json.append("\"").append(value).append("\"");
			if (it.hasNext()) {
				json.append(",");
			}
		}
		json.append("}");
		LOG.debug("mapToJson=" + json.toString());
		return json.toString();
	}


	 /**
     * post(��չ֧�����󷽷�)
     *
     * @param url  �����url
     * @param data post json �ύ�Ĳ���
     * @return
     */
    public static String post(String url, String data) {
        String responseBody = "";
        //ָ��url,��http��ʽ
        HttpPost httpPost = new HttpPost(url);
        //��������
        StringEntity se = new StringEntity(data, "utf-8");
        se.setContentEncoding(new BasicHeader(HTTP.CONTENT_TYPE, "application/json"));
        httpPost.setEntity(se);
        //HttpEntity
        HttpEntity entity = null;
        //��������
        CloseableHttpResponse response = null;
        try {
        	httpClient = new SSLClient();
            response = httpClient.execute(httpPost);
            if (response.getStatusLine().getStatusCode() == HttpStatus.SC_OK) {
                entity = response.getEntity();
                responseBody = EntityUtils.toString(entity);
            }
        } catch (IOException ex) {
            LOG.debug("http post error >> ex = {}");
        } catch (Exception e) {
        	LOG.debug("http post error >> e = {}");
			e.printStackTrace();
		} finally {
            // �ر�����,�ͷ���Դ
            if (entity != null) {
                EntityUtils.consumeQuietly(entity); //���Զ��ͷ�����
            }
            if (response != null) {
                try {
                    response.close();
                } catch (IOException e) {
                	 LOG.debug("http post close error >> ex = {}");
                }
            }
        }
        return responseBody;
    }


    // �԰������ĵ��ַ�������ת�룬��ΪUTF-8���������Ǳ�Ҫ����һ�ν���
    private static String encode(String value) throws Exception{
    	return URLEncoder.encode(value, "UTF-8");
    }

    private static String getBoundry() {
        StringBuffer _sb = new StringBuffer();
        for (int t = 1; t < 12; t++) {
            long time = System.currentTimeMillis() + t;
            if (time % 3 == 0) {
                _sb.append((char) time % 9);
            } else if (time % 3 == 1) {
                _sb.append((char) (65 + time % 26));
            } else {
                _sb.append((char) (97 + time % 26));
            }
        }
        return _sb.toString();
    }

    /**
     *
     * �õ�ip
     * @param request
     */
    public static String getRemoteAddress(HttpServletRequest request) {
		String ip = request.getHeader("x-forwarded-for");
		if (ip == null || ip.length() == 0 || ip.equalsIgnoreCase("unknown")) {
			ip = request.getHeader("Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || ip.equalsIgnoreCase("unknown")) {
			ip = request.getHeader("WL-Proxy-Client-IP");
		}
		if (ip == null || ip.length() == 0 || ip.equalsIgnoreCase("unknown")) {
			ip = request.getRemoteAddr();
		}
		return ip;
	}
}
