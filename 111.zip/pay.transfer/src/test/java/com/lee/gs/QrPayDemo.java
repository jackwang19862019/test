package com.lee.gs;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;
import java.util.Random;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;



/**
 * 支付Demo
 *
 */
public class QrPayDemo {
    static final char HEX_DIGITS[] = { '0', '1', '2', '3', '4', '5', '6', '7',
            '8', '9', 'A', 'B', 'C', 'D', 'E', 'F' };
    //测试地址
    public static String  testRequestUrl="http://gway.yt888f.com:7060/api/qrCodePay.action";
    //生产地址
    public static String  proRequestUrl="http://gway.yt888f.com:7060";

    public static void main(String[] args) throws Throwable {
        //pay();//支付请求接口
//		result();//支付结果异步模拟通知接口
        String result = "{reqData={\"appId\":\"GS190608151201798\",\"goodsInfo\":\"recharge\",\"outTradeNo\":\"1020588003202383\",\"payDate\":\"2019-08-22 15:23:24\",\"payType\":\"ZFB\",\"resultCode\":\"00\",\"totalAmount\":\"10000\",\"sign\":\"0949089BCEC15739DA976E048FB129F6\"}}";
        testResult(result);
    }

    private static void testResult(String result) {
        JSONObject jsonObject = JSONObject.parseObject(result);
        Map<String, String> map = JSONObject.toJavaObject(jsonObject, Map.class);
        System.out.println(map.get("sign"));
    }

    /**
     * 扫码支付接口包含：WX:微信支付,ZFB:支付宝支付 QQ：QQ支付 BAI_DU：百度支付 JD：京东支付  UNIONPAY_QRCODE：银联二维码支付 WX_WAP：微信H5支付
     * 1）调用pay返回二维码
     * 2）用户扫描二维码完成支付
     * 3）支付完成后调用用户提供的notifyUrl地址通知用户支付成功；
     */
    public static void pay() {
        Map<String, String> metaSignMap = new TreeMap<>();
        metaSignMap.put("appId", "GS190608151201798");
        metaSignMap.put("payType", "ZFB_WAP");// WX:微信支付,ZFB:支付宝支付 QQ：QQ支付 BAI_DU：百度支付 JD：京东支付  UNIONPAY_QRCODE：银联二维码支付 WX_WAP：微信H5支付
        metaSignMap.put("nonceStr", randomStr(4));// 4位随机数
        String orderNum = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()); // 20位
        orderNum += randomStr(3);
        metaSignMap.put("outTradeNo", orderNum);
        metaSignMap.put("requestIp", "120.33.61.252");// 单位:分
        metaSignMap.put("totalAmount", "50000");// 单位:分
        metaSignMap.put("goodsInfo", "笔");// 商品名称：20位
        metaSignMap.put("notifyUrl", "http://127.0.0.1/");// 回调地址
        metaSignMap.put("returnUrl", "http://localhost/view");// 回显地址
        String metaSignJsonStr = mapToJson(metaSignMap);
        String sign = MD5(metaSignJsonStr + "BF776C0D4BB0664E46E297A40663A96F", "UTF-8");// 32位
        System.out.println("sign=" + sign); // 英文字母大写
        metaSignMap.put("sign", sign);
        String reqParam = "reqData=" + mapToJson(metaSignMap);
        String resultJsonStr = request(testRequestUrl, reqParam);

        System.out.println(resultJsonStr);

        Map<String, String> map = (Map)JSONObject.parseObject(resultJsonStr);
        String signStr = map.get("sign");
        map.remove("sign");
        //再次排序
        map = new TreeMap<>(map);
        String str = JSON.toJSONString(map);
        String targetString = MD5(str + "BF776C0D4BB0664E46E297A40663A96F", "UTF-8");
        System.out.println(targetString.equals(signStr));
    }



    /**
     * 支付结果处理
     * @throws Throwable
     */
    public static void result(HttpServletRequest request,
                              HttpServletResponse response) throws Throwable {
        String data = request.getParameter("reqData");
        JSONObject jsonObj = JSONObject.parseObject(data);
        Map<String, String> metaSignMap = new TreeMap<String, String>();
        metaSignMap.put("appId", jsonObj.getString("appId"));
        metaSignMap.put("payType", jsonObj.getString("payType"));
        metaSignMap.put("outTradeNo", jsonObj.getString("outTradeNo"));
        metaSignMap.put("totalAmount", jsonObj.getString("totalAmount"));
        metaSignMap.put("goodsInfo", jsonObj.getString("goodsInfo"));
        metaSignMap.put("resultCode", jsonObj.getString("resultCode"));// 支付状态
        metaSignMap.put("payDate", jsonObj.getString("payDate"));// yyyy-MM-dd
        // HH:mm:ss
        String jsonStr = mapToJson(metaSignMap);
        String sign = MD5(jsonStr.toString() + "xxxxxxxxxxxxxxxxxxx", "UTF-8");
        if(!sign.equals(jsonObj.getString("sign"))){
            return;
        }
        System.out.println("签名校验成功");
        response.getOutputStream().write("0".getBytes());
    }

    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuffer data = new StringBuffer();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, "UTF-8"));
            }
            System.out.println("响应报文=" + data);
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    public static String request(String url, String params) {
        try {
            System.out.println("请求报文:" + params);
            URL urlObj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlObj
                    .openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(1000 * 5);
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setRequestProperty("Content-Type",
                    "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length",
                    String.valueOf(params.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(params.toString().getBytes("UTF-8"));
            outStream.flush();
            outStream.close();
            return getResponseBodyAsString(conn.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public final static String MD5(String s, String encoding) {
        try {
            byte[] btInput = s.getBytes(encoding);
            MessageDigest mdInst = MessageDigest.getInstance("MD5");
            mdInst.update(btInput);
            byte[] md = mdInst.digest();
            int j = md.length;
            char str[] = new char[j * 2];
            int k = 0;
            for (int i = 0; i < j; i++) {
                byte byte0 = md[i];
                str[k++] = HEX_DIGITS[byte0 >>> 4 & 0xf];
                str[k++] = HEX_DIGITS[byte0 & 0xf];
            }
            return new String(str);
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static String mapToJson(Map<String, String> map) {
        Iterator<Map.Entry<String, String>> it = map.entrySet().iterator();
        StringBuffer json = new StringBuffer();
        json.append("{");
        while (it.hasNext()) {
            Map.Entry<String, String> entry = it.next();
            String key = entry.getKey();
            String value = entry.getValue();
            json.append("\"").append(key).append("\"");
            json.append(":");
            json.append("\"").append(value).append("\"");
            if (it.hasNext()) {
                json.append(",");
            }
        }
        json.append("}");
        System.out.println("mapToJson=" + json.toString());
        return json.toString();
    }

    public static String randomStr(int num) {
        char[] randomMetaData = new char[] { 'a', 'b', 'c', 'd', 'e', 'f', 'g',
                'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's',
                't', 'u', 'v', 'w', 'x', 'y', 'z', 'A', 'B', 'C', 'D', 'E',
                'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q',
                'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', '0', '1', '2',
                '3', '4', '5', '6', '7', '8', '9' };
        Random random = new Random();
        String tNonceStr = "";
        for (int i = 0; i < num; i++) {
            tNonceStr += (randomMetaData[random
                    .nextInt(randomMetaData.length - 1)]);
        }
        return tNonceStr;
    }
}
