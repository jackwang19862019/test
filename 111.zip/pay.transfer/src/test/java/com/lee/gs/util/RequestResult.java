package com.lee.gs.util;

import java.net.HttpURLConnection;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 *
 *
 */
public class RequestResult {
	private HttpURLConnection connection;
	private String resStr;
	private String errStr;
	private static final Log LOG = LogFactory.getLog(RequestResult.class);

	public String getResOrErr() {
		return resStr == null ? errStr : resStr;
	}

	public String getErrStr() {
		return errStr;
	}

	public void setErrStr(String errStr) {
		this.errStr = errStr;
	}

	public HttpURLConnection getConnection() {
		return connection;
	}

	public void setConnection(HttpURLConnection connection) {
		this.connection = connection;
	}

	public String getResStr() {
		return resStr;
	}

	public void setResStr(String resStr) {
		this.resStr = resStr;
	}

	public RequestResult(HttpURLConnection connection, String resStr, String errStr) {
		super();
		this.connection = connection;
		this.resStr = resStr;
		if(resStr!=null){
			if (this.resStr.length() > 5000) {
				LOG.error("HTTP请求同步返回报文超长==长度=" + this.resStr.length() + "==" + this.resStr);
				this.resStr.substring(0, 5000);
			}
		}
		this.errStr = errStr;
	}

}
