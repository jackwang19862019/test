package com.lee.gs.util;


/**
 *
 * @author sihai
 *
 */
public interface ProtocolMappings {

	String PROTOCOL_HEADER_PREFIX = "x-oapi-";

	// 1.0 协议
	String PROTOCOL_VERSION = "x-oapi-pv";							// API协议版本
	String PROTOCOL_SECRET_KEY = "x-oapi-sk";						// SecretKey
	String PROTOCOL_APP_VERSION = "x-oapi-appv";					// APP Version
	String PROTOCOL_CHANNEL = "x-oapi-channel";						// 渠道�?
	String PROTOCOL_DEVICE_ID = "x-oapi-devid";						// 设备ID
	String PROTOCOL_LOCATION = "x-oapi-location";					// 地理位置信息
	String PROTOCOL_SCREEN = "x-oapi-screen";						// 设备屏幕信息
	String PROTOCOL_NETWORK = "x-oapi-nt";						    // 设备网络信息
	String PROTOCOL_SDK_VERSION = "x-oapi-sdkv";					// sdk version
	String PROTOCOL_TIMESTAMP = "x-oapi-ts";					    // 客户端请求时间戳
	String PROTOCOL_SID = "x-oapi-sid";								// 客户端用户登录会话ID
	String PROTOCOL_USER_ID = "x-oapi-uid";							// 客户端拿到的用户ID，会话失效也有可能拿到的
	String PROTOCOL_DEBUG = "x-oapi-debug";							// 是否�?启debug模式�? true �?�?
	String PROTOCOL_IMEI = "x-oapi-imei";							// 国际移动设备识别码，即�?�常�?说的手机序列号�?�手机�?�串号�??
	String PROTOCOL_IMSI = "x-oapi-imsi";							// 国际移动用户识别码，是用于区分蜂窝网络中不同用户的�?�在�?有蜂窝网络中不重复的识别�?
	String PROTOCOL_SIGN = "x-oapi-sign";							// 客户端请求安全签�?
	String PROTOCOL_SIGN_TYPE = "x-oapi-sm";					// 客户端请求安全签名类�?

	// Response

	String PROTOCOL_ERROR_CODE = "x-oapi-error-code";				//
	String PROTOCOL_ERROR_MSG = "x-oapi-msg";						//
	String PROTOCOL_DEBUG_ERROR_MSG = "x-oapi-debug-msg";			//

	/**
	 *
	 */
	String ERROR_CODE_SUCCEED = "SUCCEED";

	public static enum SignType {
	    RSA,
        MD5;
    }
}
