package com.lee.kuaiyitong;

import com.alibaba.fastjson.JSON;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.springframework.web.client.RestTemplate;

import java.util.Map;
import java.util.TreeMap;

public class Kuaiyitong {

    static final String payUrl = "https://income.nnmmc.com";

    static final String merchNo = "AWD9082416032324700";

    static final String key = "2d6d82a4721046fe85e37c59062026a9";

    public static void main(String[] args) {
        kuaiyitongPaySm();
        //kuaiyitongPayWy();
    }

    private static void kuaiyitongPayWy() {
        RestTemplate restTemplate = new RestTemplate();
        Map params = new TreeMap();
        params.put("merchantCode", merchNo);
        params.put("amount", "5000");
        params.put("orderNumber", System.currentTimeMillis() + "");
        params.put("payCode", "D0_ALIPAY");
        params.put("submitTime", "20190802122312");
        params.put("commodityName", "产品名称");
        params.put("submitIp", "88.172.168.22");
        params.put("syncRedirectUrl", "http://www.ccc");
        params.put("asyncNotifyUrl", "http://www.ccc");

        params.put("bankCode", "CCB");
        params.put("remark", "备注");

        String sign = SignatureUtils.sign(params, key);
        params.put("sign", sign);
        System.out.println("请求入参："+ JSON.toJSON(params));
        String result = restTemplate.postForObject(payUrl+"/cashier/b2cAPI", HttpsParams.buildFormEntity(params), String.class);
        System.out.println("第三方返回：" + result);
    }

    /**
     * 扫码
     */
    private static void kuaiyitongPaySm() {
        RestTemplate restTemplate = new RestTemplate();
        Map params = new TreeMap();
        params.put("merchantCode", merchNo);
        params.put("amount", "499");
        params.put("orderNumber", System.currentTimeMillis() + "");
        params.put("payCode", "D0_ALIPAY");
        params.put("submitTime", "20190802122312");
        params.put("commodityName", "产品名称");
        params.put("submitIp", "88.172.168.22");
        params.put("syncRedirectUrl", "http://www.ccc");
        params.put("asyncNotifyUrl", "http://www.ccc");
        params.put("remark", "备注");

        String sign = SignatureUtils.sign(params, key);
        params.put("sign", sign);
        System.out.println("请求入参："+ JSON.toJSON(params));
        System.out.println("请求地址："+ payUrl+"/cashier/scanAP");
        String result = restTemplate.postForObject(payUrl+"/cashier/scanAPI", HttpsParams.buildFormEntity(params), String.class);
        System.out.println("第三方返回：" + result);

    }
}
