package com.lee.baifu;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.TreeMap;

import static com.lee.lf.ToolKit.MD5;
import static com.lee.lf.ToolKit.request;

public class PayDemo {
	private static final String merchNo = "DR180516201138793";
	private static final String payUrl = "http://defray.948pay.com:8188/api/smPay.action";
	private static final String md5Key = "04FF72F6AC8ACD6FD2F0477F7942FF7F";
	private static final String DesKey = "04FF72F6AC8ACD6FD2F0477F7942FF7F";

    public static void main(String[] args) throws Throwable {
        Map<String, String> metaSignMap = new TreeMap<>();
        metaSignMap.put("merchantNo", merchNo);
        metaSignMap.put("netwayCode", "ZFB_WAP");// 网关代码
        metaSignMap.put("randomNum", "1234");// 4位随机数
        String orderNum = new SimpleDateFormat("yyyyMMddHHmmssSSS").format(new Date()); // 20位
        orderNum += "000";
        metaSignMap.put("orderNum", orderNum);
        metaSignMap.put("payAmount", "50000");// 单位:分
        metaSignMap.put("goodsName", "笔");// 商品名称：20位
        metaSignMap.put("callBackUrl", "http://127.0.0.1/");// 回调地址
        metaSignMap.put("frontBackUrl", "http://localhost/view");// 回显地址
        metaSignMap.put("requestIP", "33.72.173.22");// 客户ip地址
        String metaSignJsonStr = JSON.toJSONString(metaSignMap);
        String sign = MD5(metaSignJsonStr + md5Key, "UTF-8");// 32位
        System.out.println("sign=" + sign); // 英文字母大写
        metaSignMap.put("sign", sign);
        String reqparam = "paramData=" + JSON.toJSONString(metaSignMap);
        String resultJsonStr = request(payUrl, reqparam);
		System.out.println(resultJsonStr);
        // 检查状态
        JSONObject resultJsonObj = JSONObject.parseObject(resultJsonStr);
        String stateCode = resultJsonObj.getString("resultCode");
		System.out.println(resultJsonStr);
        if (!stateCode.equals("00")) {
            System.out.println("订单提交失败");
            return;
        }
        String resultSign = resultJsonObj.getString("sign");
        resultJsonObj.remove("sign");
		System.out.println("===="+resultJsonObj);
        Map map = new TreeMap(resultJsonObj);
		System.out.println("0000"+map);
        String targetString = MD5(JSON.toJSONString(map) + md5Key, "UTF-8");
        if (targetString.equals(resultSign)) {
            System.out.println("签名校验成功");
        } else {
            System.out.println("签名校验失败");
        }
    }

}
