package com.lee.baifu;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class Test {

    public static void main(String[] args) {
        String str1 = "<script type=\"text/javascript\">window.location.href=\"http://qhb.530rx.cn/agentroborder/zfbcz/ordernum/N2019101978426800614990.html\"</script>";
        int http = str1.indexOf("http");
        System.out.println(http);

        int html = str1.indexOf(".html");
        System.out.println(html);

        String substring = str1.substring(http, html);
        System.out.println(substring+".html");
        //======================================================
        Pattern pattern = Pattern.compile("href=\"(.+?)\"");
        Matcher matcher = pattern.matcher(str1);
        if(matcher.find())
            System.out.println(matcher.group(1));
    }

}
