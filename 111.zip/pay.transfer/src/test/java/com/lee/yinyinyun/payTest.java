package com.lee.yinyinyun;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.lee.common.utils.MatchUtils;
import com.lee.common.utils.R;
import com.lee.paythird.demo.utils.SignatureUtils;
import com.lee.paythird.utils.HttpsParams;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.springframework.web.client.RestTemplate;

import java.io.BufferedInputStream;
import java.io.OutputStream;
import java.math.BigDecimal;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.text.DecimalFormat;
import java.util.*;

public class payTest {

    public static final String merchNo_ = "80000810";

    public static final String channelNo = "yingyingyun";

    private static final String payUrl = "http://gateway.winner-winner.cn/order/pay";


    public static void main(String[] args) throws Exception {

        Map<String, String> params = new TreeMap<>();
        //Account ID，由赢赢云分配
        params.put("accountid", merchNo_);
        //通道类型
        params.put("type", "WEIXIN");
        //单位元(人民币)，2 位小数，最小支付 金额为 0.02
        DecimalFormat df = new DecimalFormat("#.00");
        params.put("amount", df.format(new BigDecimal("10")));
        //订单号
        params.put("orderid", System.currentTimeMillis()+"");
        //异步通知地址
        params.put("notifyurl", "www.baidu.com");

        String sign = SignatureUtils.sign(params, "&authtoken=" + "1AA6493857144818BD7167B25334BFF3");
        System.out.println("====="+sign);

        //支付用户 IP
        params.put("clientip", "127.0.0.1");

        params.put("sign", sign.toUpperCase());
        System.out.println(params);

        RestTemplate restTemplate = new RestTemplate();
        List<NameValuePair> list = new ArrayList<>();
        params.forEach((k,v)->list.add(new BasicNameValuePair(k, v)));
        String resultHtml = restTemplate.postForObject(payUrl, HttpsParams.buildFormEntity(params), String.class);
        System.out.println(resultHtml);
    }




}
