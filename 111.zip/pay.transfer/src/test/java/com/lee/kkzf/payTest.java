package com.lee.kkzf;

import com.lee.common.utils.DateUtil;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;

public class payTest {

    //http://ip地址/channel/Common/mail_interface

    private static final String merchKey = "e5o9mtf2mglt1coq18wm23pvet3f769w";

    private static final String kkPayUrl = "http://www.kk999.net/Pay_Index.html";

    private static final String kkPayUrl_ = "http://kk999.net/Pay_Index_Productones.html?ref=MTYy";

    public static void main(String[] args) throws Exception {
        String pay_amount = "500";
        String pay_applydate = DateUtil.getCurrentStr();
        String pay_bankcode = "961";
        String pay_callbackurl = "http://www.baidu.com";
        String pay_memberid = "10162";
        String pay_notifyurl = "http://www.baidu.com";
        String pay_orderid = System.currentTimeMillis() + "";
        String keyValue = "e5o9mtf2mglt1coq18wm23pvet3f769w";
        String stringSignTemp = "pay_amount=" + pay_amount + "&pay_applydate=" + pay_applydate + "&pay_bankcode=" + pay_bankcode + "&pay_callbackurl=" + pay_callbackurl + "&pay_memberid=" + pay_memberid + "&pay_notifyurl=" + pay_notifyurl + "&pay_orderid=" + pay_orderid + "&key=" + keyValue + "";
        String sign = md5(stringSignTemp);
        System.out.println("签名======：" + sign);
        //MD5签名
        String requestParams =
                "pay_amount=" + pay_amount + "&pay_applydate=" + pay_applydate +
                        "&pay_bankcode=" + pay_bankcode + "&pay_callbackurl=" + pay_callbackurl +
                        "&pay_memberid=" + pay_memberid + "&pay_notifyurl=" + pay_notifyurl +
                        "&pay_orderid=" + pay_orderid + "&pay_productname=商品名称&pay_md5sign=" + sign;
        System.out.println("请求参数：" + requestParams);
        String result = request(kkPayUrl, requestParams);
        System.out.println("=========" + result);
    }

    public static String md5(String str) {
        try {
            MessageDigest md = MessageDigest.getInstance("MD5");
            md.update(str.getBytes());
            byte[] byteDigest = md.digest();
            int i;
            //字符数组转换成字符串
            StringBuffer buf = new StringBuffer("");
            for (int offset = 0; offset < byteDigest.length; offset++) {
                i = byteDigest[offset];
                if (i < 0)
                    i += 256;
                if (i < 16)
                    buf.append("0");
                buf.append(Integer.toHexString(i));
            }
            // 32位加密
            return buf.toString().toUpperCase();
            // 16位的加密
            //return buf.toString().substring(8, 24).toUpperCase();//MD5后8A47BB627C603E586922B552E11D67D1
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }


    public static String request(String url, String params) {
        try {
            System.out.println("请求报文:" + params);
            URL urlObj = new URL(url);
            HttpURLConnection conn = (HttpURLConnection) urlObj.openConnection();
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            conn.setDoInput(true);
            conn.setUseCaches(false);
            conn.setConnectTimeout(1000 * 5);
            conn.setRequestProperty("Charset", "UTF-8");
            conn.setRequestProperty("Content-Type", "application/x-www-form-urlencoded");
            conn.setRequestProperty("Content-Length", String.valueOf(params.length()));
            OutputStream outStream = conn.getOutputStream();
            outStream.write(params.toString().getBytes("UTF-8"));
            outStream.flush();
            outStream.close();
            return getResponseBodyAsString(conn.getInputStream());
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static String getResponseBodyAsString(InputStream in) {
        try {
            BufferedInputStream buf = new BufferedInputStream(in);
            byte[] buffer = new byte[1024];
            StringBuffer data = new StringBuffer();
            int readDataLen;
            while ((readDataLen = buf.read(buffer)) != -1) {
                data.append(new String(buffer, 0, readDataLen, "UTF-8"));
            }
            return data.toString();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }
}
