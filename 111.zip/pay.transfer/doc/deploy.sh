#!/bin/sh
# 执行git拉取源码
echo '开始拉取代码======================================='
cd /data/app/transfer/project/pay.transfer
gitLog=`git pull origin 2>&1`
if [ $? -ne 0  ];
then
    echo $gitLog
    exit $?
fi
echo "$gitLog" | while read line
do
    echo $line
done
echo '完成拉取代码======================================='


echo '开始maven打包======================================'
mavenLog=`mvn clean package -Dmaven.test.skip=true 2>&1`
if [ $? -ne 0  ];
then
    echo $mavenLog
    exit $?
fi
echo "$mavenLog" | while read line
do
    echo $line
done
echo '结束maven打包======================================'
echo '开始备份jar包======================================'
cd /data/app/transfer
chmod 777 pay-transfer.jar
mv /data/app/transfer/pay-transfer.jar /data/app/transfer/jar/
echo '结束备份jar包======================================'
cp /data/app/transfer/project/pay.transfer/target/pay-transfer.jar /data/app/transfer

COUNT=`netstat -nl | grep -w 10086 | sed -r 's#.* (.*)/.*#\1#'| wc -l`
PONT=`ps -ef |grep java |grep -w 'pay-transfer.jar'|grep -v 'grep'|awk '{print $2}'`
echo "进程存在:"$COUNT
echo "占用的PID:"$PONT
if [ 0 == $COUNT ]; then
    cd /data/app/transfer
    nohup java -jar pay-transfer.jar > log.out 2>&1 &
    cd /data/app/transfer
    tail -f log.out
  else
    kill -9 $PONT
    cd /data/app/transfer
    echo "杀死进程PID:"$PONT
    nohup java -jar pay-transfer.jar > log.out 2>&1 &
    cd /data/app/transfer
    tail -f log.out
fi
echo "完成部署============================================"
